---
title: "(26) Activity | Lasse Flagstad | LinkedIn"
link: "https://www.linkedin.com/in/lasse-flagstad/recent-activity/all/"
published:
created: 2025-11-04
description:
tags:
  - "content-creation"
---
## All activity

Loaded 80 Posts posts

- ## Feed post number 1
	Claude mail just dropped  
	(Sonnet 4.5 email prompts)  
	  
	My partner built an email prompt pack powered by Claude's latest model  
	  
	It booked 27 calls in 3 days  
	  
	Here's how it works:  
	1️⃣ Audience Mapper Node → Runs a 2-minute psychographic analysis using your ICP description, then merges it with data from Reddit, LinkedIn, and niche discussion boards  
	  
	2️⃣ Offer Decoder Node → Breaks down your service and pulls out credibility hooks + differentiators. It builds proof-backed positioning  
	  
	3️⃣ PromptMaestro (core node) → Combines both and drafts 3 emails per lead. The emails share value and build reciprocity with your leads  
	  
	4️⃣ Memory Node → Uses Sonnet 4.5's memory tool to store every published email. You never repeat yourself, each asset shared is backed with value and novelty  
	  
	He's helped his clients generate $60,000 in new deals using this prompt pack  
	  
	I have his permission to share it  
	  
	Want it?  
	  
	✅ Comment "PROMPTS"  
	✅ Connect with me and [Lasse Flagstad](https://www.linkedin.com/in/lasse-flagstad/) and we'll send it to you  
	  
	🎁 BONUS: Repost and we'll also send you his Sonnet 4.5 ICP Analysis Prompts
- ## Feed post number 2
	This system gives you unlimited content ideas — 100% on autopilot  
	(and you can grab it for free)  
	  
	Everyone knows they should post more.  
	  
	But sitting down to come up with ideas?  
	Painful.  
	  
	That’s why we built a system that does it for you — 24/7.  
	  
	It’s called the YouTube Content Repurposing Engine — an N8N workflow + Google Sheets setup that automatically turns the YouTube channels you already follow… into endless repurposable ideas for LinkedIn, email, and beyond.  
	  
	Here’s what it does 👇  
	  
	1️⃣ Scrapes the channels you follow — constantly scanning for new videos.  
	  
	2️⃣ Transcribes every upload — turning it into text you can feed into AI.  
	  
	3️⃣ Generates long-form repurposing reports — customized for your company and your tone.  
	  
	4️⃣ Logs everything automatically — so you wake up to new content ideas every day.  
	  
	No brainstorming. No blank-page anxiety.  
	  
	Just a nonstop stream of ideas you can post, repurpose, or remix across channels.  
	  
	We’re talking about a plug-and-play system — not theory.  
	  
	Import the workflow. Add your API keys. Turn it on.  
	  
	And watch as AI does the heavy lifting.  
	  
	We built this because we were tired of wasting hours “getting inspired.”  
	  
	Now the system does it for us — and it never stops.  
	  
	👉 Want the setup?  
	  
	✅ Comment “ENGINE”  
	✅ Connect with me + [Lasse Flagstad](https://www.linkedin.com/in/lasse-flagstad/) — we’ll DM you the workflow and setup guide.
- ## Feed post number 3
	Cloning your brain with AI  
	(Sonnet 4.5 prompt stack)  
	  
	My partner built his own AI brain inside Claude  
	  
	It studied his writing, his goals, and his logic  
	  
	Then it used that data to do everything he does on a daily basis  
	  
	Claude now writes, thinks, and reasons in the same way he does  
	  
	This AI Brain:  
	  
	1️⃣ Booked him 27 calls in under 5 days on autopilot  
	  
	2️⃣ Wrote offers that closed $50,000 in new deals  
	  
	3️⃣ Built 3 full high-value resources (3,000+ new leads per resource)  
	  
	He's letting me share the prompts he used to build it  
	  
	Want to build your own AI Brain?  
	  
	✅ Comment "BUILD"  
	✅ Connect with me and [Lasse Flagstad](https://www.linkedin.com/in/lasse-flagstad/) and we'll send them to you  
	  
	  
	🎁 BONUS: Repost and we'll also send you his Sonnet 4.5 Sales Assistant prompts
- ## Feed post number 4
	🔥 Stop Chasing Google Rankings…  
	  
	Start Owning Perplexity Citations.  
	  
	Because the next Google isn’t coming —  
	it’s already here.  
	And it’s called Perplexity.  
	  
	Perplexity isn’t another chatbot.  
	It’s a $14B AI-powered search engine that blends Google’s real-time data with ChatGPT-level intelligence.  
	But here’s what makes it a goldmine 👇  
	  
	💡 Every answer Perplexity gives is sourced.  
	That means when your brand is cited —  
	you become the trusted authority in every result.  
	  
	And here’s the kicker:  
	Perplexity users spend 11–23 minutes per session.  
	They’re not doom-scrolling — they’re researching, comparing, and buying.  
	Decision-makers. High-intent. Ready to act.  
	  
	While everyone else is still fighting for page one on Google,  
	early movers are locking in citation dominance inside Perplexity.  
	  
	Here’s the Perplexity Visibility Blueprint 👇  
	  
	1️⃣ Use the Question–Answer–Evidence format so your content mirrors how Perplexity thinks  
	2️⃣ Publish on authority sites (Yahoo, GlobeNewswire, or industry outlets it already trusts)  
	3️⃣ Add original stats or proprietary data — even small surveys work  
	4️⃣ Let Perplexity pick it up and cite you automatically  
	5️⃣ Watch those citations compound across answers and industries  
	  
	That’s the Perplexity Flywheel:  
	Citation → Visibility → Authority → More Citations.  
	  
	It’s not SEO.  
	It’s Source Engine Optimization.  
	  
	💡 I just released the Perplexity Domination Playbook + Prompts to show you exactly how to turn one optimized article into dozens of live Perplexity citations in under 7 days.  
	  
	Want it? 👇  
	  
	✅ Comment “PERPLEXITY”  
	✅ Connect with me so I can DM you the playbook  
	  
	♻️ Repost this for priority access + my private list of “Perplexity-friendly media outlets” you can publish on today.
- ## Feed post number 5
	This system does McKinsey-level viral analysis in under 10 minutes  
	(and you can grab it for free)  
	  
	Everyone wants to go viral on LinkedIn.  
	  
	But most don’t know where to start.  
	  
	Recently, in a call with Lasse, we stumbled across a few profiles doing something we hadn’t seen before.  
	  
	To understand why it worked, we built a system — and it’s completely changed the way we think about content.  
	  
	It analyses posts with McKinsey- and BCG-level precision — breaking down structure, flow, post types, and patterns to uncover what truly drives virality. Funny as McKinsey got awarded 100 billion token award by OpenAI  
	  
	See a profile that always blows up?  
	  
	Curious why a creator’s posts outperform yours?  
	  
	Just drop their link in — and the system handles the rest.  
	  
	Here’s what it does 👇  
	  
	1️⃣ Finds every post from the profiles you choose.  
	  
	2️⃣ Classifies them by style: lead magnet, thought leadership, news, or other.  
	  
	3️⃣ Runs a full-scale analysis across all profiles — then delivers a 5+ page breakdown of trends, correlations, and best practices.  
	  
	The result?  
	  
	Crystal-clear insights into what’s working right now — and how to replicate it.  
	  
	We’ve quietly used this for the past 10 months to help drive over 10M+ impressions on LinkedIn — and we’re finally sharing it.  
	  
	Having on-demand, data-driven advice on what to post next doesn’t just help — it skyrockets your odds of going viral.  
	  
	👉 Want the exact prompts to run this for your business?  
	  
	✅ Comment “POST”  
	✅ Connect with me + [Lasse Flagstad](https://www.linkedin.com/in/lasse-flagstad/) — we’ll send it to you via DM.  
	  
	🎁 BONUS: Repost this and we’ll share 75 extra guides and prompts with you.  
	  
	\---  
	  
	Access it here:[https://lnkd.in/gVHaiTct](https://lnkd.in/gVHaiTct)
- ## Feed post number 6
	My mentor cloned his brain with Claude  
	It closed $50,000 in new deals for him  
	  
	My mentor built a prompt stack that replicates his psyche using Claude’s latest model  
	  
	It turned Claude into a full brainstorming partner that can:  
	  
	1️⃣ Write copy that generates 300,000+ impressions per post  
	  
	2️⃣ Build offers with 35% higher closing rates  
	  
	3️⃣ Cut his prompting time by 90%  
	  
	He doesn’t have to reprompt or clarify his goals  
	  
	Claude now knows how he thinks and changes his output accordingly  
	  
	It’s all powered by Sonnet 4.5  
	  
	He’s letting me share it for free  
	  
	Want it?  
	  
	✅ Comment “CLONE”  
	✅ Connect with me and [Lasse Flagstad](https://www.linkedin.com/in/lasse-flagstad/) and we’ll send you the prompts  
	  
	BONUS: Repost and we’ll also send you his Sonnet 4.5 GTM planning prompts
- ## Feed post number 7
	Claude just changed sales forever  
	(Sonnet 4.5 Sales Agent)  
	  
	My partner built a full-stack SDR, researcher, and closer inside Claude  
	  
	Here’s how it works:  
	1️⃣ Claude scans Reddit to extract real buyer psychology (fears, desires, beliefs, and pain language).  
	Every sales script feels like it was written inside your prospect’s mind  
	  
	2️⃣ It dissects your website into a clean, structured offer model.  
	Everything is backed by logic and buying triggers  
	  
	3️⃣ Then it merges audience + offer into a multi-layered closing playbook based on the Emotional Contrast and Belief frameworks.  
	You get long-form, objection-proof call scripts you can run instantly.  
	  
	It’s all powered by Sonnet 4.5’s extended thinking and stamina  
	  
	It can study complex offers and detailed buyer intel without hallucinating  
	  
	My partner cut his own sales call prep time by 70% using it  
	  
	He’s helped founders boost their closing rate by 30% with a 10-minute agent run  
	  
	He’s letting me share it  
	  
	Want it?  
	  
	✅ Comment “CLOSER”  
	✅ Connect with me and [Lasse Flagstad](https://www.linkedin.com/in/lasse-flagstad/) and we’ll send it to you  
	  
	🎁 BONUS: Repost and we’ll also send you his full Claude Business Suite
- ## Feed post number 8
	This prompt stack changes how you use Claude forever  
	(Sonnet 4.5 Brain Prompts)  
	  
	  
	My mentor cloned his brain inside Claude using its latest model  
	  
	It changed everything  
	  
	Claude stopped being a simple tool and became a “partner”  
	  
	It thinks like him  
	  
	Writes like him  
	  
	It even disagrees with him  
	  
	It’s an actual second brain that he can bounce his ideas off of  
	  
	He’s used it to write copy that generated $50,000 in new deals (from 3 posts)  
	  
	It’s also helped him book 27 calls last week just by writing his emails for him  
	  
	Now he’s letting me share the prompts behind it  
	  
	Want them?  
	  
	✅ Comment “Brain”  
	✅ Connect with me and [Lasse Flagstad](https://www.linkedin.com/in/lasse-flagstad/) and we’ll send you the prompts  
	  
	BONUS: Repost and get access to his Sonnet 4.5 offer prompts (35%+ closing rate)
- ## Feed post number 9
	These Claude prompts 5x'd my partner's sales  
	(They're free)  
	  
	  
	My partner rewrote his offer using Claude's latest model (Sonnet 4.5)  
	  
	He closed 4 new deals in under 5 days with it  
	  
	1️⃣ Claude studied his ICP's digital footprint and learned their buying triggers, needs, and frustrations with the existing offers/services  
	  
	2️⃣ The prompts infused his offer with the top 25 buyer thoughts found on niche forums (Reddit, Substack, and niche-specific boards)  
	  
	3️⃣ Claude studied his competitors and found a gap in their offers, then rewrote his offer so it's the only one covering that gap  
	  
	Sonnet 4.5 backed his offer with deep psychographic analysis and put it in a league of its own  
	  
	He's helped his clients rewrite their offers with these prompts  
	  
	Their closing rates went up by 27-35%  
	  
	He's letting me share it with more founders  
	  
	Want to rebuild your offer with them?  
	  
	✅ Comment "PROMPTS"  
	✅ Connect with me and [Harald Røine](https://www.linkedin.com/in/haraldroine/) and we'll send them to you  
	  
	🎁 BONUS: Repost and we'll also send you his full Claude B2B Prompt Suite (Offer Creation, Marketing Team, Sales Agent, and GTM Planning)
- ## Feed post number 15
	This Sonnet 4.5 Sales Agent closed 3 deals last week  
	(It’s free)  
	  
	My mentor’s helped founders book 15+ calls per week using his prompts  
	  
	Now he released a Sales Agent to close those calls  
	  
	Here’s what it does:  
	1️⃣ Researches your leads’ digital footprint→ goes through Reddit and LinkedIn to learn what your ICP actually struggles with. Then modifies your offer to cater to those struggles  
	  
	2️⃣ Builds a call intel pack → researches each lead’s biggest objections, motivators, and buying triggers and gives you a full brief with counters and risk reversals  
	  
	3️⃣ Builds a “Closing Pipeline” → applies a 6-phase framework that mirrors emotions, logic and language. It’s designed to take leads from a demo into a closed deal  
	  
	A Founder closed $18,000 in one week just by prepping for his calls with this agent  
	  
	I’m allowed to share the prompts behind it  
	  
	Want them?  
	  
	✅ Comment “SALES”  
	✅ Connect with me and [Lasse Flagstad](https://www.linkedin.com/in/lasse-flagstad/) and we’ll send them to you  
	  
	🎁 BONUS: Repost and we’ll also give you access to his full Claude Sonnet 4.5 Business Suite
- ## Feed post number 16
	These prompts turn Claude into a sales expert  
	($50k in new sales last month)  
	  
	My mentor built a Sonnet 4.5 Sales Agent  
	  
	Here’s how it works:  
	  
	1️⃣ Analyzes Reddit threads for buyer psychology. It pulls fears, frustrations, beliefs, and phrases that decision-makers actually use. Then it uses those insights to write your copy  
	  
	2️⃣ Dissects your product or service into a pure, factual structure. It’s not just writing some generic script, everything is tailored to your offer  
	  
	3️⃣ Merges audience + offer into a complete sales playbook. It builds 6 phases of copy designed to take prospects from curiosity to closing  
	  
	It’s the same agent that helped him close $50k in new deals last month  
	  
	He’s helped his clients generate full sales scripts and proposals in under an hour using this agent  
	  
	Now he’s letting me share it  
	  
	Want it?  
	  
	✅ Comment “AGENT”  
	✅ Connect with me and [Lasse Flagstad](https://www.linkedin.com/in/lasse-flagstad/) and we’ll give you access to it  
	  
	🎁 BONUS: Repost and get access to his full Claude Business Suite (GTM, Marketing, and Sales prompts)
- ## Feed post number 17
	These prompts cut our marketing spend by 90%  
	I’m sharing them for free  
	  
	My partner built a full marketing team that lives inside Claude  
	  
	It’s all powered by its latest model (Sonnet 4.5)  
	  
	Here’s how it works:  
	  
	1️⃣ ‘Market Mapper’ finds your ICP, maps demand pockets, and identifies the warmest leads in your niche  
	  
	2️⃣ ‘Offer Architect’ rebuilds your offer’s promise, pricing, angles, objections, and proof map based on ICP analysis  
	  
	3️⃣ ‘Hooksmith’ generates scroll-stopping hooks, comment magnets, and lead magnets from your offer and expertise  
	  
	4️⃣ ‘Distribution Engineer’ builds the posting, DM, and retargeting engine that pushes your message out to the right people in your network  
	  
	5️⃣ ‘Nurture Orchestrator’ runs evergreen nurture flows and proof-based follow-ups that keep leads warm and engaged  
	  
	6️⃣ ‘Conversion Closer’ maintains your booking flows, follow-ups, and call scripts so every lead stays in your orbit  
	  
	It benefits from Sonnet 4.5’s extended memory and thinking capabilities…  
	  
	Each team member feeds its findings to the other team members.  
	  
	They all operate autonomously in a self-improving loop…  
	  
	We’ve helped Founders cut their research and ad spend by 90% using this team.  
	  
	Now we’re sharing the prompts behind it with everyone  
	  
	Want it to run your marketing?  
	  
	✅ Comment “TEAM”  
	✅ Connect with me and [Lasse Flagstad](https://www.linkedin.com/in/lasse-flagstad/) and we’ll send you the prompts  
	  
	🎁 BONUS: Repost and we’ll also give you access to our full Claude Business Suite (GTM planning, Sales, Marketing, and Offer prompts)
- ## Feed post number 18
	These prompts do $20,000 of marketing in 15 minutes  
	(They're free)  
	  
	It's been a month since Claude's latest model dropped (Sonnet 4.5)  
	  
	My partner's been relentlessly running it to do his marketing  
	  
	It cut down his marketing and research spending by 90%  
	  
	He built a fully autonomous marketing team, all powered by Sonnet 4.5  
	  
	Here's what it does:  
	1️⃣ Locates hidden demand in your network and pinpoints your ICP and their buying triggers  
	  
	2️⃣ Drafts offers that hit nerve points powered by the buyer voice and data it surfaces  
	  
	3️⃣ Builds momentum with value-driven lead magnets that turn curiosity into warm conversations  
	  
	4️⃣ Handles content drops, DMs, and runs retargeting loops that never sleep  
	  
	5️⃣ Holds your ICP's attention with authentic proof, story-driven follow-ups, and trust-building nurture flows  
	  
	He's generated 8,000 leads in under two months using this team  
	  
	It all runs inside Claude and costs $0 to run  
	  
	I have his permission to share the prompts he used to build this team  
	  
	Want them?  
	  
	  
	✅ Comment "CLAUDE"  
	✅ Connectt with me and [Lasse Flagstad](https://www.linkedin.com/in/lasse-flagstad/) and we'll send you the prompts  
	  
	🎁 BONUS: Repost and we'll also give you access to his full Claude B2B suite (GTM planning, Marketing, Offer Creation)
- ## Feed post number 19
	This prompt stack turns Claude into a full marketing department  
	(It's free)  
	  
	When Claude released its latest model last month, everyone was crazy about its extended thinking and stamina  
	  
	But my partner saw the real potential in its memory  
	  
	He could integrate multiple prompts and have them work together like a real team  
	  
	So he put together his top 6 marketing prompts into one collaborative stack  
	  
	Here's what it does:  
	1️⃣ Defines your ICP, maps demand pockets, and validates the channels that actually convert  
	  
	2️⃣ Builds your offer with promise, proof, pricing, and angles that stand out from the competition  
	  
	3️⃣ Fills your content calendar with hooks, lead magnets, and high-value assets based on your offer  
	  
	4️⃣ Launches, tracks, and optimizes your posts, DMs, and retargeting engine for a consistent flow of leads  
	  
	5️⃣ Keeps leads engaged with proof-driven follow-ups and evergreen nurture sequences. (No human input needed)  
	  
	6️⃣ Maintains your booking flow and follow-ups to increase conversion (37% higher closing rates)  
	  
	He's helped solopreneurs run entire marketing operations using this prompt stack  
	  
	It's how he took a business to $14k MRR in under 2 months  
	  
	He's given me permission to share the full prompt stack  
	  
	Want it?  
	  
	✅ Comment "STACK"  
	✅ Connect with me and [Lasse Flagstad](https://www.linkedin.com/in/lasse-flagstad/) and we'll send it to you  
	  
	🎁 BONUS: Repost and we'll also give you access to his full Claude Sonnet 4.5 prompt library
- ## Feed post number 20
	These 4 prompts booked 27 calls in 10 days  
	(They're free)  
	  
	My partner engineered a prompt stack that does all his marketing for free  
	  
	Here's how:  
	1️⃣ Prompts find your ideal buyers, map pain clusters, and identify channels where attention converts  
	  
	2️⃣ Build a magnetic offer around those insights and use them to craft angles, pricing, and fill it with proof stacks  
	3️⃣ Write hooks, DMs, and content that only pulls your ICP  
	  
	4️⃣ Autonomously handle your booking flows and follow-ups while converting curiosity into calls  
	  
	The prompts are powered by Claude's latest model (Sonnet 4.5)  
	  
	They work independently in a self-improving loop  
	  
	Each prompt feeds its findings to the other prompts to constantly improve their output  
	  
	They've helped my partner and his clients cut down marketing costs by 90%  
	  
	Now he's given me permission to share them with everyone  
	  
	Want them?  
	  
	✅ Comment "MARKETING"  
	✅ Connect with me and [Lasse Flagstad](https://www.linkedin.com/in/lasse-flagstad/) and we'll send them to you  
	BONUS: Repost and we'll also send you his GTM planning prompt stack
- ## Feed post number 21
	These Claude prompts build an autonomous marketing team  
	(Steal them)  
	  
	My partner built a 3-member marketing team inside Claude  
	  
	Here's what it does:  
	1️⃣ The Analyst scans your market, identifies ICPs, and finds real buyer pains straight from Reddit and Substack boards  
	  
	2️⃣ The Architect rebuilds your offer based on those insights. You get a sharper promise, better pricing, and objection counters  
	  
	3️⃣ The Storyteller builds a full content plan out of your offer complete with lead magnets and DM scripts that pull leads on autopilot  
	  
	He's helped founders book 27+ calls in under 2 weeks using this team  
	  
	I have his permission to share it with more founders  
	  
	Want to "hire" this team?  
	  
	✅ Comment "PROMPTS"  
	✅ Connect with me and [Lasse Flagstad](https://www.linkedin.com/in/lasse-flagstad/) and we'll send you the prompts  
	  
	🎁 BONUS: Repost and we'll also give you access to his full prompt directory (120+ Prompts)
- ## Feed post number 22
	Atlas has killed Chrome  
	Yes I said it. Here’s how I use it to do better B2B marketing  
	  
	I’ve replaced every tab, extension, and research tool with prompt chains that run inside ChatGPT’s Atlas browser.  
	  
	It’s basically a built-in marketing ops assistant.  
	  
	Here’s what I use:  
	  
	1️⃣ AdSpyder → Opens any competitor’s ad library and breaks down the angles, CTAs, and emotional hooks behind their top performers.  
	  
	2️⃣ PageDoctor → Audits landing pages live in-browser, flags trust gaps and weak flow, and rewrites headlines + CTAs for higher conversions.  
	  
	3️⃣ VoiceMiner → Scans Trustpilot or G2 reviews and extracts copy angles, objections, and testimonials straight from customer language.  
	  
	These chains have helped my clients cut 90% of their marketing research time - just by switching browsers.  
	  
	Want the exact prompts?  
	✅ Comment “BROWSER”  
	✅ Connect with me and [Harald Røine](https://www.linkedin.com/in/haraldroine/)  
	✅ Get it on this link:[https://lnkd.in/g8AEEXTQ](https://lnkd.in/g8AEEXTQ)  
	  
	(I check that you’re connected and commented)  
	  
	BONUS: Repost this and I'll also give you my AI sales assistant prompts that have increased my closing rate from 20% -> 30%.
- ## Feed post number 23
	We built something absolutely ridiculous.  
	An AI Sales Assistant that closes your calls for you 😳  
	  
	It does everything.  
	→ Researches your audience (Reddit-level deep)  
	→ Extracts your offer positioning  
	→ Builds a custom sales playbook  
	→ Prepares full pre-call briefings  
	→ Coaches you live in the meeting  
	  
	All you do is copy the prompts, add your context, and watch it work.  
	  
	It’s wild.  
	  
	Clients have been sending screenshots mid-call like “bro it’s actually selling for me.”  
	  
	Took us forever to write this out, and I’m giving it away for free.  
	  
	✅ Comment "BATMAN" + like + connect with [Lasse Flagstad](https://www.linkedin.com/in/lasse-flagstad/) and myself and I’ll send the full guide.  
	  
	\---  
	  
	Access it here:[https://lnkd.in/dgPUAP\_2](https://lnkd.in/dgPUAP_2)
- ## Feed post number 24
	This setup generated 4,000+ leads from one Notion page  
	(It's free)  
	  
	My partner designed a process that turned his expertise into high-value B2B assets  
	  
	Here's how it works:  
	  
	  
	1️⃣ Start with one Notion page. Write it as if you're advising a friend, raw value and no fluff  
	  
	2️⃣ Drop a teaser post on LinkedIn asking people to comment for access to that page  
	  
	3️⃣ The page gives real insight first, creating a bond and building trust that ads can't buy  
	  
	4️⃣ Follow-up and nurture stacks keep commenters in your pipeline on autopilot  
	  
	Posts about these pages trigger the algorithm (200+ organic leads per post)  
	  
	He's built 100+ pages  
	  
	Each page generated 4000+ leads  
	  
	I'm helping him share the full process  
	  
	Want it?  
	  
	✅ Comment "NOTION"  
	✅ Connect with me and [Harald Røine](https://www.linkedin.com/in/haraldroine/) and we'll send it to you  
	  
	🎁 BONUS: Repost and we'll also send you his viral LinkedIn post prompts
- ## Feed post number 25
	These prompts rebuild your offer with Sonnet 4.5  
	(30%+ Conversions with Claude’s latest model)  
	  
	My mentor built a B2B offer creation protocol  
	  
	It’s a Sonnet 4.5 prompting sequence that:  
	1️⃣ Analyzes buyer psyche, Reddit threads, and competitor data, then pulls exact phrases, frustrations, and success stories from this data  
	2️⃣ Uses it to build a 3-tier value stack with foundation, enhancements, and risk reversal layers built using your own insights  
	  
	It’s how he built offers that had 30%+ conversion rates in under an hour  
	  
	His clients used this system to cut down on research costs and lead booking time  
	  
	These offers booked 27 calls in 5 days so far  
	  
	I have permission to share the prompt sequence behind them  
	  
	Want it?  
	  
	✅ Comment “OFFER”  
	✅ Connect with me and [Harald Røine](https://www.linkedin.com/in/haraldroine/) and we’ll send them to you  
	  
	🎁 BONUS: Repost and we’ll also send you his full Claude-powered Business Suite
- ## Feed post number 26
	These Claude prompts changed sales forever  
	(Sonnet 4.5 sales prompts)  
	  
	My mentor built a prompt stack that turned Claude’s latest model into a full sales agent  
	  
	Here’s how it works:  
	  
	  
	1️⃣ Finds real buyer pain on Reddit  
	  
	2️⃣ Extracts your product’s full structure, then builds a clean offer doc  
	  
	3️⃣ Merges both into a ready-to-close playbook that converts  
	  
	It tripled his call prep speed and raised his closing rate with no additional cost  
	  
	These prompts helped his clients go to $12,000 MRR in under 2 months  
	  
	Now he’s letting me share them with everyone  
	  
	Want to use them for your sales?  
	✅ Comment “AGENT”  
	✅ Connect with me and [Lasse Flagstad](https://www.linkedin.com/in/lasse-flagstad/) and we’ll send you the prompts  
	  
	🎁 BONUS: Repost and we’ll also send you his personal B2B lead gen setup
- ## Feed post number 27
	I cracked how to save our sales team 20 hours a week.  
	(It’s easier than you think)  
	  
	For the past 14 years, I’ve built system to automate growth.  
	  
	After testing countless tactics, strategies and “secrets”, there’s 1 thing we all need.  
	  
	👉 A way to qualify if someone is qualified or not.  
	  
	That’s why I built a system to do just this.  
	  
	This is how it works:  
	  
	1️⃣ If you’re active on LinkedIn, it will identify everyone that engages with your profile and content.  
	  
	2️⃣ It will learn more about every single one, their company, what they do, and what they sell.  
	  
	3️⃣ Then identify and qualify everyone according to who YOUR ideal client is.  
	  
	4️⃣ You’ll be notified when someone matches your ICP, similar to how you have tools notifying you if your target audience visits your website - but just for LinkedIn.  
	  
	This is 100% safe to use.  
	  
	And it will severely improve your sales performance.  
	  
	Stop wasting time on unqualified leads, and spend time on those who are qualified - and already engaging with you on LinkedIn.  
	  
	Want me to send it over, with a full tutorial?  
	  
	✅ Comment “Q” and I’ll send it over  
	  
	(PS. Remember to follow and connect with me, as that’s needed for me to send over)  
	  
	♻️ Repost, and I’ll also send over a few other automation systems to help you create the content your ideal client can engage with.
- ## Feed post number 28
	This prompt sequence does $500,000 market research in 10 minutes  
	(They're free)  
	  
	My partner built a McKinsey-level market researcher powered by Claude's latest model  
	  
	Here's how it works:  
	  
	1️⃣ SonnetPsych scans Reddit, Quora, and niche forums to extract 25 real, emotionally loaded quotes from your target audience  
	  
	2️⃣ SonnetPsych-Exec rebuilds that data into a full psychological profile that maps their fears, beliefs, and contradictions  
	  
	3️⃣ SonnetPsych-Blacksite converts those insights into conversion triggers andcopy angles  
	  
	It delivers in 10 minutes what top consultancies take weeks to draft  
	  
	High end market research shouldn't be locked behind insane costs  
	  
	That's why I'm helping him share it with everyone  
	  
	Want it?  
	✅ Comment "PROMPTS"  
	✅ Connect with me and [Lasse Flagstad](https://www.linkedin.com/in/lasse-flagstad/) and we'll give you access to it  
	  
	🎁 BONUS: Repost and we'll also share his GTM plan prompts with you
- ## Feed post number 29
	These prompts do weeks of market research in minutes  
	(Steal them)  
	  
	My partner built an audience researcher powered by Sonnet 4.5  
	  
	Here's how it works:  
	  
	1️⃣ You input your audience, their struggle, and what you sell.  
	  
	2️⃣ Sonnet 4.5 does a real-time deep dive across Reddit, X, YouTube, Quora.  
	  
	3️⃣ It builds a 10-page psychographic profile covering what drives them, what they blame, what they secretly want  
	  
	It's self-feeding and self-improving, each pass goes deeper until it feels like an unfair advantage  
	  
	It's helped his clients get weeks of results in a few hours  
	  
	I have his permission to share it  
	  
	Want it?  
	  
	✅ Comment "ADVANTAGE"  
	✅ Connect with me and [Lasse Flagstad](https://www.linkedin.com/in/lasse-flagstad/) and we'll share it with you  
	  
	🎁 BONUS: Repost and we'll also share his full Claude business suite with you (Research, GTM planning, and Marketing)
- ## Feed post number 30
	We just released our own Sonnet 4.5 business suite  
	(Research + GTM + Marketing)  
	  
	We built a prompt sequence that turns Claude into a full B2B Command Center  
	  
	1️⃣ It runs deep market + psychographic research; in minutes  
	  
	2️⃣ Builds new offers + GTM plans based on that data: replacing $20K+ strategy decks with real buyer intelligence  
	  
	3️⃣ Writes posts, emails, and pitch decks automatically (we generated 8M+ impressions in 3 months from our internal tests)  
	  
	4️⃣ Breaks down your CRM + pipeline and highlights close blockers (it lifted closing rates past 35%)  
	  
	It saved our Team and our clients $600,000+ in marketing and research expenses...  
	  
	Now we're sharing it with everyone, for free.  
	  
	Want it?  
	✅ Comment "SUITE"  
	✅ Connect with me and [Lasse Flagstad](https://www.linkedin.com/in/lasse-flagstad/) and we'll send it to you  
	  
	🎁 BONUS: Repost and we'll also share our latest B2B lead-gen setup with you
- ## Feed post number 31
	You can close 37% more clients with these Claude prompts  
	(Sonnet 4.5 B2B Offer prompts)  
	  
	My partner used Claude's latest model to rebuild his offers  
	  
	It helped him close 37% more clients in under 2 weeks  
	  
	He uses a prompt sequence powered by Claude's Sonnet 4.5 model  
	  
	Here's how it works:  
	  
	1️⃣ Scans Reddit, forums, and YouTube to map your buyers' psychology  
	  
	2️⃣ Studies your competitors' pricing, positioning, and messaging to expose gaps your new offer can fill  
	  
	3️⃣ Builds a full 5-layer value stack with bonuses, risk reversals, urgency, and category positioning  
	  
	It all happens in under 1 hour  
	  
	He's helped his clients close more deals and boost their conversions just by rewriting their offers with these prompts  
	  
	I finally have his permission to share this sequence with everyone  
	  
	Want to run it on your offers?  
	✅ Comment "SEQUENCE"  
	✅ Connect with me and [Harald Røine](https://www.linkedin.com/in/haraldroine/) and we'll send it to you  
	  
	BONUS: Repost and we'll also send you his full Claude Business Suite (GTM planning, Marketing team, and Sales Agent)
- ## Feed post number 32
	These prompts run your marketing with Claude  
	(Full Sonnet 4.5 marketing team)  
	  
	  
	It's been 30 days since Claude's latest model dropped  
	  
	Its endurance and memory made collaboration possible  
	  
	So my partner built a full collaborative team powered by it  
	  
	Here's how it works:  
	  
	1️⃣ Market Research Lead goes through Reddit, communities, and LinkedIn to surface real customer pains and language. It maintains a flow of verified data into your funnel  
	  
	2️⃣ Offer Strategist converts those pains into offers that sell themselves using the Value Equation. It sharpens your positioning and lowers friction  
	  
	3️⃣ Content Lead writes hooks, headlines, and short-form posts that match your ICP's voice. You end up with more scroll-stops and higher engagement  
	  
	4️⃣ Channel Manager packages and schedules everything across LinkedIn, X, and Email  
	  
	5️⃣ Lifecycle Marketer builds follow-ups, DMs, and proof sequences that nurture interest  
	  
	6️⃣ Conversion Manager creates landing copy, objection counters, and call scripts  
	  
	It takes 40 minutes to set up (live campaigns go out on the same day)  
	  
	My partner built it for founders who wanted to cut down on marketing costs without compromising on visibility  
	  
	Now he's letting me share it with more people  
	  
	Want it?  
	✅ Comment "TEAM"  
	✅ Connect with me and [Lasse Flagstad](https://www.linkedin.com/in/lasse-flagstad/) and we'll give you access to it  
	  
	🎁 BONUS: Repost and we'll also send you his full Claude GTM planning prompts
- ## Feed post number 33
	Offers built with these prompts have 35%+ closing rate  
	(Sonnet 4.5 offer prompts)  
	  
	My partner turned Claude’s latest model into an offer architect  
	  
	Here’s how it works:  
	1️⃣ Maps your market’s fears, beliefs, and desires from real conversations to output a genuine customer voice  
	  
	2️⃣ Studies competitor pricing and messaging to pinpoint a gap you can own  
	  
	3️⃣ Renames your offer into a new category. The goal is to rebrand it as the leader in its category  
	  
	4️⃣ Runs your offer through 5 risk types and handles all those objections before the call  
	  
	5️⃣ Adds urgency to your offer with FOMO, tiered systems, and a high value-stack  
	  
	He’s helped his clients raise their closing rates by 27-35% using these prompts  
	  
	I have his permission to share it with more founders for free  
	  
	Want to tweak your offer with them?  
	  
	✅ Comment “OFFER”  
	✅ Connect with me and [Harald Røine](https://www.linkedin.com/in/haraldroine/) and we’ll send them to you  
	🎁 BONUS: Repost and we’ll also send you his Sonnet 4.5 GTM plan builder prompts
- ## Feed post number 34
	I cracked how to sell services to large businesses using AI-driven marketing  
	(It’s easier than you think)  
	  
	For the past 5 years I have been meticulously obsessing over how to market and sell B2B services.  
	  
	After testing hundreds of small and large tactics, there’s just 1 universal truth.  
	  
	— You need to build trust to sign the deal.  
	  
	After years of testing, this is how to best approach it:  
	  
	\## 1️⃣ - Target them as good as possible.  
	Your problem will always be that you can’t 100% identify the specific decision maker.  
	There will always be more people involved in the decisions - embrace this.  
	Use Deep Lookup to deploy thousands of AI agents across the web to build your list.  
	  
	\## 2️⃣ - Approach them without pitches  
	Since we’re reaching out to more people than the end decision maker, we don’t want to pitch.  
	Instead we make the outbound focused on building a positive association to our brand.  
	  
	\## 3️⃣ - Nurture them automatically  
	Set up automations on the backend to ensure everyone that engages with you gets added to email and ad nurturing.  
	We use encharge and meta for this.  
	  
	\## 4️⃣ - Track their signals  
	Make an AI algorithm to track who engages with your nurturing.  
	Using this we make a list of prospects with high signal that we should reach out to 1-1 and sell to.  
	  
	When you get to this point what you’ll experience is that the lead already knows you - and it mimics a referral-style sale as trust is already established.  
	  
	We’ve been working on this system for years, today I’ll share my Enterprise Blueprint with you.  
	  
	If you want to see under the carpet and duplicate this process to sell more:  
	✅ Comment “LARGE”  
	✅ Connect with me + [Harald Røine](https://www.linkedin.com/in/haraldroine/)  
	  
	♻️ Repost and I’ll also hand you access to 4 prompts you can use to automate the content creation in your nurturing.
- ## Feed post number 35
	These prompts do McKinsey-BCG-Bain market research  
	I’m sharing them for free  
	  
	My partner built a market research system powered by GPT-5  
	  
	He wanted to cut down on market research costs  
	  
	He ended up with a system that does McKinsey-level market research  
	  
	1️⃣ It studies Reddit, G2, YouTube, X, then collects verbatim quotes with emotion tags and citations  
	  
	2️⃣ It uses psychographics to know what motivates them, then builds segments, objections, and triggers straight from their language  
	  
	3️⃣ Writes copy and positioning lines based on their inner monologue  
	  
	4️⃣ Generates a live Google / LinkedIn X-ray then scores and exports real ICP prospects  
	  
	A single run helped his clients generate 7,000-11,000 leads per week on LinkedIn  
	  
	It increased his closing rate by 35%  
	  
	It’s built fully within ChatGPT and runs at $0 cost  
	  
	We both agree, high quality market research shouldn’t be gated behind a six-figure price tag  
	  
	So I’m helping him share it with more founders  
	  
	Want to run your market research with it?  
	✅ Comment “MARKET”  
	✅ Connect with me and [Harald Røine](https://www.linkedin.com/in/haraldroine/) and we’ll send it to you  
	🎁 BONUS: Repost and we’ll also send you his GPT-5 marketing team prompts
- ## Feed post number 36
	$23K+ MRR in 4 months.  
	30,000+ leads captured in 27 days ($0 ad spend setup)  
	  
	My partner turned his LinkedIn profile into a lead engine.  
	  
	He built a set of prompts that turned his experience and process into high-value assets — then gave them away for free.  
	  
	It created reciprocity. Then it sparked conversations.  
	  
	The leads don’t feel pitched.  
	  
	The content educates first — then leads naturally to a sale.  
	  
	That’s how he generates 30,000+ leads a month.  
	  
	We used the same system to help other founders generate 7,000+ leads from their first 3 posts.  
	  
	Now I'm sharing the full prompt + setup guide for this system.  
	  
	Want it?  
	  
	✅ Comment “PROFILE”  
	✅ Follow me and [Lasse Flagstad](https://www.linkedin.com/in/lasse-flagstad/), and we’ll send it over  
	  
	BONUS: Repost this, and we’ll also share his entire asset library with you.
- ## Feed post number 37
	Claude Business Suite just dropped  
	(Full Sonnet 4.5 business scaling stack)  
	  
	My partner built a full B2B growth system powered by Claude's latest model  
	  
	It's a series of prompts that:  
	1️⃣ Do deep market + psychographic research in minutes  
	  
	2️⃣ Build offers + GTM plans from live buyer data ($20,000 planning for free)  
	  
	3️⃣ Write content, emails, and decks automatically (8 million impressions in 3 months)  
	  
	4️⃣ Run sales analysis + closing workflows (35%+ closing rates)  
	  
	I have his permission to share the full Claude Business Suite  
	  
	Want it?  
	✅ Comment "SUITE"  
	✅ Connect with me and [Lasse Flagstad](https://www.linkedin.com/in/lasse-flagstad/) and we'll send it to you  
	  
	BONUS: Repost and we'll also give you full access to his prompt library
- ## Feed post number 38
	This is the craziest offer-creation system I’ve ever seen  
	(35%+ closing rate with Sonnet 4.5)  
	  
	My mentor used Claude’s latest model to rebuild his offer  
	  
	It increased his closing rate by 35%  
	  
	Here’s how it did that:  
	  
	1️⃣ Pulled real conversations from Reddit and forums to find what his buyers actually believe, then use that to simulate their own patterns  
	  
	2️⃣ Compared his offer to every competitor’s pricing and messaging then renamed his service into its own category so it becomes the only option  
	  
	3️⃣ Combined all the data into a 3-tier offer with built-in urgency and risk reversals  
	  
	These Claude prompts helped him triple conversions for his clients  
	  
	Now he’s letting me share them with even more founders  
	  
	Want to rebuild your offer with them?  
	  
	✅ Comment “REBUILD”  
	✅ Connect with me and [Lasse Flagstad](https://www.linkedin.com/in/lasse-flagstad/) and we’ll send them to you  
	  
	BONUS: Repost and we’ll also send you his Sonnet 4.5 revenue generation prompt stack
- ## Feed post number 39
	These prompts took a startup to $12,000 MRR in 2 months  
	(GPT-5 Revenue Generation Prompts)  
	  
	My partner built a revenue-generating prompt chain using ChatGPT's latest model  
	  
	Here's how it works:  
	1️⃣ Finds what your buyers actually say online (Reddit, X, Quora) and rebuilds their belief map  
	  
	2️⃣ Rewrites your offer using the "Grand Slam" method to increase perceived value without lowering price  
	  
	3️⃣ Pulls conversion headlines, hooks, and objections straight from real buyer data  
	  
	4️⃣ Spots the holes in your competitors' positioning so you can differentiate yourself  
	  
	5️⃣ Engineers bonuses and first-week wins that cut down closing time  
	  
	It all runs inside ChatGPT and needs no human input  
	  
	It's how he's helped startups scale at no additional marketing/research costs  
	  
	I have his permission to share the prompts  
	  
	Want to run them for your business?  
	✅ Comment "PROMPTS"  
	✅ Connect with me and [Lasse Flagstad](https://www.linkedin.com/in/lasse-flagstad/) and we'll share them with you  
	  
	BONUS: Repost and we'll also send you his GPT-5 marketing swarm prompts ($60,000+ in new deals in under 3 months)
- ## Feed post number 40
	$23K+ MRR in 4 months. 30,000+ leads captured in 27 days.  
	($0 ad spend setup)  
	  
	My partner turned his LinkedIn profile into a lead gen engine  
	  
	He built a series of prompts that turn his experience and process into high-value assets  
	  
	Then he gave them away for free  
	  
	It built reciprocity, then it drove conversations  
	  
	His leads don't feel pitched  
	  
	His content educates, then leads toward a sale  
	  
	It's how he generates 30,000+ leads every month  
	  
	He's used this same setup to help founders generate 7,000+ leads from their first 3 posts on LinkedIn  
	  
	I have his permission to share the prompts + setup guide for this system  
	  
	Want them?  
	  
	✅ Comment "PROFILE"  
	✅ Connect with me and [Lasse Flagstad](https://www.linkedin.com/in/lasse-flagstad/) and we'll send them to you  
	  
	BONUS: Repost and we'll also share his full asset library with you
- ## Feed post number 41
	This system generates offers with 35%+ closing rate  
	(Sonnet 4.5 Offer Creator)  
	  
	My partner turned his offer creation flow into one system powered by Claude's latest model  
	  
	It helped him and his clients book 7-10 warm calls per week  
	  
	All with no ad spend  
	  
	Here's how it works:  
	1️⃣ Stores everything about your buyers. Their pains, objections, beliefs, and buying triggers  
	  
	  
	2️⃣ Studies engagement on Reddit + forums to pull the exact words your buyers use when they buy  
	  
	3️⃣ Spots competitor gaps and defines a lane you can stand out in  
	  
	4️⃣ Builds your 5-layer stack (Core, Bonus, Exclusive, Urgent, Safe) automatically  
	  
	5️⃣ Finalizes pricing, proof, and CTAs tuned for 15-35% close rates  
	  
	It's the same flow that generated $40,000 in new contracts in under 30 days  
	  
	I have his permission to share it  
	  
	Want it?  
	  
	✅ Comment "CLOSE"  
	✅ Connect with me and [Harald Røine](https://www.linkedin.com/in/haraldroine/) and we'll give you access to it  
	BONUS: Repost and we'll also give you access to his full Claude prompt library
- ## Feed post number 42
	McKinsey-Bain-BCG audience research in 10 minutes (minus the 6-figure bill)  
	(Sonnet 4.5 market research prompts)  
	  
	My partner turned Claude into an elite market researcher  
	  
	The kind McKinsey would charge you $500,000 for  
	  
	Here's how it works:  
	  
	  
	1️⃣ SonnetPsych → scans Reddit, Indie Hackers, X, and Quora for real quotes from your audience. You get unfiltered buyer thoughts, fears, frustrations, and desires.  
	  
	2️⃣ SonnetPsych-Exec → rebuilds your persona from scratch based on detected buyer thoughts.  
	  
	3️⃣ SonnetPsych-Blacksite → enhances that persona with psychological forensics.  
	  
	It's how he pays $0 in market research yet still generates 12,000+ leads every week  
	  
	I have his permission to share the full prompts + the setup guide  
	  
	Want to run it on your market?  
	✅ Comment "SONNET"  
	✅ Connect with me and [Lasse Flagstad](https://www.linkedin.com/in/lasse-flagstad/) and we'll send it to you  
	  
	BONUS: Repost and we'll also send you his Sonnet 4.5 GTM plan prompts
- ## Feed post number 43
	Claude can now build a 90-day GTM plan in <4 hours  
	(Sonnet 4.5 GTM prompts)  
	  
	A lot of founders struggle because they didn't spend that $20,000 on a GTM plan.  
	  
	So my partner built a system that builds it for free.  
	  
	Here's how it works:  
	  
	1️⃣ You feed it your business context - offer, audience, goals.  
	  
	2️⃣ It runs deep market + competitor research.  
	  
	3️⃣ Builds positioning, messaging, and content strategy.  
	  
	4️⃣ Designs your funnel, lead magnets, and nurture emails.  
	  
	5️⃣ Outputs a 90-day execution roadmap with tasks and KPIs.  
	  
	All powered by Claude's latest model (Sonnet 4.5).  
	  
	It's how he generated $17,000 in MRR in under 3 months.  
	  
	He's letting me share it.  
	  
	Want to build your GTM plan with it?  
	✅ Comment "PLAN".  
	✅ Connect with me and [Harald Røine](https://www.linkedin.com/in/haraldroine/) and we'll send it to you.  
	  
	🎁 BONUS: Repost and we'll also send you his full Sonnet 4.5 prompt archive.
- ## Feed post number 44
	We built a full marketing team powered by Sonnet 4.5  
	(and giving it away)  
	  
	Claude's latest model isn't just faster...  
	  
	Its prompts think together.  
	  
	So we built an interconnected marketing team that benefits from this model  
	  
	Here's how it works:  
	  
	  
	1️⃣ 'Signal Scout' finds ICPs, pain stacks, and hidden demand from Reddit + niche forums  
	  
	2️⃣ 'Offer Alchemist' engineers pricing, packaging, and objection counters using a proprietary Value Equation  
	  
	3️⃣ 'Story Crafter' writes hooks, campaigns, and DMs that use your buyer's language  
	  
	4️⃣ 'Growth Router' designs your posting rhythm, retargeting flows, and channel loops  
	  
	5️⃣ 'Trust Weaver' runs testimonial-backed proof drops  
	  
	6️⃣ 'Closer Core' maintains your booking flow, follow-ups, and call frameworks  
	  
	It all runs inside Claude, powered by its latest model: Sonnet 4.5  
	  
	Our Team has generated 2M+ impressions in 19 days using this team...  
	  
	Solopreneurs are running their entire marketing operations using these prompts.  
	  
	Now we're sharing them with everyone  
	  
	Want to run them for your marketing?  
	  
	✅ Comment "CLAUDE"  
	✅ Connect with me and [Lasse Flagstad](https://www.linkedin.com/in/lasse-flagstad/) and we'll send them to you  
	  
	🎁 BONUS: Repost and we'll share our full Sonnet 4.5 prompt library with you
- ## Feed post number 45
	Yesterday I turned 30. Here are 30 guides on growing your company.  
	  
	Since 2011, I’ve been obsessed about how to grow companies digitally.  
	  
	Along the way, I’ve learned a thing or two.  
	  
	And the last year I’ve created countless guides on how to do it.  
	After having helped companies generate $10M+ and reach tens of millions of people since I started.  
	  
	I’ve taking all my learnings and put them into this “30 at 30” package.  
	  
	Want them all?  
	  
	✅ Comment “30” and I’ll send them over  
	(Also, follow me on LinkedIn, for me to send over)  
	  
	Here’s a list of all guides you’ll get:  
	  
	1️⃣ B2B Protocol — The full-funnel outbound + inbound system that builds predictable, high-quality B2B pipelines on autopilot.  
	  
	2️⃣ Gravity Marketing — Attract high-intent clients without chasing them using a pull-based content and trust strategy.  
	  
	3️⃣ Inbound Protocol — Turn newsletters, webinars, and lead magnets into a 24/7 inbound machine that books meetings for you.  
	  
	4️⃣ The Big Idea™ — Craft a single, market-defining idea that makes your brand unforgettable and impossible to compete with.  
	  
	5️⃣ Notion Page Syndicate™ — Replace funnels and ads with one trust-led Notion page that turns readers into clients.  
	  
	6️⃣ 10-Minute AI Team ($20K System) — Build a ChatGPT-powered copy team that creates world-class marketing assets in minutes.  
	  
	7️⃣ Perpetual LinkedIn Engine — Turn your LinkedIn into a self-funding inbound engine that drives leads and sales daily.  
	  
	8️⃣ Viral Lead Magnets (in 60 Minutes) — Create scroll-stopping, conversation-starting lead magnets fast—with AI.  
	  
	9️⃣ Winning B2B Deals with AI + Love — Close premium clients through authenticity, generosity, and long-term trust.  
	  
	🔟 Non-Spammy LinkedIn Outbound — Book meetings with thoughtful, value-first DMs that actually get replies.  
	  
	Sold?  
	  
	✅ Comment "30" and get them  
	  
	\---  
	Here are the next 5:  
	  
	1️⃣1️⃣ Your AI Sales Assistant v2 — Let AI coach your sales calls, sharpen your scripts, and help you close faster.  
	  
	1️⃣2️⃣ McKinsey-Level Audience Researcher — Discover what truly drives your buyers using deep AI-powered psychographic research.  
	  
	1️⃣3️⃣ GPT-5 Automated Our Company — Learn how to automate your business step by step—from SOPs to full company systems.  
	  
	1️⃣4️⃣ YouTube Repurposing System (n8n Template) — Automatically turn YouTube videos into fresh, tailored content every week.  
	  
	1️⃣5️⃣ LinkedIn Post Analyzer (n8n Template) — Reverse-engineer viral posts and recreate them in your own brand voice.  
	  
	What about now?  
	  
	Sold, drooling thinking about them?  
	  
	✅ Like & comment "30" below, and I'll send them all over to you.  
	  
	(I couldn't share all because of max characters for this post)  
	  
	\---  
	  
	Access here:[https://lnkd.in/d-NTGMKK](https://lnkd.in/d-NTGMKK)
- ## Feed post number 46
	I use these Sonnet 4.5 prompts to do McKinsey level audience research for free  
	Comment “HERE” and I’ll share them  
	  
	…over the past 24 months I have battle tested and studied how to best prompt AI.  
	  
	As a result of this I have mapped out a model for prompting that turn an AI’s perceived IQ level up from 110 to 140.  
	  
	When using these types of prompts you feel like you have a $300K/year consultant in your team.  
	  
	After 24 months of prompt creation - there’s one unique prompt chain that tops my list… I literally can’t live without this anymore.  
	  
	It requires you to answer 3 short questions about your business:  
	— who you sell to  
	— what their problems are  
	— what you sell  
	  
	After this it spends up to 25 minutes scraping hundreds of webpages to learn about your audience.  
	  
	It figures out how your audience thinks in ways that are extremely difficult to do on your own.  
	  
	Because the AI can keep all of these sources in mind at the same time.  
	  
	Take these prompts and use them for your own business, but also for the businesses of all your leads and clients. They’ll be overly impressed by your understanding of their business, and you will make more money as a result.  
	  
	I will share them with you if you:  
	✅ Comment “HERE”  
	✅ Connect with me & [Harald Røine](https://www.linkedin.com/in/haraldroine/)  
	✅ Access it at this link:[https://lnkd.in/g8AEEXTQ](https://lnkd.in/g8AEEXTQ)  
	  
	PS: If you also repost this I will share 6 other prompts I use to have Sonnet 4.5 help me during my sales calls.
- ## Feed post number 47
	These prompts add 6 free members to your marketing team  
	(Sonnet 4.5 marketing prompts)  
	  
	My partner built a full marketing department inside Claude Sonnet 4.5  
	  
	Here's how it works:  
	1️⃣ Mapper → maps ICPs, pain stacks, and demand channels (Reddit, forums, LinkedIn) to give data-driven clarity  
	  
	2️⃣ Shaper → builds irresistible offers, pricing logic, and objection counters so you can add sellable angles to your ideas  
	  
	3️⃣ Scrollstopper → writes scroll-stopping hooks and opt-ins for each channel so your lead magnets convert  
	  
	4️⃣ Distributor → packages and schedules content across LinkedIn, X, and Email to keep your brand visible 24/7  
	  
	5️⃣ Orchestrator → builds proof-based email and DM sequences to keep warm leads moving toward a call  
	  
	6️⃣ Closer → optimizes your booking flow and follow-ups to turn conversations into clients  
	  
	It's a full marketing department that lives inside Claude, powered by its latest model  
	  
	Each member feeds its findings to the other members in a self-improving loop  
	  
	This team helped founders generate 6,000+ leads each month at no additional marketing cost  
	  
	I have permission to share the full prompts behind it  
	  
	Want them?  
	✅ Comment "TEAM"  
	✅ Connect with me and [Lasse Flagstad](https://www.linkedin.com/in/lasse-flagstad/) and we'll send you the prompts  
	  
	BONUS: Repost and I'll share his full GTM plan prompts (also powered by Sonnet 4.5)
- ## Feed post number 48
	Cutting 90% of marketing costs with ChatGPT Atlas  
	(Free browser prompts)  
	  
	My mentor turned ChatGPT Atlas into a marketing expert that:  
	1️⃣ Studies competitor campaigns to find the angles, proof, and CTAs they use to convert  
	  
	2️⃣ Audits your landing pages to spot friction, clarity gaps, and rewrites sections for conversion  
	  
	3️⃣ Scans buyer insights, then pulls real customer language from reviews to shape your messaging  
	  
	These three prompts helped him and his clients cut 90% of marketing costs  
	  
	It all happens inside ChatGPT’s Atlas browser, and it’s all free  
	  
	I got his permission to share the browser prompts  
	  
	Want them?  
	✅ Comment “PROMPTS”  
	✅ Connect with me and [Lasse Flagstad](https://www.linkedin.com/in/lasse-flagstad/) and we’ll send you the prompts  
	  
	BONUS: Repost and get his full breakdown of Atlas’s features for B2B founders
- ## Feed post number 49
	I've been getting a lot of DMs asking for this  
	(Claude B2B offer prompt stack)  
	  
	My partner built a full offer creation system powered by Claude Sonnet 4.5  
	  
	It's a 3-layer system that increased his conversion rate by 35%+  
	  
	Here's how it works:  
	1️⃣ Insight Layer  
	👉 Claude analyzes your ICP, competitors, and customer language to find hidden pain points and untapped angles  
	  
	2️⃣ Offer Layer  
	👉 Claude rewrites your positioning and value prop into 3 offer variants that cater to your audience segments  
	  
	3️⃣ Proof Layer  
	👉 Claude stress-tests your new offer against objections, credibility gaps, and real market data  
	  
	You end up with a precise map of what your buyers really care about backed by guarantees and a conversion-ready pack  
	  
	He's helped founders reach a 25-37% higher closing rate with this stack's offers  
	  
	Now I'm helping him share it with more founders  
	  
	Want to build your offers with it?  
	✅ Comment "BUILD"  
	✅ Connect with me and [Harald Røine](https://www.linkedin.com/in/haraldroine/) and we'll send you the prompt stack  
	  
	BONUS: Repost and I'll also send you his full Sonnet 4.5 prompt directory
- ## Feed post number 50
	My mentor built a $3.5M pipeline from a single Notion page  
	Here’s how he did it:  
	  
	He engineered a Notion system that turned his expertise into trust-generating assets  
	  
	He stopped making “perfect” PDFs and wrote like he talks. That authenticity created intimacy  
	  
	He gives the map (Notion page) for free. Prospects feel invited, not sold  
	  
	Every post offering the page feeds the algorithm. It generated 200-4000+ new leads per drop  
	  
	Each Notion page he builds works on its own  
	  
	He’s built 100+ pages and 700+ posts over the past 4 months  
	  
	It’s how he consistently generated 9-12,000+ leads every month  
	  
	I have his permission to share the page building prompts he uses  
	  
	Want to build your own Notion assets?  
	Comment “NOTION”  
	Connect with me and [Harald Røine](https://www.linkedin.com/in/haraldroine/) and we’ll send you the prompts  
	  
	BONUS: Repost and I’ll also send you his full Notion asset directory
- ## Feed post number 51
	Your browser can now do your marketing  
	(ChatGPT browser prompts)  
	  
	My partner built a prompt chain that turns ChatGPT’s Atlas browser into a marketing expert  
	  
	Here’s how it works:  
	1️⃣ AdBreakdown → Studies any competitor’s ad library live inside the browser and picks up on emotional triggers and CTAs that work  
	  
	2️⃣ PagePulse → Audits your landing pages in real time and pinpoints trust gaps, weak proof, and bad flow, then rewrites headlines, CTAs, and structure for higher conversions  
	  
	3️⃣ ReviewRadar → Reads Trustpilot or G2 reviews for your brand (or competitors) and turns them into copy angles and testimonials  
	  
	He’s helped founders cut 90% of marketing research costs just by switching browsers  
	  
	I got his permission to share the prompts  
	  
	Want them?  
	✅ Comment “EXPERT”  
	✅ Connect with me and [Lasse Flagstad](https://www.linkedin.com/in/lasse-flagstad/) and we’ll send you the prompts  
	  
	BONUS: Repost and I’ll also send you his full GPT-5 and Claude Sonnet 4.5 prompt library
- ## Feed post number 52
	Your browser can now be a marketing team member  
	(Atlas browser prompts)  
	  
	My partner built a marketing prompt pack for ChatGPT's Atlas browser  
	  
	It cut his marketing costs by 90% in 3 days  
	  
	Here's how:  
	  
	  
	1️⃣ Gave him ad intelligence  
	It broke down every competitor's ad, their angles, emotions, and CTAs, then revealed exactly why they convert (and how to beat them)  
	  
	2️⃣ Optimized his landing pages  
	It audited his landing pages, rewrote the hero copy, repositioned proof, and plugged 3 conversion leaks in under an hour  
	  
	3️⃣ Gave him buyer insights  
	It pulled real buyer language from live reviews and highlighted pains and triggers  
	  
	The prompts saved him thousands in consultancy fees and copy research  
	  
	He's helped his clients cut marketing costs by 90% with Atlas  
	  
	I have his permission to share these prompts with more people  
	  
	Want to turn your browser into a marketing professional?  
	  
	✅ Comment "EXPERT"  
	✅ Connect with me and [Lasse Flagstad](https://www.linkedin.com/in/lasse-flagstad/) and we'll send you the prompts  
	  
	BONUS: Repost and get his full breakdown of Atlas for B2B founders
- ## Feed post number 53
	This prompt stack builds a 6-person marketing team  
	(Sonnet 4.5 prompts)  
	  
	My partner built a full marketing team that lives inside Claude  
	  
	It's powered by Sonnet 4.5 + 6 prompts  
	  
	Here's what they do:  
	  
	1️⃣ The Researcher prompt maps your market, ICPs, and competitor positioning in minutes  
	  
	2️⃣ The Strategist prompt builds your messaging, offer hierarchy, and GTM motion  
	  
	3️⃣ The Copy Chief prompt crafts high-converting headlines, hooks, and CTAs  
	  
	4️⃣ The Content Director prompt turns strategy into a 90-day calendar across channels  
	  
	5️⃣ The CRO Analyst prompt audits landing pages, rewrites flows, and fixes conversion leaks  
	  
	6️⃣ The CMO Brain prompt reviews, refines, and assembles it all into one GTM execution plan  
	  
	They all operate inside the same Claude project  
	  
	Each team member feeds the other members its output  
	  
	All members think and execute like a real, connected marketing department  
	  
	These prompts helped founders generate 7,000+ leads in under 2 weeks  
	  
	I got his permission to share them with more founders  
	  
	Want to use them for your marketing?  
	  
	✅ Comment "TEAM"  
	✅ Connect with me and [Lasse Flagstad](https://www.linkedin.com/in/lasse-flagstad/) and we'll share the prompts with you  
	  
	🎁 BONUS: Repost and we'll also send you his Claude GTM planner prompts
- ## Feed post number 54
	This is the wildest GTM system I've ever seen  
	(Full GTM plan in 10 minutes with Sonnet 4.5)  
	  
	My partner built a full GTM orchestration system  
	  
	It's a 5-layer prompt stack that:  
	  
	1️⃣ Defines ICPs, analyzes competitors, and surfaces real buyer pains from live data  
	  
	2️⃣ Crafts your value prop, key messages, and GTM motion in under 15 minutes  
	  
	3️⃣ Generates content ideas, hooks, and distribution mapped to your funnel  
	  
	4️⃣ Creates lead magnets, ad angles, email sequences, and full conversion paths  
	  
	5️⃣ Outputs your 90-day roadmap with owners, KPIs, and budget  
	  
	All powered by Sonnet 4.5  
	  
	It takes 10 minutes to output a 90-day GTM plan  
	  
	I got his permission to share the prompts + the setup guide  
	  
	Want them?  
	  
	✅ Comment "GTM"  
	✅ Connect with me and [Harald Røine](https://www.linkedin.com/in/haraldroine/) and we'll send them to you  
	  
	BONUS: Repost and we'll also send you his full Claude Sonnet 4.5 marketing prompt stack
- ## Feed post number 55
	most b2b founders have the same paradox.  
	it’s the thing that built their business that’s now holding them back.  
	  
	— REFERRAL HANDCUFFS —  
	  
	their business became successful because they’re top tier in their craft.  
	  
	as they got better, clients started referring new business.  
	  
	they felt like kings. the best in the industry.  
	  
	until one day they saw someone objectively less skilled, producing worse results,  
	making way more money than they did.  
	  
	how could this happen?  
	  
	as they perfected their craft, they got referrals.  
	they got bloated on them, thinking they’d never need anything else.  
	  
	meanwhile, the other guy with lower skills never got bloated on referrals.  
	he didn’t have the same privilege, or the same REFERRAL HANDCUFFS.  
	  
	he had to go out and learn to market better.  
	  
	this can sound demoralizing.  
	  
	but the skilled founder still has the upper hand.  
	the provider who never became top tier will never reach the highest levels of the industry.  
	  
	because he’ll get beaten by the founder who has both the MARKETING and the SKILLS in place.  
	  
	marketing simply amplifies the impact you already have.  
	  
	because what’s inside your marketing?  
	it’s a miniature version of your service delivery in a DO IT YOURSELF format.  
	  
	moral of the story: the skilled founder has greater potential,  
	but even with better skills, he’ll lose to someone who markets well.  
	  
	if you want help removing your referral handcuffs, dm me and i'll show you how we do this for busy b2b founders
- ## Feed post number 56
	GPT-5 and projects in ChatGPT changed B2B marketing forever  
	(Prompts + GPT-5-pro + Reddit)  
	  
	I can't believe people don't talk about this.  
	  
	Combining elaborate prompts and deep research with projects inside ChatGPT.  
	  
	Why am I hyped about this?  
	  
	We can give a project out details like company, audience and our product, and it searches the web to help us find the gaps.  
	  
	I made 5 ridiculously good prompts to create B2B offers.  
	  
	1️⃣ It scrapes the web to do deep psychographic market intelligence gathering to understand what your audience truly feel and want.  
	  
	2️⃣ Scrapes relevant Reddit posts to learn what problems your audience is currently dealing with.  
	  
	3️⃣ It analyses your competition and identifies the best way for you to position your company and product.  
	  
	4️⃣ It takes all the analysis and research, and build your offer intelligence system.  
	  
	5️⃣ It puts it all together to help you craft your irresistible offer, that people feel dumb saying no to.  
	  
	It's a total game changer.  
	  
	If you want these prompts + the project setup to make this great.  
	✅ Comment "Offer"  
	✅ Follow me + [Lasse Flagstad](https://www.linkedin.com/in/lasse-flagstad/) on LinkedIn  
	  
	♻️ Repost this, and we'll set aside 30min 1-1 to optimize your offer.
- ## Feed post number 57
	ChatGPT Atlas dropped 3 days ago...  
	We turned it into a marketing expert  
	  
	The moment OpenAI announced the release of their browser, we saw its potential.  
	(and have been using Perplexity's Comet for a while)  
	  
	We've built so many marketing and sales tools with the latest models of ChatGPT...  
	  
	But they always had one thing missing.  
	  
	True LIVE interactions  
	  
	Agent mode helped us work around that  
	  
	Atlas took it to the next level  
	  
	It can interact with what you're seeing, perform actions, and engage with your webpages...  
	  
	Just like a real team member.  
	  
	So we built a prompt chain that turned it into a marketing expert  
	  
	Here's how it works:  
	  
	1️⃣ 'AdIntel-GPT' → looks at your competitor's ads and breaks them down, then suggests counter-angles that could outperform them  
	  
	2️⃣ 'CROSensei' → audits your landing page flow, runs a 3-second clarity test, then rewrites it for conversion clarity  
	  
	3️⃣ 'BuyerVoice AI' → analyzes customer reviews to uncover what people actually value, then gives you headline + messaging angles written in their own words  
	  
	Our Team has already cut marketing costs by 90% in under 3 days using Atlas + these prompts...  
	  
	Now we're sharing them with everyone.  
	  
	Want them?  
	✅ Comment "EXPERT"  
	✅ Connect with me and [Lasse Flagstad](https://www.linkedin.com/in/lasse-flagstad/) and we'll send you the prompts  
	  
	BONUS: Repost and we'll send you our full breakdown of its B2B capabilities
- ## Feed post number 58
	This AI stack replaces marketing consultancy giants  
	($500,000 market research done in minutes)  
	  
	My partner built a marketing prompt stack that does BCG, McKinsey, and Bain level market research....  
	  
	Without the six figure invoice  
	  
	Here's how it works:  
	1️⃣ SignalSweep Intelligence Engine scans the web, Reddit, and LinkedIn to extract 40-60 verbatim audience quotes. It builds a live psychographic map of pains, desires, and buying triggers  
	  
	2️⃣ CoreSync Analyzer cleans and restructures the raw findings into clear, actionable insights. You get the real audience language without the noise  
	  
	3️⃣ DeepPulse Narrative Builder converts the data into a sharp "buyer's inner-monologue" report so you know how your buyers actually think, feel, and decide  
	  
	4️⃣ VectorLead Prospector searches Google + LinkedIn to find real, high-fit prospects matching your ICP then exports qualified leads straight to CSV  
	  
	His flow helped clients cut 90% of market research costs  
	  
	It's also helped him generate 4,000 leads in under 5 days  
	  
	We both believe good market research shouldn't be gated behind six-figure retainers  
	  
	That's why I'm helping him share it with everyone for free  
	  
	Want to use it for your market research?  
	✅ Comment "MARKET"  
	✅ Connect with me and [Lasse Flagstad](https://www.linkedin.com/in/lasse-flagstad/) and we'll share it with you  
	  
	BONUS: Repost and I'll also share his GTM plan builder prompts
- ## Feed post number 59
	Building a 3.5M sales pipeline with one notion page  
	(Free 3-day setup)  
	  
	My mentor built a system that turns one Notion page into a renewable sales pipeline  
	  
	He doesn’t use ads  
	  
	He doesn’t even have a sales team  
	  
	The notion doc does all the selling for him  
	  
	His setup is replacing B2B marketing as we know it  
	  
	1️⃣ It feels personal, like a friend sharing notes, not a company pitching. The peak of trust-based design  
	  
	2️⃣ It’s his unfiltered voice, written how you’d text a client, not how your website speaks  
	  
	3️⃣ Chemical trigger → Authenticity → reciprocity → trust  
	  
	One Notion page = content, posts, lead magnets, and nurture systems all in one  
	  
	He’s generated 20,000+ leads and 700+ pieces of high-value content with one run of this setup  
	  
	I finally have his permission to share it  
	  
	Want it?  
	✅ Comment “DOC”  
	✅ Connect with me and [Harald Røine](https://www.linkedin.com/in/haraldroine/) and we’ll share it with you  
	  
	BONUS: Repost and I’ll also give you access to his full Notion resource directory
- ## Feed post number 60
	This 5-figure system generates 10,000+ leads every month  
	I’m sharing it for free  
	  
	It’s called the B2B Protocol  
	  
	My mentor put 10+ years of helping B2B founders scale into it  
	  
	It’s meant to shift companies from chasing leads and having the leads chase them instead  
	  
	Here’s how it works:  
	  
	1️⃣ LinkedIn + email work together to start warm conversations  
	  
	2️⃣ Every new lead gets 7 emails that teach what you do, zero selling involved  
	  
	3️⃣ Evergreen nurture system keeps your best insights in a loop so you stay in their minds 24/7  
	  
	4️⃣ Smartly scores when a lead engages, then flags them automatically so your team knows exactly when to reach out  
	  
	He’s helped founders generate 8M impressions in 3 months using this system  
	  
	Founders who got access to it consistently generated 10,000+ leads per month  
	  
	It’s how he closed 37 new deals in under 30 days  
	  
	He gave me permission to share it  
	  
	Want it?  
	✅ Comment “B2B”  
	✅ Connect with me and [Harald Røine](https://www.linkedin.com/in/haraldroine/) and we’ll give you access to it  
	  
	BONUS: Repost and get access to his latest GPT-5 powered B2B lead-gen setup
- ## Feed post number 61
	These prompts turn your browser into a marketing expert  
	(ChatGPT Atlas browser prompts)  
	  
	ChatGPT's browser can do a lot more than just ordering groceries  
	  
	My partner turned it into a marketing team member  
	  
	Here's how:  
	1️⃣ Builds his ad strategy in a click with breakdowns of angles, CTAs, and proof  
	  
	2️⃣ Fixes his funnel fast, by spotting trust gaps in his landing page and rewriting sections for faster conversion  
	  
	3️⃣ Compiles real buyer language he can plug straight into his copy  
	  
	It only takes 3 prompts + ChatGPT's Atlas browser  
	  
	These prompts cut his ad testing time by 80%  
	  
	He increased his landing page conversions within 3 days of its release  
	  
	I got his permission to share the prompts  
	  
	Want them?  
	✅ Comment "ATLAS"  
	✅ Connect with me and [Lasse Flagstad](https://www.linkedin.com/in/lasse-flagstad/) and we'll send you the prompts  
	  
	BONUS: Repost and get his full breakdown of Atlas's other B2B features
- ## Feed post number 62
	Built by CPAs who saved clients $14M collectively in 2024.  
	(Now they're making the same AI available to everyone)  
	  
	Every year, small business owners lose thousands because the “tax talk” happens in April — when it’s too late.  
	  
	This GPT flips that.  
	It thinks like a strategist, not a filer.  
	  
	Here’s what it can do:  
	1️⃣ Find deductions your accountant forgot  
	2️⃣ Map timing moves to lower next year’s bill  
	3️⃣ Flag which credits you qualify for  
	4️⃣ Explain every step in plain English  
	  
	We trained it on the full IRS code + 10,000 CPA cases — then pressure-tested it on real businesses.  
	  
	Result? Owners saved $12,000+ average across 4 test runs.  
	  
	👉 Comment “TAX” + connect with me to get access.  
	♻️ Repost for a free “Tax Moves That Pay Back” guide.
- ## Feed post number 63
	Sales teams are closing 37% more deals with Claude  
	(Sales Agent prompts)  
	  
	My partner built a sales agent powered by Claude’s latest model  
	  
	It was originally meant to just help with sales call prep  
	  
	But the new model made it capable of so much more  
	  
	With Sonnet 4.5 this agent can:  
	  
	1️⃣ Research every lead before a call → scanning their digital footprint to surface buying signals  
	  
	2️⃣ Build personalized scripts → matching tone, pain points, and desired outcomes for each prospect  
	  
	3️⃣ Handle objections live → running a belief-flip playbook to handle objections in real time  
	  
	4️⃣ Write post-call proposals → using the transcript context to mirror what was actually said  
	  
	5️⃣ Coach your reps → grading calls, spotting belief gaps, and suggesting better phrasing  
	  
	It’s helped my partner and his clients close 37%+ more deals in one month  
	  
	All while cutting costs and rep-onboarding time  
	  
	I’m helping my partner share it  
	  
	Want it?  
	✅ Comment “AGENT”  
	✅ Connect with me and [Lasse Flagstad](https://www.linkedin.com/in/lasse-flagstad/) and we’ll share it with you  
	  
	BONUS: Repost and I’ll also share his full Claude Sonnet 4.5 marketing prompt stack with you
- ## Feed post number 64
	Sora 2 + ChatGPT = End of $10K video agencies  
	You can now produce quality ads for your business in minutes using simple prompts.  
	  
	The cost of hiring agencies for expensive video projects doesn’t make sense anymore. Sora 2 can handle the same process with a short workflow and no extra software.  
	  
	Here’s the structure I use:  
	  
	Step 1  
	👉 Run my B2B Ad Generator Prompt in GPT-5.  
	Add your website URL. It scrapes the site and builds ad concepts with ready-to-use prompts for Sora.  
	  
	Step 2  
	👉 Create a cameo of yourself or another person to represent your brand.  
	  
	Step 3  
	👉 Paste the prompt into Sora, add your cameo, and generate the video.  
	If the output stops early, feed GPT-5 the result. It will produce a follow-up prompt that continues the script.  
	  
	Step 4  
	👉 Download the video and add subtitles in VEED.  
	  
	This workflow removes the need for external video teams.  
	  
	Once documented, it can be fully delegated to a VA.  
	  
	I’m sharing all the prompts and steps for anyone who wants to use them.  
	  
	✅ Comment “Sora” + connect with me and [Harald Røine](https://www.linkedin.com/in/haraldroine/) to get access  
	🎁 Repost and I'll also share a 20 minute breakdown video of where to add these ads in your funnel
- ## Feed post number 65
	ChatGPT Atlas just changed browsing forever  
	Here's why:  
	  
	Your browser isn't just fetching webpages for you anymore  
	  
	It's interacting with them just like you do  
	  
	It can open sites, click buttons, and generally take actions in your place  
	  
	My partner sees Atlas as a digital co-worker more than a simple tool  
	  
	He's optimizing every single Atlas functionality into a B2B gold mine  
	  
	He just dropped a video showing how Atlas helps B2B founders  
	  
	I'm helping him share it with more founders  
	  
	Want to build B2B systems inside Atlas?  
	  
	✅ Comment "BROWSER"  
	✅ Connect with me and [Harald Røine](https://www.linkedin.com/in/haraldroine/) and we'll share it with you  
	  
	BONUS: Repost and I'll also share his Atlas-powered B2B marketing prompts
- ## Feed post number 66
	This workflow sells through your LinkedIn profile without a single sales call  
	(Steal it in this post)  
	  
	My partner scaled a product from $0 to $10k MRR in one month  
	  
	He didn't use cold calls or even a funnel  
	  
	He didn't need to...  
	  
	He built a self closing funnel that uses his LinkedIn profile to close deals for him  
	  
	Here's how it works:  
	  
	\-STEP 1-  
	👉 He validates demand before he even builds anything using simple "Value Sensor" ideas on LinkedIn  
	  
	\-STEP 2-  
	👉 Value sensor becomes a trojan horse. He builds a short guide from that initial idea packed with "How do I do this?!" moments  
	  
	\-STEP 3-  
	👉 Deploys uses an independent delivery stack to avoid manual delivery  
	  
	\-STEP 4-  
	👉 Retargets everywhere. Pipe leads into nurturing stacks that sync with Meta to run reminder ads so he's always in their feed  
	  
	He used this flow to help founders build their brand on LinkedIn, then boost conversion using their own LinkedIn profiles  
	  
	We're sharing the full flow along with the delivery and nurturing stacks  
	  
	✅ Comment "Profile"  
	✅ Connect with me and [Lasse Flagstad](https://www.linkedin.com/in/lasse-flagstad/) so we can send them to you