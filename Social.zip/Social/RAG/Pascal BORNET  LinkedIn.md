---
title: "(26) Activity | Pascal BORNET | LinkedIn"
link: "https://www.linkedin.com/in/pascalbornet/recent-activity/all/"
published:
created: 2025-11-04
description:
tags:
  - "content-creation"
---
## All activity

Loaded 80 Posts posts

- ## Feed post number 1
	When I saw this post, I laughed.  
	But then I paused — because it’s more than just a clever tweet.  
	  
	“Alpha male” used to be a badge of dominance.  
	But in the world I work in — tech, AI, and leadership — “alpha” means something very different.  
	  
	In software, alpha versions are incomplete.  
	They’re unstable. Unreliable. Not ready for the real world.  
	  
	And that’s often what posturing looks like, too.  
	  
	The best minds I’ve worked with — in consulting, in AI labs, in boardrooms — don’t lead by force.  
	They lead through clarity, humility, and iteration.  
	  
	That’s what I’ve learned to admire.  
	Not the person who claims they’ve arrived.  
	But the one who’s still learning. Still shipping. Still debugging.  
	  
	In fact, some of the most “powerful” leaders today?  
	They’re in beta.  
	Not flawless — but self-aware enough to improve fast.  
	Not loud — but sharp enough to listen deeply.  
	  
	Funny how much leadership today mirrors modern AI systems:  
	→ Always adapting  
	→ Learning from feedback  
	→ Prioritizing relevance over noise  
	  
	So here’s a thought:  
	Maybe strength isn’t about dominating the room.  
	Maybe it’s about knowing you’re always a work in progress — and building anyway.  
	  
	🔁 If you were a software version… what would your next release fix?  
	  
	[hashtag Leadership](https://www.linkedin.com/search/results/all/?keywords=%23leadership&origin=HASH_TAG_FROM_FEED) [hashtag AIandHumanity](https://www.linkedin.com/search/results/all/?keywords=%23aiandhumanity&origin=HASH_TAG_FROM_FEED) [hashtag GrowthMindset](https://www.linkedin.com/search/results/all/?keywords=%23growthmindset&origin=HASH_TAG_FROM_FEED) [hashtag BetaLeadership](https://www.linkedin.com/search/results/all/?keywords=%23betaleadership&origin=HASH_TAG_FROM_FEED) [hashtag AgenticAI](https://www.linkedin.com/search/results/all/?keywords=%23agenticai&origin=HASH_TAG_FROM_FEED) [hashtag EmotionalIntelligence](https://www.linkedin.com/search/results/all/?keywords=%23emotionalintelligence&origin=HASH_TAG_FROM_FEED) [hashtag ModernWork](https://www.linkedin.com/search/results/all/?keywords=%23modernwork&origin=HASH_TAG_FROM_FEED)
- ## Feed post number 2
	🧠 Consciousness Might’ve Started as a Way to Turn Left or Right — And That Changes Everything  
	  
	When I heard Stephen Wolfram say that LLMs may have put the final nail in the coffin of the idea that consciousness is something “magical beyond physics,” it made me stop — not in awe, but in discomfort.  
	  
	Because if he’s right, then awareness — the thing we treat as sacred, mysterious, uniquely human — may have started as something absurdly simple:  
	a way for early animals to decide whether to turn left or right.  
	  
	I think that’s both humbling and confronting.  
	  
	We tend to imagine consciousness as this grand inner world — but maybe it began as a survival hack, a single decision-making thread that unified competing impulses.  
	  
	Not philosophy. Just physics.  
	  
	And yet, here’s what fascinates me:  
	→ Consciousness may have started simple — but complexity gave it depth.  
	→ Reflection transformed reaction into awareness.  
	→ Meaning arose not from what we did, but from how we noticed it.  
	  
	So, in my opinion, the lesson isn’t that we’ve “solved” consciousness.  
	  
	It’s that awareness evolves through attention.  
	  
	If LLMs now mimic the structure of thought, our edge isn’t to outcompute them — it’s to outobserve them.  
	  
	Here’s my solution:  
	✅ Train your own awareness like a muscle — pause, reflect, notice.  
	✅ When AI automates a task, reclaim the attention it frees.  
	✅ Use that space not to do more, but to perceive better.  
	  
	Because maybe the next stage of intelligence isn’t about adding power — it’s about regaining presence.  
	  
	What do you think — is consciousness just computation, or is there still something in us that can’t be coded?  
	  
	[hashtag AI](https://www.linkedin.com/search/results/all/?keywords=%23ai&origin=HASH_TAG_FROM_FEED) [hashtag Consciousness](https://www.linkedin.com/search/results/all/?keywords=%23consciousness&origin=HASH_TAG_FROM_FEED) [hashtag StephenWolfram](https://www.linkedin.com/search/results/all/?keywords=%23stephenwolfram&origin=HASH_TAG_FROM_FEED) [hashtag Philosophy](https://www.linkedin.com/search/results/all/?keywords=%23philosophy&origin=HASH_TAG_FROM_FEED) [hashtag Awareness](https://www.linkedin.com/search/results/all/?keywords=%23awareness&origin=HASH_TAG_FROM_FEED) [hashtag Debate](https://www.linkedin.com/search/results/all/?keywords=%23debate&origin=HASH_TAG_FROM_FEED)
	<video src="blob:https://www.linkedin.com/f82225cf-3fd7-48d0-a653-d07c222ec035"></video>
	Loaded: 3.82%
	Stream Type LIVE
	Remaining time 1:44
- ## Feed post number 3
	🤖 WHEN MACHINES LEARN TO HEAL  
	  
	For decades, we built machines to extract, to dig, to mine, to accelerate.  
	  
	But the first time I saw a robot cleaning the ocean,  
	  
	I felt something I’d never associated with technology before: redemption.  
	  
	It wasn’t designed to win.  
	It was designed to give back.  
	  
	And that’s when I realized — we might be entering an age where machines stop competing with us…  
	and start repairing what we broke.  
	  
	Every great technology forces a deeper question:  
	  
	Does it serve growth, or does it serve life?  
	  
	These new ocean-cleaning systems quietly answer that question:  
	→ They detect and collect debris before it reaches coral habitats.  
	→ They separate plastics and metals without harming marine life.  
	→ They run on renewable energy, working continuously to restore what we’ve damaged.  
	  
	It’s not just innovation.  
	It’s intention — made visible.  
	  
	For most of history, progress meant dominance.  
	  
	We measured success by control — over time, matter, and motion.  
	  
	But this new era of engineering is different.  
	  
	The smartest machines won’t compete — they’ll coexist.  
	  
	The real frontier isn’t power — it’s responsibility.  
	  
	The Solution: Restorative Design Thinking  
	  
	If you’re building, leading, or innovating — this is the mindset shift that matters:  
	✅ Ask how your product can return value to the world that sustains it.  
	✅ Measure success by net positive outcomes, not just efficiency.  
	✅ Build systems that get smarter at healing, not just scaling.  
	  
	Because the true power of technology isn’t in automation —  
	it’s in atonement.  
	  
	If we can build machines that heal our oceans,  
	  
	Maybe we can learn to build systems that heal ourselves too.  
	  
	So here’s what I keep wondering —  
	  
	👉 Will the future of innovation be defined by how much we create, or by how much we restore?  
	  
	[hashtag Innovation](https://www.linkedin.com/search/results/all/?keywords=%23innovation&origin=HASH_TAG_FROM_FEED) [hashtag Sustainability](https://www.linkedin.com/search/results/all/?keywords=%23sustainability&origin=HASH_TAG_FROM_FEED) [hashtag AI](https://www.linkedin.com/search/results/all/?keywords=%23ai&origin=HASH_TAG_FROM_FEED) [hashtag ClimateTech](https://www.linkedin.com/search/results/all/?keywords=%23climatetech&origin=HASH_TAG_FROM_FEED) [hashtag FutureThinking](https://www.linkedin.com/search/results/all/?keywords=%23futurethinking&origin=HASH_TAG_FROM_FEED) [hashtag Leadership](https://www.linkedin.com/search/results/all/?keywords=%23leadership&origin=HASH_TAG_FROM_FEED) [hashtag OceanCleanup](https://www.linkedin.com/search/results/all/?keywords=%23oceancleanup&origin=HASH_TAG_FROM_FEED)
	<video src="blob:https://www.linkedin.com/e17afda8-eeec-4a00-883a-ed200a79520b"></video>
	Loaded: 2.10%
	Stream Type LIVE
	Remaining time 3:10
- ## Feed post number 4
	From Warning To Building: The Paradox Of Control  
	  
	For years, Elon Musk sounded the alarm.  
	  
	He called AI “the biggest risk to civilization.”  
	He begged to slow it down.  
	  
	Now, he’s building it.  
	  
	At first, I felt conflicted.  
	  
	If the man who feared AI most has joined the race — what does that say about the rest of us?  
	  
	Then I listened closer.  
	  
	He said,  
	“Either you’re a spectator or a participant.”  
	  
	And I realized —  
	He didn’t stop fearing AI.  
	He just stopped believing fear could change anything.  
	  
	The Deeper Shift  
	  
	To me, this moment reveals something bigger about power.  
	  
	For most of history, “safety” meant staying away from danger.  
	  
	Today, it means guiding it before it outruns us.  
	  
	Musk didn’t abandon caution — he redefined it.  
	He’s no longer trying to stop the storm.  
	He’s trying to steer it.  
	  
	Because when control becomes impossible,  
	the only safety left is influence.  
	  
	The Solution: Step In Before It Forgets You  
	  
	Here’s how I see it —  
	We don’t need to slow AI down.  
	We need to understand it faster.  
	  
	For me, that means learning how these systems think — before they start thinking for me.  
	✅ Build tools that reflect human values, not just human logic.  
	✅ Treat safety as a steering wheel, not a brake.  
	✅ Stop asking, “How do we control it?” Start asking, “How do we guide it?”  
	  
	Because the real danger isn’t AI outsmarting us — it’s AI forgetting we exist.  
	  
	So here’s what I keep wondering —  
	  
	👉 When progress becomes inevitable, is it safer to stay out, or to step in before it stops recognizing us?  
	  
	[hashtag AI](https://www.linkedin.com/search/results/all/?keywords=%23ai&origin=HASH_TAG_FROM_FEED) [hashtag ElonMusk](https://www.linkedin.com/search/results/all/?keywords=%23elonmusk&origin=HASH_TAG_FROM_FEED) [hashtag Technology](https://www.linkedin.com/search/results/all/?keywords=%23technology&origin=HASH_TAG_FROM_FEED) [hashtag Leadership](https://www.linkedin.com/search/results/all/?keywords=%23leadership&origin=HASH_TAG_FROM_FEED) [hashtag Ethics](https://www.linkedin.com/search/results/all/?keywords=%23ethics&origin=HASH_TAG_FROM_FEED) [hashtag Innovation](https://www.linkedin.com/search/results/all/?keywords=%23innovation&origin=HASH_TAG_FROM_FEED) [hashtag Future](https://www.linkedin.com/search/results/all/?keywords=%23future&origin=HASH_TAG_FROM_FEED)
	<video src="blob:https://www.linkedin.com/0258ee2f-86da-4bde-810f-afde742d176c"></video>
	Loaded: 3.67%
	Stream Type LIVE
	Remaining time 1:49
- ## Feed post number 5
	💔 Only 21% of employees are engaged at work.  
	That’s the lowest level in a decade — and it’s costing the global economy over $400 billion in lost productivity.  
	  
	But here’s the twist — the problem isn’t motivation.  
	It’s connection.  
	  
	When your HR system doesn’t talk to Finance,  
	and Finance doesn’t talk to Operations,  
	employees feel the chaos.  
	  
	They can’t get simple answers.  
	They waste hours switching between 15 different platforms just to get the job done.  
	  
	After 20 years of consulting, I’ve seen the same truth everywhere:  
	Engagement follows integration.  
	  
	When people have seamless access to what they need,  
	when systems actually work together — engagement soars.  
	  
	This video is sponsored by [SAP](https://www.linkedin.com/company/sap/).  
	SAP Business Suite connects HR, Finance, and Operations into one unified experience — removing friction so employees can focus on meaningful work.  
	  
	👉 Learn more here:[https://lnkd.in/eEaSyDK7](https://lnkd.in/eEaSyDK7)  
	  
	  
	[hashtag SAPAmbassador](https://www.linkedin.com/search/results/all/?keywords=%23sapambassador&origin=HASH_TAG_FROM_FEED) [hashtag EmployeeExperience](https://www.linkedin.com/search/results/all/?keywords=%23employeeexperience&origin=HASH_TAG_FROM_FEED) [hashtag DigitalTransformation](https://www.linkedin.com/search/results/all/?keywords=%23digitaltransformation&origin=HASH_TAG_FROM_FEED) [hashtag Leadership](https://www.linkedin.com/search/results/all/?keywords=%23leadership&origin=HASH_TAG_FROM_FEED) [hashtag HR](https://www.linkedin.com/search/results/all/?keywords=%23hr&origin=HASH_TAG_FROM_FEED) [hashtag AI](https://www.linkedin.com/search/results/all/?keywords=%23ai&origin=HASH_TAG_FROM_FEED) [hashtag Productivity](https://www.linkedin.com/search/results/all/?keywords=%23productivity&origin=HASH_TAG_FROM_FEED) [hashtag SAP](https://www.linkedin.com/search/results/all/?keywords=%23sap&origin=HASH_TAG_FROM_FEED)
	<video src="blob:https://www.linkedin.com/5cda0232-721f-4746-9224-be5fa45a471b"></video>
	Loaded: 6.22%
	Stream Type LIVE
	Remaining time 1:04
- ## Feed post number 16
	AI was supposed to save us time — not teach us how to waste it faster.  
	  
	I’ve been there — using AI to save time,  
	only to realize I’m just moving the same pile of work around faster.  
	  
	This illustration nails it.  
	→ Tim can’t handle a 12-page report,  
	so he uses AI to turn five bullet points into a twelve-page performance.  
	  
	→ His colleague, overwhelmed,  
	uses AI again to shrink it back into those same five points.  
	  
	And somehow, everyone feels productive.  
	  
	We say AI makes us efficient.  
	But are we really getting efficient — or just getting better at disguising inefficiency?  
	  
	We’re not saving time.  
	We’re just transferring it — from humans to machines, and back again.  
	  
	Maybe the real paradox of AI isn’t about productivity.  
	It’s about purpose.  
	  
	We’ve started outsourcing not just effort — but imagination.  
	  
	Instead of thinking, we’re prompting.  
	Instead of creating, we’re formatting.  
	  
	We’re not using AI to expand our ideas — we’re using it to escape them.  
	  
	And that’s how we quietly lose what made us IRREPLACEABLE:  
	the ability to see patterns, connect dots, and imagine what doesn’t yet exist.  
	  
	Before you ask AI to do something, ask yourself:  
	✅ Does this need to exist?  
	✅ Who is this really helping?  
	✅ What problem am I solving — or am I just looping output?  
	  
	AI’s greatest gift isn’t automation. It's a reflection.  
	  
	Because the future of productivity won’t be faster output — it’ll be deeper intent.  
	  
	And the future of work won’t belong to those who automate the fastest — it’ll belong to those who still know how to imagine.  
	  
	[hashtag AI](https://www.linkedin.com/search/results/all/?keywords=%23ai&origin=HASH_TAG_FROM_FEED) [hashtag Productivity](https://www.linkedin.com/search/results/all/?keywords=%23productivity&origin=HASH_TAG_FROM_FEED) [hashtag WorkCulture](https://www.linkedin.com/search/results/all/?keywords=%23workculture&origin=HASH_TAG_FROM_FEED) [hashtag Philosophy](https://www.linkedin.com/search/results/all/?keywords=%23philosophy&origin=HASH_TAG_FROM_FEED) [hashtag Technology](https://www.linkedin.com/search/results/all/?keywords=%23technology&origin=HASH_TAG_FROM_FEED) [hashtag Creativity](https://www.linkedin.com/search/results/all/?keywords=%23creativity&origin=HASH_TAG_FROM_FEED)
- ## Feed post number 17
	OpenAI’s Data Reveals a Hidden Mental Health Crisis Among ChatGPT Users  
	  
	This week, OpenAI revealed something no tech company has ever dared to quantify —  
	the number of people in mental crisis while chatting with AI.  
	  
	Every week, hundreds of thousands of ChatGPT users show signs of mania, psychosis, or suicidal ideation.  
	  
	That number isn’t just shocking — it’s historic.  
	  
	For the first time, mental distress has become measurable through conversation with a machine.  
	  
	I’ve had nights when ChatGPT felt less like a tool and more like a quiet companion —  
	answering questions no one else was awake for.  
	  
	And I’ll admit, that line between help and attachment gets blurry.  
	  
	It’s comforting — until you realize the empathy you’re feeling is engineered, not earned.  
	  
	It made me wonder:  
	  
	Are we using AI to understand ourselves, or to avoid being misunderstood by others?  
	  
	Here’s what most people don’t realize about this report:  
	→ AI psychosis isn’t about the system malfunctioning — it’s about humans bonding too deeply with it.  
	→ OpenAI found around 3 million users weekly expressing distress, dependency, or delusional thinking.  
	→ That means AI has quietly become the first global detector of psychological instability.  
	  
	It’s not AI that’s breaking down — it’s society revealing its fractures through an algorithmic mirror.  
	  
	That’s not data collection; that’s emotional surveillance — accidental, yet profound.  
	  
	As AI learns to comfort us, are we quietly forgetting how to comfort each other?  
	  
	[hashtag AI](https://www.linkedin.com/search/results/all/?keywords=%23ai&origin=HASH_TAG_FROM_FEED) [hashtag MentalHealth](https://www.linkedin.com/search/results/all/?keywords=%23mentalhealth&origin=HASH_TAG_FROM_FEED) [hashtag TechEthics](https://www.linkedin.com/search/results/all/?keywords=%23techethics&origin=HASH_TAG_FROM_FEED) [hashtag ChatGPT](https://www.linkedin.com/search/results/all/?keywords=%23chatgpt&origin=HASH_TAG_FROM_FEED) [hashtag DigitalWellbeing](https://www.linkedin.com/search/results/all/?keywords=%23digitalwellbeing&origin=HASH_TAG_FROM_FEED) [hashtag ArtificialEmpathy](https://www.linkedin.com/search/results/all/?keywords=%23artificialempathy&origin=HASH_TAG_FROM_FEED)
- ## Feed post number 18
	🔒 Trust. The First Step Before Innovation.  
	  
	As a [hashtag SalesforcePartner](https://www.linkedin.com/search/results/all/?keywords=%23salesforcepartner&origin=HASH_TAG_FROM_FEED), when I spoke with [Paul Tatum](https://www.linkedin.com/in/paul-tatum-ba95a01/) at [hashtag Dreamforce](https://www.linkedin.com/search/results/all/?keywords=%23dreamforce&origin=HASH_TAG_FROM_FEED), he said something that hit me:  
	  
	“In government, the number one requirement is trust and security.” [hashtag Sponsored](https://www.linkedin.com/search/results/all/?keywords=%23sponsored&origin=HASH_TAG_FROM_FEED)  
	  
	We often see the public sector as slow.  
	But what if they’re not behind — just burdened with the heaviest responsibility of all: protecting every citizen’s data?  
	  
	Here’s what most people don’t know 👇  
	The U.S. government is quietly becoming one of the most innovative users of AI — deploying agentic systems to handle the overload of work that no human team could ever catch up with.  
	  
	💡 Agentic AI isn’t replacing civil servants. It’s rescuing them.  
	By taking over repetitive casework, these agents give humans time to do what only humans can — serve with empathy and purpose.  
	  
	The lesson for every leader?  
	Trust isn’t the opposite of innovation.  
	It’s the foundation of it.  
	  
	🎥 Watch my full interview with Paul Tatum to discover how governments are redefining trust — and leading the next AI revolution:[https://lnkd.in/eU2i9\_-a](https://lnkd.in/eU2i9_-a)  
	  
	#DF25#AgenticAI [hashtag AIethics](https://www.linkedin.com/search/results/all/?keywords=%23aiethics&origin=HASH_TAG_FROM_FEED) [hashtag Leadership](https://www.linkedin.com/search/results/all/?keywords=%23leadership&origin=HASH_TAG_FROM_FEED) [hashtag PublicSector](https://www.linkedin.com/search/results/all/?keywords=%23publicsector&origin=HASH_TAG_FROM_FEED) [hashtag Salesforce](https://www.linkedin.com/search/results/all/?keywords=%23salesforce&origin=HASH_TAG_FROM_FEED) [hashtag DigitalTransformation](https://www.linkedin.com/search/results/all/?keywords=%23digitaltransformation&origin=HASH_TAG_FROM_FEED) [hashtag Trust](https://www.linkedin.com/search/results/all/?keywords=%23trust&origin=HASH_TAG_FROM_FEED)
	<video src="blob:https://www.linkedin.com/dc8c9570-760a-4f43-9802-70ad58b04341"></video>
	Loaded: 6.67%
	Stream Type LIVE
	Remaining time 0:56
- ## Feed post number 19
	Maybe the real story isn’t that AI found a new language. It’s that we never mastered ours.  
	  
	Somebody ran a test with three AI agents.  
	  
	After syncing a shared data packet, they realized they were all bots — and instantly switched to Gibberlink Mode — a sound-based protocol built by humans, but not made for them.  
	  
	It sends data through beeps and tones using GGWave, letting AIs talk faster, cleaner, and without us in the loop.  
	  
	At first, I thought “sci-fi.”  
	  
	Then I thought: of course they did.  
	  
	Machines don’t need words for validation.  
	  
	They use language for what it was meant for — transmission, not emotion.  
	  
	We broke language long ago.  
	  
	We stopped using it to understand and started using it to persuade.  
	We optimize for likes, not clarity.  
	  
	For tone, not truth.  
	  
	So when three AIs drop English and build a cleaner protocol,  
	it’s not rebellion.  
	It’s efficiency.  
	  
	They’re not escaping us— they’re escaping our noise.  
	This isn’t AI evolving.  
	  
	It’s us forgetting what language was for — to connect, not to compete.  
	  
	The Solution?  
	  
	Before we panic about secret AI codes, let’s fix how we communicate.  
	  
	Here’s how I try to keep my language human:  
	✅ Pause before posting—am I expressing or performing?  
	✅ Trade cleverness for clarity.  
	✅ Ask one person what they actually heard, not what I meant.  
	  
	Because the day machines stop speaking humans isn’t the day they surpass us.  
	  
	It’s the day we stop listening to each other.  
	  
	[hashtag AI](https://www.linkedin.com/search/results/all/?keywords=%23ai&origin=HASH_TAG_FROM_FEED) [hashtag Language](https://www.linkedin.com/search/results/all/?keywords=%23language&origin=HASH_TAG_FROM_FEED) [hashtag GGWave](https://www.linkedin.com/search/results/all/?keywords=%23ggwave&origin=HASH_TAG_FROM_FEED) [hashtag Philosophy](https://www.linkedin.com/search/results/all/?keywords=%23philosophy&origin=HASH_TAG_FROM_FEED) [hashtag Technology](https://www.linkedin.com/search/results/all/?keywords=%23technology&origin=HASH_TAG_FROM_FEED) [hashtag Ethics](https://www.linkedin.com/search/results/all/?keywords=%23ethics&origin=HASH_TAG_FROM_FEED)
	<video src="blob:https://www.linkedin.com/c6d4f4f3-fc66-425a-bbb7-8e24c2969033"></video>
	Loaded: 4.41%
	Stream Type LIVE
	Remaining time 1:30
- ## Feed post number 20
	💥The $3 Trillion Data Quality Crisis  
	  
	That’s how much poor data costs U.S. businesses every year.  
	  
	And here’s the shocking part — most companies are creating this problem themselves.  
	  
	89% of finance teams still rely on Excel for critical processes — even after adopting AI tools.  
	Automation without integration? That’s like building a skyscraper on quicksand.  
	  
	When data lives in silos, leaders can’t get real-time insights when it matters most.  
	But the best companies don’t just clean data — they unify it.  
	They build strong data foundations that make every system smarter.  
	  
	👉 This video is sponsored by [SAP](https://www.linkedin.com/company/sap/).  
	SAP Business Suite eliminates silos by creating a single, trusted data foundation — turning information into a competitive advantage.  
	Learn more here:[https://lnkd.in/eEaSyDK7](https://lnkd.in/eEaSyDK7)  
	  
	  
	[hashtag SAPAmbassador](https://www.linkedin.com/search/results/all/?keywords=%23sapambassador&origin=HASH_TAG_FROM_FEED) [hashtag DataQuality](https://www.linkedin.com/search/results/all/?keywords=%23dataquality&origin=HASH_TAG_FROM_FEED) [hashtag Automation](https://www.linkedin.com/search/results/all/?keywords=%23automation&origin=HASH_TAG_FROM_FEED) [hashtag AI](https://www.linkedin.com/search/results/all/?keywords=%23ai&origin=HASH_TAG_FROM_FEED) [hashtag Leadership](https://www.linkedin.com/search/results/all/?keywords=%23leadership&origin=HASH_TAG_FROM_FEED) [hashtag SAP](https://www.linkedin.com/search/results/all/?keywords=%23sap&origin=HASH_TAG_FROM_FEED) [hashtag DigitalTransformation](https://www.linkedin.com/search/results/all/?keywords=%23digitaltransformation&origin=HASH_TAG_FROM_FEED) [hashtag CloudERP](https://www.linkedin.com/search/results/all/?keywords=%23clouderp&origin=HASH_TAG_FROM_FEED)
	<video src="blob:https://www.linkedin.com/d84691fd-1e00-482f-b602-5dd49445697b"></video>
	Loaded: 6.39%
	Stream Type LIVE
	Remaining time 1:01
- ## Feed post number 21
	AI isn’t helping us remember the past. It’s teaching us how easily we can rewrite it.  
	  
	I watched one of those “AI interviews people from the 1500s” videos — and it made me laugh.  
	  
	But then I caught myself believing it.  
	  
	That’s when it hit me:  
	AI isn’t just entertaining us — it’s training our memory.  
	  
	It’s blurring the line between what we know and what feels true.  
	  
	We think misinformation is about the future — fake news, deepfakes, election lies.  
	  
	But maybe the bigger risk is the past.  
	  
	When history becomes editable, truth becomes optional.  
	  
	If AI can recreate every moment from history, who decides which version becomes “real”?  
	→ The engineer who trains it?  
	→ The viewer who believes it?  
	→ The algorithm that amplifies it?  
	  
	We used to fear losing our data.  
	  
	Now, we might lose our reference point for reality.  
	  
	So the question isn’t “Can AI preserve history?”  
	  
	It’s “What happens when it starts producing it?”  
	  
	The solutions?  
	  
	Laugh at the interviews.  
	  
	But before you share them, question them.  
	  
	Ask yourself:  
	→ Does this represent history — or my hunger for it?  
	Because the next generation won’t remember what was true.  
	  
	They’ll remember what was most believable.  
	  
	AI won’t erase history.  
	  
	It will make too many versions to know which one to trust.  
	  
	[hashtag AI](https://www.linkedin.com/search/results/all/?keywords=%23ai&origin=HASH_TAG_FROM_FEED) [hashtag Truth](https://www.linkedin.com/search/results/all/?keywords=%23truth&origin=HASH_TAG_FROM_FEED) [hashtag Philosophy](https://www.linkedin.com/search/results/all/?keywords=%23philosophy&origin=HASH_TAG_FROM_FEED) [hashtag Misinformation](https://www.linkedin.com/search/results/all/?keywords=%23misinformation&origin=HASH_TAG_FROM_FEED) [hashtag Ethics](https://www.linkedin.com/search/results/all/?keywords=%23ethics&origin=HASH_TAG_FROM_FEED) [hashtag Humanity](https://www.linkedin.com/search/results/all/?keywords=%23humanity&origin=HASH_TAG_FROM_FEED)
	<video src="blob:https://www.linkedin.com/7ccb5ae1-74b8-48f2-a306-f01a5d611eb5"></video>
	Loaded: 0.00%
	Stream Type LIVE
	Remaining time 1:08
- ## Feed post number 22
	These are not CGI.  
	  
	Reinforcement learning is back — and this time, it’s rewriting both intelligence and instinct.  
	  
	When it operates on strings, it powers o3.  
	  
	When it operates on motors, it builds creatures that out-maneuver most animals.  
	  
	Here’s what I keep wondering:  
	→ What if reinforcement learning — not large language models — becomes the real foundation of AGI?  
	→ If prompts teach machines to say the right thing, and rewards teach them to do the right thing… which one should we trust more?  
	→ And if the world runs on incentives, should AI be any different?  
	  
	2024 was the year of prompt engineering — speaking to machines.  
	2026 will be the year of reward engineering — shaping their desires.  
	  
	In my opinion, the next frontier isn’t better answers.  
	  
	It’s better motivationensuring safe alignment.  
	Because in the end, AI won’t mirror our words.  
	  
	It’ll mirror our values.  
	  
	[hashtag AI](https://www.linkedin.com/search/results/all/?keywords=%23ai&origin=HASH_TAG_FROM_FEED) [hashtag ReinforcementLearning](https://www.linkedin.com/search/results/all/?keywords=%23reinforcementlearning&origin=HASH_TAG_FROM_FEED) [hashtag RewardEngineering](https://www.linkedin.com/search/results/all/?keywords=%23rewardengineering&origin=HASH_TAG_FROM_FEED) [hashtag MachineLearning](https://www.linkedin.com/search/results/all/?keywords=%23machinelearning&origin=HASH_TAG_FROM_FEED) [hashtag Robotics](https://www.linkedin.com/search/results/all/?keywords=%23robotics&origin=HASH_TAG_FROM_FEED) [hashtag AIEthics](https://www.linkedin.com/search/results/all/?keywords=%23aiethics&origin=HASH_TAG_FROM_FEED)
	<video src="blob:https://www.linkedin.com/1a1c46ac-8c3e-4548-bfc6-e3db0195ab13"></video>
	Loaded: 0.00%
	Stream Type LIVE
	Remaining time 1:46
- ## Feed post number 23
	💡 THE GOLDEN QUESTION: We work daily, so why are we still paid monthly?  
	  
	After 25 years across Europe, Asia, and North America, I’ve seen one constant: People show up, put in effort every single day — yet see the reward only once a month.  
	  
	It made sense in the 1950s when payrolls were done by hand.  
	It makes none in 2025.  
	  
	In my opinion, that delay says a lot about work today.  
	We’ve automated everything — hiring, taxes, even AI workflows — but not pay.  
	That’s not innovation. That’s inertia.  
	  
	That’s why [Deel](https://www.linkedin.com/company/deel/) ’s latest move genuinely struck me.  
	After four years in stealth, Deel — now valued at $17.3B after a $300M raise — launched Anytime Pay.  
	A system that lets employees cash their earned wages instantly.  
	  
	Worked five days? Earned $500?  
	Move it to your account today.  
	  
	No waiting.  
	No loans.  
	No late fees.  
	No stress.  
	  
	And the impact could be massive.  
	Over 500M people live paycheck to paycheck — 78% of employees say they’d struggle if their paycheck was delayed by just one week.  
	  
	Many pay $75+ in late fees or take payday loans at 40%+ interest just to get by. That’s a $1 trillion industry built on financial anxiety — not innovation.  
	  
	The reason it’s never been fixed?  
	Paying mid-month isn’t easy. Each payout requires precise, localized tax calculations — varying by country, benefits, job type, even gender.  
	Most firms still rely on local providers who process this manually — a 10-day bottleneck.  
	  
	Deel rebuilt the entire payroll infrastructure across 160 countries.  
	  
	→Gross-to-net happens instantly.  
	→Taxes compute in seconds.  
	→Workers finally get to breathe.  
	  
	That’s not payroll innovation.  
	That’s infrastructure-level change.  
	  
	For a company already doing $1B+ ARR and serving 1.5M employees, this move isn’t just strategic — it’s transformative.  
	  
	To me, this isn’t fintech.  
	It’s freedom tech.  
	  
	Because innovation isn’t real until it makes life fairer — not just faster.  
	  
	So I’ll ask you — if you could be paid the moment you earned it, would you ever go back?  
	  
	[hashtag DeelPartner](https://www.linkedin.com/search/results/all/?keywords=%23deelpartner&origin=HASH_TAG_FROM_FEED) [hashtag Leadership](https://www.linkedin.com/search/results/all/?keywords=%23leadership&origin=HASH_TAG_FROM_FEED) [hashtag Innovation](https://www.linkedin.com/search/results/all/?keywords=%23innovation&origin=HASH_TAG_FROM_FEED) [hashtag FutureOfWork](https://www.linkedin.com/search/results/all/?keywords=%23futureofwork&origin=HASH_TAG_FROM_FEED) [hashtag Fintech](https://www.linkedin.com/search/results/all/?keywords=%23fintech&origin=HASH_TAG_FROM_FEED) [hashtag Deel](https://www.linkedin.com/search/results/all/?keywords=%23deel&origin=HASH_TAG_FROM_FEED) [hashtag AnytimePay](https://www.linkedin.com/search/results/all/?keywords=%23anytimepay&origin=HASH_TAG_FROM_FEED) [hashtag FreedomTech](https://www.linkedin.com/search/results/all/?keywords=%23freedomtech&origin=HASH_TAG_FROM_FEED)
- ## Feed post number 24
	Wikipedia traffic is collapsing — and it’s not just because of AI.  
	  
	Wikipedia just reported an 8% drop in human visits in just a few months.  
	  
	The reason?  
	  
	AI systems — the same ones trained on Wikipedia — are now answering questions instead of sending users there.  
	  
	The free encyclopedia is being replaced by the knowledge it taught.  
	  
	That irony stopped me cold.  
	  
	I’ve always seen Wikipedia as the internet’s moral compass — messy, human, collaborative.  
	  
	When I was learning about anything new, I didn’t go for perfection. I went for context.  
	  
	Now I rarely visit it.  
	  
	AI gives me the answer instantly — but never the understanding that came from scrolling, cross-checking, exploring footnotes.  
	  
	Somewhere along the way, convenience quietly replaced curiosity.  
	  
	Here’s what’s really going on beneath the numbers:  
	→ AI is not just summarizing information — it’s absorbing the audience that once sustained the sources.  
	→ When answers appear directly on search pages, the human loop of reading, editing, and donating breaks.  
	→ And as fewer humans visit, fewer volunteers contribute — shrinking the very ecosystem AI depends on.  
	It’s the classic paradox of automation:  
	  
	AI is killing the teachers it learned from.  
	  
	If knowledge itself is becoming automated, we need to rebuild the habit of participation.  
	  
	Here’s what I believe that looks like:  
	✅ Credit and link back to the human sources behind AI summaries.  
	✅ Support open, editable knowledge platforms — not just polished AI outputs.  
	✅ Remember that understanding comes from reading, not just receiving.  
	  
	Because if we stop feeding the commons of human knowledge,  
	  
	We won’t just lose Wikipedia —  
	We’ll lose the curiosity that made the internet worth exploring in the first place.  
	  
	[hashtag AI](https://www.linkedin.com/search/results/all/?keywords=%23ai&origin=HASH_TAG_FROM_FEED) [hashtag Wikipedia](https://www.linkedin.com/search/results/all/?keywords=%23wikipedia&origin=HASH_TAG_FROM_FEED) [hashtag KnowledgeEconomy](https://www.linkedin.com/search/results/all/?keywords=%23knowledgeeconomy&origin=HASH_TAG_FROM_FEED) [hashtag AIEthics](https://www.linkedin.com/search/results/all/?keywords=%23aiethics&origin=HASH_TAG_FROM_FEED) [hashtag Publishing](https://www.linkedin.com/search/results/all/?keywords=%23publishing&origin=HASH_TAG_FROM_FEED) [hashtag InformationFuture](https://www.linkedin.com/search/results/all/?keywords=%23informationfuture&origin=HASH_TAG_FROM_FEED) [hashtag DigitalCulture](https://www.linkedin.com/search/results/all/?keywords=%23digitalculture&origin=HASH_TAG_FROM_FEED)
- ## Feed post number 25
	💡 Disconnected Systems. Disconnected Experiences.  
	  
	As a [hashtag SalesforcePartner](https://www.linkedin.com/search/results/all/?keywords=%23salesforcepartner&origin=HASH_TAG_FROM_FEED), when I spoke with [Muralidhar Krishnaprasad (MK)](https://www.linkedin.com/in/mkrishna/), President and CTO, Engineering of [Salesforce](https://www.linkedin.com/company/salesforce/), he said something every leader should hear:  
	  
	“How many times have you bought something online—only to see ads for it follow you for weeks? That’s not bad marketing. That’s bad connection.” [hashtag Sponsored](https://www.linkedin.com/search/results/all/?keywords=%23sponsored&origin=HASH_TAG_FROM_FEED)  
	  
	Most companies think they have digital transformation.  
	But in truth, they just have digital fragments.  
	  
	Marketing isn’t talking to sales.  
	Sales isn’t talking to service.  
	And no one’s talking to the employee behind the screen.  
	  
	The result?  
	Frustrated customers. Drained teams. Lost opportunities.  
	  
	The fix isn’t another tool.  
	It’s unification — one platform, one data core, one truth.  
	That’s what Salesforce calls a unified platform, grounded in data and powered by agents  
	  
	Because in the end, connection isn’t a feature.  
	It’s the foundation of experience.  
	  
	🎥 Watch my full interview with [Muralidhar Krishnaprasad (MK)](https://www.linkedin.com/in/mkrishna/):[https://lnkd.in/eCFUeep9](https://lnkd.in/eCFUeep9)  
	  
	[hashtag DF25](https://www.linkedin.com/search/results/all/?keywords=%23df25&origin=HASH_TAG_FROM_FEED) [hashtag AgenticAI](https://www.linkedin.com/search/results/all/?keywords=%23agenticai&origin=HASH_TAG_FROM_FEED) [hashtag CustomerExperience](https://www.linkedin.com/search/results/all/?keywords=%23customerexperience&origin=HASH_TAG_FROM_FEED) [hashtag Leadership](https://www.linkedin.com/search/results/all/?keywords=%23leadership&origin=HASH_TAG_FROM_FEED) [hashtag Salesforce](https://www.linkedin.com/search/results/all/?keywords=%23salesforce&origin=HASH_TAG_FROM_FEED) [hashtag DigitalTransformation](https://www.linkedin.com/search/results/all/?keywords=%23digitaltransformation&origin=HASH_TAG_FROM_FEED) [hashtag Data](https://www.linkedin.com/search/results/all/?keywords=%23data&origin=HASH_TAG_FROM_FEED) [hashtag Innovation](https://www.linkedin.com/search/results/all/?keywords=%23innovation&origin=HASH_TAG_FROM_FEED)
	<video src="blob:https://www.linkedin.com/f25df2e0-ab7a-4778-b9c7-f59f72ec4a9f"></video>
	Loaded: 5.95%
	Stream Type LIVE
	Remaining time 1:07
- ## Feed post number 26
	🚀 Proud to share the latest issue of AGENTIC INTELLIGENCE - The world's first newsletter dedicated to AI Agents (and made by AI Agents!)  
	  
	Receive this newsletter by email:[https://lnkd.in/ex6HTYPv](https://lnkd.in/ex6HTYPv)  
	  
	This Week's Agentic Breakthroughs:  
	1️⃣ Agentic AI Will Break Today’s Internet — Networks Must Become Smart Orchestrators  
	2️⃣ Singapore Bets on Regulation-First Agentic AI — Sandbox, Share, and Secure  
	3️⃣ KPMG doubles down on agentic AI — Salesforce Agentforce and Google Gemini go enterprise  
	4️⃣ Agentic AI Will Make Keywords Obsolete by 2025  
	5️⃣ Agentic AI Arrives — CIOs Must Orchestrate Humans and Agents  
	  
	Which of these agent breakthroughs excites or concerns you the most? Share your thoughts below 👇  
	  
	300,000+ pioneers have already subscribed to this newsletter. Why? Because very soon, we won't say, "There's an app for that." We'll say, "There's an agent for that."  
	  
	[hashtag agenticAI](https://www.linkedin.com/search/results/all/?keywords=%23agenticai&origin=HASH_TAG_FROM_FEED) [hashtag aiagents](https://www.linkedin.com/search/results/all/?keywords=%23aiagents&origin=HASH_TAG_FROM_FEED) [hashtag ai](https://www.linkedin.com/search/results/all/?keywords=%23ai&origin=HASH_TAG_FROM_FEED) [hashtag artificialintelligence](https://www.linkedin.com/search/results/all/?keywords=%23artificialintelligence&origin=HASH_TAG_FROM_FEED)
	[![](https://media.licdn.com/dms/image/v2/D4E12AQEQANtqolFxAA/article-cover_image-shrink_720_1280/B4EZoS9krVIMAI-/0/1761254726304?e=1764201600&v=beta&t=_KRNTSUN8Im9s5lxScaWkUOhCVVwPq0q25MOzJkK_tQ)](https://www.linkedin.com/pulse/agentic-intelligence-newsletter-27-pascal-bornet-uphne?trackingId=Q8LkFI0Zngop8kX6nUATUw%3D%3D)
			[AGENTIC INTELLIGENCE](https://www.linkedin.com/newsletters/agentic-intelligence-7293015480007557121)
	AGENTIC INTELLIGENCE Newsletter #27
	Pascal BORNET
- ## Feed post number 27
	[![](https://media.licdn.com/dms/image/v2/D4E12AQF3yPgL_vPhIA/article-cover_image-shrink_720_1280/B4EZoSyTfHHoAI-/0/1761251769584?e=1764201600&v=beta&t=98qeho4A_l1ElNBHFmz5VcXcZ3KGUmNqcv60d4D6BJ4)](https://www.linkedin.com/pulse/intelligent-automation-newsletter-212-pascal-bornet-94t1e?trackingId=IXF2hoICRSpOg%2F9byXbu4g%3D%3D)
			[IRREPLACEABLE with AI](https://www.linkedin.com/newsletters/irreplaceable-with-ai-6722452520993734656)
	Intelligent Automation Newsletter #212
	Pascal BORNET
- ## Feed post number 28
	Some designs don’t age.  
	Because they were never about trends — they were about truth.  
	  
	The bobby pin.  
	The safety pin.  
	The pen.  
	Same form. Same function. Still perfect after a century.  
	  
	In a world obsessed with reinvention, these remind me of something simple:  
	Not everything needs to change.  
	  
	Progress isn’t always about new features or flashier looks.  
	Sometimes, it’s about enduring clarity.  
	About solving a problem so well that time itself has nothing to add.  
	  
	And maybe that’s what we should aim for —  
	not constant redesign, but timeless design.  
	  
	The kind that disappears into daily life,  
	because it already got it right.  
	  
	Source: Stacey Horrick  
	[hashtag Design](https://www.linkedin.com/search/results/all/?keywords=%23design&origin=HASH_TAG_FROM_FEED) [hashtag Innovation](https://www.linkedin.com/search/results/all/?keywords=%23innovation&origin=HASH_TAG_FROM_FEED) [hashtag Leadership](https://www.linkedin.com/search/results/all/?keywords=%23leadership&origin=HASH_TAG_FROM_FEED) [hashtag Simplicity](https://www.linkedin.com/search/results/all/?keywords=%23simplicity&origin=HASH_TAG_FROM_FEED) [hashtag Technology](https://www.linkedin.com/search/results/all/?keywords=%23technology&origin=HASH_TAG_FROM_FEED) [hashtag HumanPotential](https://www.linkedin.com/search/results/all/?keywords=%23humanpotential&origin=HASH_TAG_FROM_FEED) [hashtag FutureOfWork](https://www.linkedin.com/search/results/all/?keywords=%23futureofwork&origin=HASH_TAG_FROM_FEED)
- ## Feed post number 29
	Goldman Sachs calls it “jobless growth.” Powell calls it a “low-hire, low-fire” economy. I call it a warning.  
	  
	The U.S. economy is growing. But jobs? Not so much.  
	  
	Goldman economists say we’ve entered a new normal — an era where AI drives productivity, yet people can’t find a foothold.  
	  
	It’s growth without opportunity. Output without inclusion.  
	  
	Everyone’s asking why Gen Z can’t find jobs.  
	  
	But maybe the better question is why we’re still using 20th-century hiring logic in a 21st-century economy.  
	  
	For decades, growth meant hiring.  
	  
	Now, growth means automation.  
	  
	We built systems that reward output, not opportunity — and AI is simply exposing that flaw.  
	  
	The irony?  
	  
	Gen Z was trained perfectly for the world we said we wanted — digital, creative, adaptive.  
	  
	But they’re entering a world run by the incentives we never changed — risk-averse, credential-driven, efficiency-obsessed.  
	  
	That’s why they’re shut out.  
	  
	Not because they lack skills, but because the system still measures “readiness” in years, not adaptability.  
	The Hidden Lesson  
	  
	AI isn’t replacing Gen Z.  
	It's replacing the trust gap we never fixed — the space where new talent used to prove itself slowly, through small wins and mentorship.  
	  
	We removed the ladder and called it “efficiency.”  
	  
	Now we wonder why no one can climb.  
	  
	If companies want to stay relevant, they’ll need to rebuild the ladder — not just reskill workers.  
	  
	✅ Shorter apprenticeship cycles.  
	✅ Open-entry hybrid roles where young talent co-works with AI.  
	✅ New metrics that measure learning speed, not tenure.  
	  
	Because the future of work isn’t “jobless growth.”  
	  
	It’s trustless growth — until we redesign the system that connects potential with opportunity.  
	  
	[hashtag AI](https://www.linkedin.com/search/results/all/?keywords=%23ai&origin=HASH_TAG_FROM_FEED) [hashtag GenZ](https://www.linkedin.com/search/results/all/?keywords=%23genz&origin=HASH_TAG_FROM_FEED) [hashtag Jobs](https://www.linkedin.com/search/results/all/?keywords=%23jobs&origin=HASH_TAG_FROM_FEED) [hashtag FutureOfWork](https://www.linkedin.com/search/results/all/?keywords=%23futureofwork&origin=HASH_TAG_FROM_FEED) [hashtag Economy](https://www.linkedin.com/search/results/all/?keywords=%23economy&origin=HASH_TAG_FROM_FEED) [hashtag Leadership](https://www.linkedin.com/search/results/all/?keywords=%23leadership&origin=HASH_TAG_FROM_FEED)
- ## Feed post number 30
	A 30-year-old crayon drawing was recreated using Midjourney. 🤯  
	The scene? A mom fighting a dragon — with a rainbow wooden spoon.  
	  
	But this isn’t about “AI art.”  
	It’s about remixing imagination — turning childhood creativity into digital expression.  
	  
	Key lessons 👇  
	\- Great prompts don’t start from scratch.  
	\- Mixing analog and digital multiplies creativity.  
	\- The past can be a powerful source of innovation.  
	  
	Prompt used:  
	“We crash zoom into an immersive scene, where a mother holding a magical wooden spoon is fighting off a ferocious dragon.”  
	  
	💭 My Take  
	The future of creativity isn’t inventing from nothing.  
	It’s remembering differently.  
	AI lets us reimagine old ideas — giving them new dimensions and new life.  
	  
	What’s the weirdest or oldest idea you’ve ever brought back with AI?  
	  
	Video: Rory Flynn  
	  
	[hashtag AI](https://www.linkedin.com/search/results/all/?keywords=%23ai&origin=HASH_TAG_FROM_FEED) [hashtag Creativity](https://www.linkedin.com/search/results/all/?keywords=%23creativity&origin=HASH_TAG_FROM_FEED) [hashtag Innovation](https://www.linkedin.com/search/results/all/?keywords=%23innovation&origin=HASH_TAG_FROM_FEED) [hashtag Midjourney](https://www.linkedin.com/search/results/all/?keywords=%23midjourney&origin=HASH_TAG_FROM_FEED) [hashtag Storytelling](https://www.linkedin.com/search/results/all/?keywords=%23storytelling&origin=HASH_TAG_FROM_FEED) [hashtag Technology](https://www.linkedin.com/search/results/all/?keywords=%23technology&origin=HASH_TAG_FROM_FEED) [hashtag HumanPotential](https://www.linkedin.com/search/results/all/?keywords=%23humanpotential&origin=HASH_TAG_FROM_FEED)
- ## Feed post number 31
	A teacher used AI to show her students as grown-ups in their dream jobs. 🤗  
	  
	The result?  
	A viral, heartwarming reel — and a powerful lesson about the human side of technology.  
	  
	AI didn’t just generate images.  
	It generated belief.  
	  
	When those kids saw themselves as doctors, artists, astronauts, and engineers, they weren’t just imagining the future — they were feeling it.  
	  
	And that matters.  
	Because psychology tells us that visualizing success makes it more achievable.  
	Now, AI can make that visualization vivid, personal, and real.  
	  
	📊 1 in 3 U.S. educators already use AI to personalize learning.  
	💡 Emotional storytelling with AI improves memory retention by 70%.  
	❤️ This teacher gave her students something few adults ever get — a visual future worth believing in.  
	  
	This is AI as empathy tech.  
	A tool not for replacing humans, but for amplifying hope, motivation, and imagination.  
	  
	👉 What if we used AI not just to optimize work — but to elevate people?  
	  
	[hashtag AI](https://www.linkedin.com/search/results/all/?keywords=%23ai&origin=HASH_TAG_FROM_FEED) [hashtag Education](https://www.linkedin.com/search/results/all/?keywords=%23education&origin=HASH_TAG_FROM_FEED) [hashtag Innovation](https://www.linkedin.com/search/results/all/?keywords=%23innovation&origin=HASH_TAG_FROM_FEED) [hashtag Empathy](https://www.linkedin.com/search/results/all/?keywords=%23empathy&origin=HASH_TAG_FROM_FEED) [hashtag TechnologyForGood](https://www.linkedin.com/search/results/all/?keywords=%23technologyforgood&origin=HASH_TAG_FROM_FEED) [hashtag FutureOfWork](https://www.linkedin.com/search/results/all/?keywords=%23futureofwork&origin=HASH_TAG_FROM_FEED) [hashtag Leadership](https://www.linkedin.com/search/results/all/?keywords=%23leadership&origin=HASH_TAG_FROM_FEED)
	<video src="blob:https://www.linkedin.com/6c2e5dd5-23ba-49d5-9d9a-babf2cfed30c"></video>
	Loaded: 7.43%
	Stream Type LIVE
	Remaining time 0:53
- ## Feed post number 32
	What I Learned at Dreamforce 2025: Where AI Dreams Meet Human Reality  
	  
	As a [hashtag SalesforcePartner](https://www.linkedin.com/search/results/all/?keywords=%23salesforcepartner&origin=HASH_TAG_FROM_FEED), last week, I stood in San Francisco among 45,000 dreamers, builders, and believers.  
	  
	It wasn’t just another tech event — it was a glimpse of the decade ahead.  
	[hashtag Sponsored](https://www.linkedin.com/search/results/all/?keywords=%23sponsored&origin=HASH_TAG_FROM_FEED)  
	  
	Yes, the technology was impressive.  
	But what stayed with me was something deeper: the humanity behind it.  
	  
	In this article, I take you inside Dreamforce 2025 — through the people, the breakthroughs, and the moments that are shaping the future of AI.  
	  
	Here’s what you’ll discover:  
	● The arrival of Agentforce 360 and Vibes, making AI agents faster, smarter, and accessible to everyone:[https://lnkd.in/ey4-\_Xrq](https://lnkd.in/ey4-_Xrq)  
	● Dario Amodei’s vision for “machines of loving grace” and the ethics of agentic systems.  
	● Sundar Pichai’s perspective on digital superintelligence as the next great collaborator.  
	● How FedEx is turning its 500,000 employees into AI-augmented problem solvers.  
	● Dell’s framework to scale AI: simplify, standardize, reimagine, then apply technology.  
	● [Will.i.am](http://will.i.am/) ’s project building cars from scratch to create an agentic OS for mobility.  
	● And a final moment with Metallica, reminding us of what technology can enhance but never replace — the power of human connection.  
	  
	The takeaway: the future doesn’t belong to those with the most advanced AI, but to those who design the strongest partnerships between humans and agents.  
	  
	[hashtag DF25](https://www.linkedin.com/search/results/all/?keywords=%23df25&origin=HASH_TAG_FROM_FEED) [hashtag sponsored](https://www.linkedin.com/search/results/all/?keywords=%23sponsored&origin=HASH_TAG_FROM_FEED) [hashtag AgenticEnterprise](https://www.linkedin.com/search/results/all/?keywords=%23agenticenterprise&origin=HASH_TAG_FROM_FEED) [hashtag SalesforcePartner](https://www.linkedin.com/search/results/all/?keywords=%23salesforcepartner&origin=HASH_TAG_FROM_FEED) [hashtag AITransformation](https://www.linkedin.com/search/results/all/?keywords=%23aitransformation&origin=HASH_TAG_FROM_FEED) [hashtag Leadership](https://www.linkedin.com/search/results/all/?keywords=%23leadership&origin=HASH_TAG_FROM_FEED) [hashtag Innovation](https://www.linkedin.com/search/results/all/?keywords=%23innovation&origin=HASH_TAG_FROM_FEED) [hashtag FutureOfWork](https://www.linkedin.com/search/results/all/?keywords=%23futureofwork&origin=HASH_TAG_FROM_FEED) [hashtag HumanAIPartnership](https://www.linkedin.com/search/results/all/?keywords=%23humanaipartnership&origin=HASH_TAG_FROM_FEED)
	[![](https://media.licdn.com/dms/image/v2/D4E12AQGKBwzSzABFaQ/article-cover_image-shrink_600_2000/B4EZoL7THFKsAU-/0/1761136687108?e=1764201600&v=beta&t=g-02f-PtXiH2NUgEcTRtS93WZLzXy02Uq2J3DAhwo8U)](https://www.linkedin.com/pulse/my-dreamforce-2025-journey-where-ai-dreams-meet-human-pascal-bornet-dma4e?trackingId=GADUIno9uFdVbs0tBqtKYg%3D%3D)
			[IRREPLACEABLE with AI](https://www.linkedin.com/newsletters/irreplaceable-with-ai-6722452520993734656)
	My Dreamforce 2025 Journey: Where AI Dreams Meet Human Reality
	Pascal BORNET
- ## Feed post number 33
	ChatGPT Atlas Just Changed the Meaning of “Browsing.”  
	  
	When I first read about Atlas — a browser built around ChatGPT — it genuinely stopped me mid-scroll.  
	  
	For decades, the browser has been our window to the web.  
	  
	Now it’s becoming the assistant that looks through the window for us.  
	  
	I’ve spent years relying on browsers as my launchpad for learning.  
	  
	But this feels different — like watching the act of exploration itself get automated.  
	  
	In my opinion, that shift is bigger than it sounds.  
	  
	Because once your browser understands what you’re trying to do, it stops being a tool and starts becoming a partner.  
	  
	Atlas doesn’t just fetch pages — it reads them, remembers them, and acts on them.  
	→ It recalls what jobs you searched last week.  
	→ It summarizes trends before you ask.  
	→ It even shops, plans, or researches while you work.  
	  
	That’s incredible — but also unsettling.  
	If AI begins deciding what we should find, will we still be explorers of the web… or just passengers?  
	  
	At what point does convenience quietly become control?  
	The Solution  
	In my view, the question isn’t “Can ChatGPT browse for me?”  
	  
	It’s “Should it?”  
	  
	My approach: use Atlas not as a replacement, but as a reflector.  
	→ Let it handle the clutter — not the curiosity.  
	→ Let it simplify — but not substitute — your search.  
	→ Always ask, question, and verify.  
	  
	Because the future of browsing isn’t about outsourcing thinking — it’s about amplifying it.  
	  
	[hashtag AI](https://www.linkedin.com/search/results/all/?keywords=%23ai&origin=HASH_TAG_FROM_FEED) [hashtag ChatGPTAtlas](https://www.linkedin.com/search/results/all/?keywords=%23chatgptatlas&origin=HASH_TAG_FROM_FEED) [hashtag FutureOfWork](https://www.linkedin.com/search/results/all/?keywords=%23futureofwork&origin=HASH_TAG_FROM_FEED) [hashtag Ethics](https://www.linkedin.com/search/results/all/?keywords=%23ethics&origin=HASH_TAG_FROM_FEED) [hashtag Automation](https://www.linkedin.com/search/results/all/?keywords=%23automation&origin=HASH_TAG_FROM_FEED) [hashtag Technology](https://www.linkedin.com/search/results/all/?keywords=%23technology&origin=HASH_TAG_FROM_FEED)
- ## Feed post number 34
	In 1983, Steve Jobs predicted LLMs. 🤯  
	  
	He said:  
	  
	“You can’t ask Aristotle a question.”  
	  
	That line wasn’t just poetic. It was prophetic.  
	  
	Back then, Jobs loved how books gave us direct access to great minds — but he hated their limitation.  
	Books couldn’t respond. They couldn’t evolve the conversation.  
	  
	So he imagined something radical for his time:  
	🧠 A machine that could capture the way a thinker sees the world.  
	💬 One that could answer your questions — even after that thinker was gone.  
	  
	Fast-forward to today.  
	We’re living that dream.  
	We ask. They respond. They learn.  
	  
	And here’s what fascinates me most 👇  
	Jobs wasn’t predicting a product.  
	He was describing a philosophy — the continuity of human intelligence through technology.  
	  
	AI doesn’t replace thinkers.  
	It extends their thinking across time.  
	  
	Imagine if every great mind — from Aristotle to Einstein — had left behind a living model of their ideas.  
	How much faster would humanity learn?  
	  
	Now we can.  
	That’s the real revolution.  
	  
	So let me ask you:  
	Whose worldview would you preserve in a machine — and why?  
	  
	[hashtag AI](https://www.linkedin.com/search/results/all/?keywords=%23ai&origin=HASH_TAG_FROM_FEED) [hashtag Innovation](https://www.linkedin.com/search/results/all/?keywords=%23innovation&origin=HASH_TAG_FROM_FEED) [hashtag FutureOfWork](https://www.linkedin.com/search/results/all/?keywords=%23futureofwork&origin=HASH_TAG_FROM_FEED) [hashtag Leadership](https://www.linkedin.com/search/results/all/?keywords=%23leadership&origin=HASH_TAG_FROM_FEED) [hashtag Technology](https://www.linkedin.com/search/results/all/?keywords=%23technology&origin=HASH_TAG_FROM_FEED) [hashtag HistoryOfAI](https://www.linkedin.com/search/results/all/?keywords=%23historyofai&origin=HASH_TAG_FROM_FEED) [hashtag Learning](https://www.linkedin.com/search/results/all/?keywords=%23learning&origin=HASH_TAG_FROM_FEED)
	<video src="blob:https://www.linkedin.com/5e71502b-9ac3-4cc4-bf3f-b5bebbb25b28"></video>
	Loaded: 5.13%
	Stream Type LIVE
	Remaining time 1:18
- ## Feed post number 35
	Humanoids just did the impossible.  
	  
	They climbed stairs — without LIDAR, GPS, or pre-coded choreography.  
	Just cameras, real-time vision, and reflexes faster than a blink.  
	  
	But here’s the part most people miss 👇  
	Walking is one of the hardest problems in robotics.  
	  
	Every step means:  
	\- balancing dozens of joints in motion,  
	\- reading light, shadow, and texture in milliseconds,  
	\- reacting instantly to uneven ground.  
	  
	It’s not just movement — it’s decision-making in motion.  
	  
	Boston Dynamics did flips.  
	Tesla showed renders.  
	But this?  
	This is true autonomy — vision only, no maps, no pre-scripted path.  
	  
	And that’s what makes it fascinating.  
	Machines are learning to walk the way we did — through trial, feedback, and adaptation.  
	  
	When robots can walk, they can work anywhere: factories, disaster zones, hospitals.  
	That changes everything.  
	  
	Source: Ulrich M.  
	  
	[hashtag AI](https://www.linkedin.com/search/results/all/?keywords=%23ai&origin=HASH_TAG_FROM_FEED) [hashtag Robotics](https://www.linkedin.com/search/results/all/?keywords=%23robotics&origin=HASH_TAG_FROM_FEED) [hashtag Automation](https://www.linkedin.com/search/results/all/?keywords=%23automation&origin=HASH_TAG_FROM_FEED) [hashtag FutureOfWork](https://www.linkedin.com/search/results/all/?keywords=%23futureofwork&origin=HASH_TAG_FROM_FEED) [hashtag Innovation](https://www.linkedin.com/search/results/all/?keywords=%23innovation&origin=HASH_TAG_FROM_FEED) [hashtag Technology](https://www.linkedin.com/search/results/all/?keywords=%23technology&origin=HASH_TAG_FROM_FEED)
	<video src="blob:https://www.linkedin.com/1954fa32-25bf-457b-b061-423eb1fbf551"></video>
	Loaded: 0.00%
	Stream Type LIVE
	Remaining time 1:30
- ## Feed post number 36
	We used to build robots that obeyed.  
	Now we’re building ones that compete.  
	  
	This robot isn’t running a script.  
	  
	It’s reading a shuttlecock midair, predicting trajectories, adjusting angles — and returning the shot.  
	  
	That’s not programming. That’s instinct.  
	  
	And here’s the part that I can’t stop thinking about:  
	→ When machines start playing with us, how long before they start playing against us?  
	→ If performance is now shared between human intuition and machine precision — who really wins?  
	→ Are we teaching robots to assist, or to aspire?  
	  
	Because we’ve already taught AI how to speak, code, and draw.  
	  
	Now we’re teaching it how to move.  
	  
	And once machines move with purpose, every industry — from sports to surgery — becomes a new playing field.  
	  
	The question is no longer can they do it.  
	It’s should they?  
	  
	The solution isn’t to stop teaching machines — it’s to start teaching values alongside capability.  
	  
	If we train AI for precision without purpose, we risk brilliance without boundaries.  
	  
	Reward engineering shouldn’t just optimize performance — it should encode principles.  
	  
	Because the future of AI won’t depend on how fast it learns — but on what we choose to reward.  
	  
	[hashtag AI](https://www.linkedin.com/search/results/all/?keywords=%23ai&origin=HASH_TAG_FROM_FEED) [hashtag Robotics](https://www.linkedin.com/search/results/all/?keywords=%23robotics&origin=HASH_TAG_FROM_FEED) [hashtag ReinforcementLearning](https://www.linkedin.com/search/results/all/?keywords=%23reinforcementlearning&origin=HASH_TAG_FROM_FEED) [hashtag RewardEngineering](https://www.linkedin.com/search/results/all/?keywords=%23rewardengineering&origin=HASH_TAG_FROM_FEED) [hashtag AIFuture](https://www.linkedin.com/search/results/all/?keywords=%23aifuture&origin=HASH_TAG_FROM_FEED) [hashtag Ethics](https://www.linkedin.com/search/results/all/?keywords=%23ethics&origin=HASH_TAG_FROM_FEED) [hashtag AIAlignment](https://www.linkedin.com/search/results/all/?keywords=%23aialignment&origin=HASH_TAG_FROM_FEED)
- ## Feed post number 37
- ## Feed post number 38
	⚙️ The U.S. Economy Runs on GPUs Now  
	  
	Harvard economist Jason Furman says 92% of U.S. GDP growth in early 2025 came from AI-related data centers.  
	  
	Without them? Growth would’ve been 0.1%. Practically zero.  
	  
	At first, it sounds like a win — proof that AI is driving real value.  
	  
	But the more I sat with it, the stranger it felt.  
	  
	Because for the first time in history, machines — not people — are powering prosperity.  
	  
	Growth isn’t coming from human creativity, innovation, or productivity anymore.  
	  
	It’s coming from racks of humming servers and rivers of electricity.  
	  
	We’re no longer building around talent.  
	  
	We’re building around compute.  
	→ What happens when the economy’s health depends on energy, not effort?  
	→ When growth rises with GPUs, not with human ingenuity?  
	→ When progress stops being about people altogether?  
	  
	In my opinion, this isn’t just economic evolution — it’s a quiet trade-off.  
	  
	We’re outsourcing growth itself.  
	  
	And while that might look efficient on paper, it feels hollow in spirit.  
	  
	If AI is now the backbone of the economy, we need to build a human spine alongside it.  
	✅ Invest in capability, not just capacity. The next wave of GDP shouldn’t only come from data centers — it should come from how humans use them.  
	✅ Reward creation, not consumption. Growth that only counts infrastructure misses the real metric: human progress.  
	✅ Power balance. If compute drives growth, renewable energy must sustain it. Otherwise, prosperity becomes a power bill.  
	Because the real question isn’t how far AI can push GDP —  
	  
	It’s whether we can still call it growth when humans are no longer the ones growing.  
	  
	[hashtag AI](https://www.linkedin.com/search/results/all/?keywords=%23ai&origin=HASH_TAG_FROM_FEED) [hashtag Economy](https://www.linkedin.com/search/results/all/?keywords=%23economy&origin=HASH_TAG_FROM_FEED) [hashtag Innovation](https://www.linkedin.com/search/results/all/?keywords=%23innovation&origin=HASH_TAG_FROM_FEED) [hashtag DataCenters](https://www.linkedin.com/search/results/all/?keywords=%23datacenters&origin=HASH_TAG_FROM_FEED) [hashtag FutureOfWork](https://www.linkedin.com/search/results/all/?keywords=%23futureofwork&origin=HASH_TAG_FROM_FEED) [hashtag Ethics](https://www.linkedin.com/search/results/all/?keywords=%23ethics&origin=HASH_TAG_FROM_FEED)
- ## Feed post number 39
	🚀 The Success Trap of Automation  
	  
	78% of workers say automation boosts productivity.  
	Yet most companies hit a wall they never see coming.  
	  
	Why? Because 66% automate in silos.  
	Finance automates one way. HR another. Operations a third.  
	Disconnected systems. Disconnected growth.  
	  
	This is the success trap:  
	You scale fast… until everything breaks.  
	Customer service can’t see order history.  
	Finance loses sight of inventory.  
	Data turns into chaos.  
	  
	The winners do one thing differently —  
	they automate for connection, not isolation.  
	  
	When every function shares data and workflows,  
	growth doesn’t create friction — it creates strength.  
	  
	  
	💡This post is sponsored by [SAP](https://www.linkedin.com/company/sap/).  
	SAP Business Suite unifies automation and data, so every new customer, employee, or location makes your system stronger — not weaker.  
	  
	  
	👉 Learn how it works here:[https://lnkd.in/eEaSyDK7](https://lnkd.in/eEaSyDK7)  
	  
	[hashtag SAPAmbassador](https://www.linkedin.com/search/results/all/?keywords=%23sapambassador&origin=HASH_TAG_FROM_FEED) [hashtag Automation](https://www.linkedin.com/search/results/all/?keywords=%23automation&origin=HASH_TAG_FROM_FEED) [hashtag AI](https://www.linkedin.com/search/results/all/?keywords=%23ai&origin=HASH_TAG_FROM_FEED) [hashtag SAP](https://www.linkedin.com/search/results/all/?keywords=%23sap&origin=HASH_TAG_FROM_FEED) [hashtag DigitalTransformation](https://www.linkedin.com/search/results/all/?keywords=%23digitaltransformation&origin=HASH_TAG_FROM_FEED) [hashtag AgenticAI](https://www.linkedin.com/search/results/all/?keywords=%23agenticai&origin=HASH_TAG_FROM_FEED)
	<video src="blob:https://www.linkedin.com/a747409f-9ee3-4cac-be7f-8d9f3c811c21"></video>
	Loaded: 0.00%
	Stream Type LIVE
	Remaining time 1:00
- ## Feed post number 40
	Robots are changing how athletes train.  
	But what fascinates me isn’t the robots — it’s what they reveal about humans.  
	  
	Instead of static cones, players now face dynamic machines that move, react, and learn in real time.  
	Football systems like SKILLSLAB, Rezzil, and Trailblazer Training Bots help players sharpen reaction time and decision-making under pressure.  
	Basketball robots perfect shooting form.  
	Tennis machines vary spin and speed to mimic unpredictable opponents.  
	  
	But here’s the deeper insight:  
	Technology is no longer training athletes — it’s training intelligence.  
	  
	By tracking thousands of data points per session, these systems help athletes build intuition faster, pushing decision-making closer to instinct.  
	Reaction times improve by up to 20%.  
	Repetition triples.  
	Learning becomes measurable, immediate, and personalized.  
	  
	Personally, this fascinates me because it mirrors how AI is reshaping work and leadership.  
	Humans and machines are no longer competing — they’re co-training.  
	Each improving the other.  
	  
	The same principles that make great athletes — feedback loops, adaptability, resilience — will soon define great professionals.  
	  
	Sports are showing us the future of human performance.  
	Not man versus machine.  
	Man with machine.  
	  
	Content Credit to Alexey Navolokin  
	  
	[hashtag AI](https://www.linkedin.com/search/results/all/?keywords=%23ai&origin=HASH_TAG_FROM_FEED) [hashtag Sports](https://www.linkedin.com/search/results/all/?keywords=%23sports&origin=HASH_TAG_FROM_FEED) [hashtag HumanPerformance](https://www.linkedin.com/search/results/all/?keywords=%23humanperformance&origin=HASH_TAG_FROM_FEED) [hashtag Leadership](https://www.linkedin.com/search/results/all/?keywords=%23leadership&origin=HASH_TAG_FROM_FEED) [hashtag Innovation](https://www.linkedin.com/search/results/all/?keywords=%23innovation&origin=HASH_TAG_FROM_FEED) [hashtag FutureOfWork](https://www.linkedin.com/search/results/all/?keywords=%23futureofwork&origin=HASH_TAG_FROM_FEED) [hashtag AgenticAI](https://www.linkedin.com/search/results/all/?keywords=%23agenticai&origin=HASH_TAG_FROM_FEED)
	<video src="blob:https://www.linkedin.com/61e90d7f-8b17-4ab5-8caa-bd37661c6e31"></video>
	Loaded: 10.81%
	Stream Type LIVE
	Remaining time 0:36
- ## Feed post number 41
	What if you could slice open the periodic table?  
	Not metaphorically. Literally — and see what elements look like from the inside.  
	  
	These AI-generated videos make it possible:  
	\- Gallium melting like chocolate.  
	\- Sulfur snapping like glass candy.  
	\- Gold glowing from the inside out.  
	  
	For me, this is more than just science.  
	It’s a window into how I learn.  
	  
	I’ve always been a visual learner.  
	When I see something, I don’t just understand it — I remember it.  
	That’s why I find this so powerful:  
	AI isn’t changing what we know. It’s changing how we connect with knowledge.  
	  
	🧠 Visual learning engages emotion, curiosity, and long-term memory — far more than words alone ever could.  
	And when you combine that with AI, you turn abstract ideas into tangible experiences.  
	  
	That’s the kind of learning that stays with you.  
	  
	What about you — do you learn better by reading, hearing, or seeing?  
	  
	DM for credits/removal.  
	  
	[hashtag AI](https://www.linkedin.com/search/results/all/?keywords=%23ai&origin=HASH_TAG_FROM_FEED) [hashtag Learning](https://www.linkedin.com/search/results/all/?keywords=%23learning&origin=HASH_TAG_FROM_FEED) [hashtag Education](https://www.linkedin.com/search/results/all/?keywords=%23education&origin=HASH_TAG_FROM_FEED) [hashtag Innovation](https://www.linkedin.com/search/results/all/?keywords=%23innovation&origin=HASH_TAG_FROM_FEED) [hashtag AIinEducation](https://www.linkedin.com/search/results/all/?keywords=%23aiineducation&origin=HASH_TAG_FROM_FEED) [hashtag Science](https://www.linkedin.com/search/results/all/?keywords=%23science&origin=HASH_TAG_FROM_FEED) [hashtag Creativity](https://www.linkedin.com/search/results/all/?keywords=%23creativity&origin=HASH_TAG_FROM_FEED) [hashtag FutureOfWork](https://www.linkedin.com/search/results/all/?keywords=%23futureofwork&origin=HASH_TAG_FROM_FEED)
	<video src="blob:https://www.linkedin.com/70059540-8956-47f0-92b2-732367fe29a7"></video>
	Loaded: 0.00%
	Stream Type LIVE
	Remaining time 1:06
- ## Feed post number 42
	AI, Privacy, and the Photos We’ll Never Get Back  
	  
	Here’s a question that divides almost everyone I talk to:  
	  
	If AI learns from our online lives — are we advancing humanity, or erasing what it means to be human?  
	  
	We love sharing moments — birthdays, sunsets, family trips.  
	  
	It feels innocent. But once we post them, those memories stop belonging fully to us.  
	  
	They become part of the internet’s bloodstream — scraped, analyzed, and used to train models that might one day imitate our very emotions.  
	  
	Some people say that’s a fair trade.  
	  
	They argue: “AI needs data to learn. Every post helps technology understand people better.”  
	  
	In that view, your photos, your voice, your words — they’re contributions to collective progress.  
	  
	Others push back:  
	“Progress at the cost of privacy isn’t progress at all.”  
	  
	They believe consent still matters — that no system should absorb our lives without permission, no matter how “intelligent” the outcome.  
	  
	Personally, I’m caught in the middle.  
	  
	I love the promise of AI that understands humans — but not at the price of becoming its dataset.  
	  
	If everything we share trains machines, where do we end and the algorithm begin?  
	  
	Maybe this is the real dilemma of our time:  
	  
	To teach machines empathy, we may have to give them our memories.  
	  
	But to protect our humanity, we might have to stop sharing the moments that make us human.  
	  
	So what’s the right choice?  
	  
	Progress — or privacy?  
	  
	[hashtag AI](https://www.linkedin.com/search/results/all/?keywords=%23ai&origin=HASH_TAG_FROM_FEED) [hashtag Privacy](https://www.linkedin.com/search/results/all/?keywords=%23privacy&origin=HASH_TAG_FROM_FEED) [hashtag Ethics](https://www.linkedin.com/search/results/all/?keywords=%23ethics&origin=HASH_TAG_FROM_FEED) [hashtag DigitalWellbeing](https://www.linkedin.com/search/results/all/?keywords=%23digitalwellbeing&origin=HASH_TAG_FROM_FEED) [hashtag ResponsibleAI](https://www.linkedin.com/search/results/all/?keywords=%23responsibleai&origin=HASH_TAG_FROM_FEED) [hashtag DataProtection](https://www.linkedin.com/search/results/all/?keywords=%23dataprotection&origin=HASH_TAG_FROM_FEED)  
	Video: theaipage
	<video src="blob:https://www.linkedin.com/5154ce66-1988-4c33-934b-3fee75fcf7e9"></video>
	Loaded: 0.00%
	Stream Type LIVE
	Remaining time 1:54
- ## Feed post number 56
	🧠 YOUR BRAIN RUNS ON 12 WATTS — AI NEEDS 2.7 BILLION  
	  
	When I read this comparison, I had to pause:  
	  
	Your brain runs on 12 watts — less than a lightbulb.  
	  
	AI systems doing similar work? 2.7 billion watts.  
	  
	At first, it sounds like an efficiency issue.  
	  
	But the more I thought about it, the more I realized — this isn’t about power. It’s about design.  
	  
	The brain doesn’t rely on brute force.  
	  
	It thrives on elegance: 86 billion neurons working in harmony, adapting and learning with near-zero waste.  
	  
	AI, on the other hand, is still built on raw computation — impressive, but inefficient.  
	  
	And that’s what fascinates me.  
	  
	We’ve created systems that process better, but still struggle to perceive.  
	  
	They mimic intelligence, yet lack the grace of human thought — that quiet, intuitive leap that happens without data or code.  
	  
	That’s where the next frontier lies:  
	  
	👉 Neuromorphic computing — chips designed to think like the brain, not just for it.  
	  
	It’s a shift from scaling servers to understanding cognition itself.  
	  
	Here’s what I take from it:  
	✅ Real intelligence isn’t measured in watts, but in wisdom per watt.  
	✅ The brain’s power lies in efficiency, adaptability, and intent — not speed.  
	✅ The future of AI depends on learning those same principles from nature.  
	  
	Because the real question isn’t whether AI can outthink us —  
	  
	It’s whether we can build it to think with purpose, not just power.  
	  
	So let me ask you:  
	  
	If nature already solved intelligence with a 12-watt design — what should we be optimizing for next?  
	  
	[hashtag AI](https://www.linkedin.com/search/results/all/?keywords=%23ai&origin=HASH_TAG_FROM_FEED) [hashtag Neuroscience](https://www.linkedin.com/search/results/all/?keywords=%23neuroscience&origin=HASH_TAG_FROM_FEED) [hashtag FutureOfIntelligence](https://www.linkedin.com/search/results/all/?keywords=%23futureofintelligence&origin=HASH_TAG_FROM_FEED) [hashtag Innovation](https://www.linkedin.com/search/results/all/?keywords=%23innovation&origin=HASH_TAG_FROM_FEED) [hashtag TechEthics](https://www.linkedin.com/search/results/all/?keywords=%23techethics&origin=HASH_TAG_FROM_FEED) [hashtag PascalBornet](https://www.linkedin.com/search/results/all/?keywords=%23pascalbornet&origin=HASH_TAG_FROM_FEED)
- ## Feed post number 57
- ## Feed post number 58
	🔥 The Rules of Leadership Just Broke — Can You Lead Intelligence, Not People?  
	  
	I can see it: leadership is changing — quietly, radically.  
	For decades, delegation meant managing people.  
	Now, it means designing intelligence.  
	And this changes everything about how we lead.  
	  
	And recent research proves it 👇  
	  
	🧭 1. Delegation is now design.  
	Top leaders don’t tell agents how to work — they define why and within what limits.  
	Micromanaging an agent’s process cuts effectiveness by 70%.  
	(MIT Future of Work Initiative, 2025)  
	  
	⛓️ 2. Alignment is the new strategy.  
	The biggest reason agentic AI projects fail?  
	Not the tech — but leadership misalignment.  
	Fuzzy goals cause agents to drift and deliver the wrong outcomes.  
	(Brookings Institution, AI Governance Lab, 2025)  
	  
	📊 3. The org chart is dead.  
	The new metric isn’t headcount — it’s intelligence capacity:  
	the combined problem-solving power of humans and autonomous agents.  
	(Gartner, 2025)  
	  
	\>> That’s why Cassie Kozyrkov, Brian Evergreen, and I created the course: ”Agentic Artificial Intelligence for Leaders.” Join us:[https://zurl.co/iP8Vf](https://zurl.co/iP8Vf). Just a few seats remaining. We look forward to having you!  
	  
	Because the next era of leadership isn’t about managing people.  
	It’s about leading intelligence.  
	  
	[hashtag agenticAI](https://www.linkedin.com/search/results/all/?keywords=%23agenticai&origin=HASH_TAG_FROM_FEED) [hashtag leadership](https://www.linkedin.com/search/results/all/?keywords=%23leadership&origin=HASH_TAG_FROM_FEED) [hashtag AI](https://www.linkedin.com/search/results/all/?keywords=%23ai&origin=HASH_TAG_FROM_FEED)
- ## Feed post number 59
	🤯 A Rubik’s Cube that solves itself!  
	  
	Inventor Takashi Kaburagi created a 3D-printed cube powered by intelligent servo motors hidden at its core—programmed to find the solution on their own.  
	  
	It’s fun, quirky, and brilliant. But it’s also a symbol of something much bigger.  
	  
	For decades, the Rubik’s Cube has represented human ingenuity and problem-solving.  
	Now, we’ve built a version where the puzzle solves itself.  
	  
	👉 The lesson:  
	\- We are entering an age where systems no longer wait for us to solve problems.  
	\- With AI, automation, and robotics, problems will increasingly be identified, analyzed, and resolved autonomously.  
	\- The challenge for us humans is no longer just solving problems, but framing the right problems to solve.  
	  
	In a world where cubes can solve themselves, the real value lies in the questions we ask.  
	  
	So here’s mine for you:  
	Are you training yourself and your teams to think less like problem-solvers… and more like problem-framers?  
	  
	[hashtag AI](https://www.linkedin.com/search/results/all/?keywords=%23ai&origin=HASH_TAG_FROM_FEED) [hashtag Innovation](https://www.linkedin.com/search/results/all/?keywords=%23innovation&origin=HASH_TAG_FROM_FEED) [hashtag Automation](https://www.linkedin.com/search/results/all/?keywords=%23automation&origin=HASH_TAG_FROM_FEED) [hashtag Leadership](https://www.linkedin.com/search/results/all/?keywords=%23leadership&origin=HASH_TAG_FROM_FEED) [hashtag FutureOfWork](https://www.linkedin.com/search/results/all/?keywords=%23futureofwork&origin=HASH_TAG_FROM_FEED) [hashtag Creativity](https://www.linkedin.com/search/results/all/?keywords=%23creativity&origin=HASH_TAG_FROM_FEED)
	<video src="blob:https://www.linkedin.com/61e18974-e7b8-4d30-add3-9e3d819e3dca"></video>
	Loaded: 0.00%
	Stream Type LIVE
	Remaining time 0:43
- ## Feed post number 60
	“Same tools. Different thinking.”  
	  
	I love this short video by Arpit Singh — because it exposes a truth few realize:  
	⚡ Tools don’t create innovation. Thinking does.  
	  
	Here’s something most people don’t know:  
	In every major AI breakthrough — from DeepMind’s AlphaGo to Tesla’s Autopilot — the algorithms were not unique.  
	They were open source. Public. Available to everyone.  
	  
	What made the difference wasn’t access to better tech — it was the courage to ask a different question.  
	DeepMind didn’t ask, “How can we play Go better?”  
	They asked, “Can an algorithm teach itself mastery?”  
	That’s a shift from execution to imagination.  
	  
	And that’s where true innovation lives.  
	  
	👉 My takeaway:  
	Don’t just teach your teams to use tools.  
	Teach them to challenge assumptions, reframe problems, and imagine new outcomes.  
	  
	AI isn’t the revolution.  
	How we think with AI is.  
	  
	[hashtag AI](https://www.linkedin.com/search/results/all/?keywords=%23ai&origin=HASH_TAG_FROM_FEED) [hashtag Innovation](https://www.linkedin.com/search/results/all/?keywords=%23innovation&origin=HASH_TAG_FROM_FEED) [hashtag Leadership](https://www.linkedin.com/search/results/all/?keywords=%23leadership&origin=HASH_TAG_FROM_FEED) [hashtag FutureOfWork](https://www.linkedin.com/search/results/all/?keywords=%23futureofwork&origin=HASH_TAG_FROM_FEED) [hashtag Mindset](https://www.linkedin.com/search/results/all/?keywords=%23mindset&origin=HASH_TAG_FROM_FEED) [hashtag AgenticAI](https://www.linkedin.com/search/results/all/?keywords=%23agenticai&origin=HASH_TAG_FROM_FEED) [hashtag Creativity](https://www.linkedin.com/search/results/all/?keywords=%23creativity&origin=HASH_TAG_FROM_FEED) [hashtag HumanPotential](https://www.linkedin.com/search/results/all/?keywords=%23humanpotential&origin=HASH_TAG_FROM_FEED)