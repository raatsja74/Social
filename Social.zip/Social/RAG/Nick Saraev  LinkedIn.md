---
title: "(26) Activity | Nick Saraev | LinkedIn"
link: "https://www.linkedin.com/in/nick-saraev/recent-activity/all/"
published:
created: 2025-11-04
description:
tags:
  - "content-creation"
---
## All activity

Loaded 40 Posts posts

- ## Feed post number 1
	My agency used to make $10k-$15k/mo. Once I understood this concept, we scaled to over $80,000/mo within a year.  
	  
	The Theory of Constraints.  
	  
	In business, you’re always going to have problems. It’s just part of the game. What is interesting is that the \*order you choose to solve those problems\* determines how fast you’ll grow.  
	  
	Every business is a pipeline.  
	  
	• Sales  
	• Marketing  
	• Onboarding  
	• Fulfillment  
	• Delivery  
	  
	And a pipeline only flows as fast as its narrowest point.  
	  
	If your bottleneck is X (say, your lead gen) your entire business will move at the speed of X (i.e you will only ever move as fast as you generate leads).  
	  
	The solution is simple:  
	  
	Spend 100% of your time fixing the constraint. Nothing else matters!  
	  
	Here’s the 4-step business growth flywheel to solve your bottlenecks:  
	  
	1\. Identify constraints  
	2\. Widen constraints  
	3\. Look for new ones  
	4\. Repeat  
	  
	(from "The Goal" - an ‘80s manufacturing book I read around half a decade ago that has since changed my life)  
	  
	Check the carousel for details.  
	  
	I’ll also link to a video in the comments where I discuss this in more detail.
	Your document has finished loading
- ## Feed post number 2
	For most people, upskilling is a waste of time.  
	  
	Everyone has heard “learn more skills”. And while I don’t disagree that building skills is useful, it tends to be an excuse: a “productive” way to procrastinate doing the activities that actually matter.  
	  
	Like talking to more people who have problems you can figure out and solve.  
	  
	You spend 8 hours watching YouTube tutorials about Make.com. You complete three Udemy courses. You build sample automations that nobody asked for. You redesign your website for the fourth time.  
	  
	And at the end of the week, what do you have?  
	  
	Zero customers. Zero dollars. And no differentiable results.  
	  
	In general, skills come when customers DEMAND them.  
	  
	And they’ll only demand them if you have lots of conversations and are getting market feedback.  
	  
	If you only have a few hours per day, here’s how I’d recommend spending your time:  
	  
	An Upwork application takes ~6 minutes (3 min vid, 90 sec reading, 90 sec submitting).  
	  
	That's 10 applications in an hour; approximately the same time as some filler Udemy module.  
	  
	10 prospective customers. With money. Who have problems you can solve. Right now.  
	  
	Another: cold email is intensive to set up, but easy to manage afterward.  
	  
	So… spend a few days setting it up, then spend 45 minutes per day managing cold email replies or iterating your campaign!  
	  
	If that’s all you do, then you’ll touch ~50+ prospects daily in less than 2 hours.  
	  
	Talk to more people = make more money.
- ## Feed post number 3
	Cold leads suck.  
	  
	But they make you a lot of money.  
	  
	Here’s why they make sense for beginner agency owners:  
	  
	• Systems are cheap to set up (~$400/m).  
	• You don't need any sort of following.  
	• Anybody, whether they're a kid living in a Bangladeshi slum, or a career professional looking to branch out on their own, can build a sustainable income through cold outreach.  
	  
	It’s the ultimate leveller.  
	  
	Status, class, income, looks—none of them matter.  
	  
	The only thing they care about is how good your messaging is.  
	  
	The downsides:  
	  
	It’s hard. You’re always fighting an uphill battle.  
	  
	I knocked thousands of doors when I was selling B2B marketing. And I’ve sent hundreds of thousands of cold emails. It’s safe to say my cold outreach experience is somewhere in the top 1%.  
	  
	Even then—it’s not fun.  
	  
	Despite how legitimate you may seem, there's usually always a big elephant in the room whispering "is this a scam?" into their ears 24/7.  
	  
	If you're just starting out in business, and don't have any sort of established track record, cold outreach is probably your biggest bang for buck/your highest ROI.  
	  
	There are few channels as dependable and consistent.  
	  
	Then once you have profit, you can invest in other channels (partners, content, communities, etc.).  
	  
	Cold leads to start.  
	  
	Warm leads long term.
- ## Feed post number 4
	I was still doing lead gen at $72K/month.  
	  
	• Solo operator  
	• Working 12+ hour days  
	• One VA handling admin  
	  
	Everyone thought I was crazy.  
	  
	"Dude, you're STILL sending cold emails? You're STILL applying to Upwork jobs?"  
	  
	Yeah. And here's why:  
	  
	The moment you stop, you die.  
	  
	That month I made:  
	  
	• ~$30K from retained clients  
	• $16.2K quarterly retainer (paid upfront)  
	• ~$30K from cold email projects  
	  
	One client alone paid me $20K that month.  
	  
	But I never stopped doing outreach.  
	  
	Because I've watched it happen dozens of times:  
	  
	You hit $20K/month, stop prospecting, and 6 months later you’re back at $8K wondering what happened.  
	  
	Looks like this:  
	  
	→ Stop lead gen  
	→ Pipeline empties  
	→ Revenue drops  
	→ Panic mode  
	→ Restart from scratch  
	  
	Painful.  
	  
	So instead, I recommend continuing with all the channels that are working for you. For me, that was Upwork and cold email.  
	  
	Upwork is linear. 5 minutes = 1 application.  
	  
	Cold email is exponential. Awful learning curve, but once you crack it, it scales independent of your time.  
	  
	I kept doing Upwork because it kept me sharp. Daily practice articulating value. And it was working.  
	  
	Cold email continued bringing in leads without much additional work.  
	  
	So back to the point of this post…  
	  
	When can you stop doing lead gen?  
	  
	Never.  
	  
	Even at $300K+/month with Maker School, I'm still thinking about it. Still testing channels. Still building systems.  
	  
	The people winning aren't the ones who stopped after their first few clients.  
	  
	They're the ones who made lead gen non-negotiable.
- ## Feed post number 5
	Your document has finished loading
- ## Feed post number 6
	"I feel uncomfortable asking clients about their revenue." Common question. But here’s the thing:  
	  
	If you don't know how much money your client makes, you can't help them make MORE money.  
	  
	And if you can't help them make more, you're just an order-taker.  
	  
	You want to be a consultant. Not an order-taker.  
	  
	So how do you ask for revenue?  
	  
	Here's the trick:  
	  
	Don't ask directly.  
	  
	I never say "How much money are you making?"  
	  
	Instead, I estimate and let them correct me.  
	  
	Here's how:  
	  
	"What are clients paying you? Around $7K?"  
	→ "Yeah, about that."  
	  
	"How many new clients per month?"  
	→ "Maybe one."  
	  
	"Average relationship length? Six months?"  
	→ "Yep."  
	  
	Then I do the math OUT LOUD:  
	  
	"So you're adding $42K in new revenue monthly (6 × $7K). Sound right?"  
	→ "Yeah, that's accurate."  
	  
	"How many existing clients?"  
	→ "About 10."  
	  
	"Got it. So probably $50-100K monthly?"  
	→ "Yep."  
	  
	I just got every number I needed.  
	  
	And they were happy to give it because I showed I understand their business.  
	  
	If asking about revenue makes you uncomfortable, that's a signal to do it MORE. Not less.  
	  
	The obstacle is the way.  
	  
	Discomfort just means "I haven't done this enough times yet."  
	  
	So here’s your challenge:  
	  
	Ask for your next 5 sales calls: Practice this estimation method.  
	  
	You’ll be far better at it afterward.  
	  
	Consultant > Order-Taker.
- ## Feed post number 8
- ## Feed post number 9
	The technical barriers are plummeting. So here are the 3 skills I’d focus on stacking if I wanted to start AI consulting in 2025/2026:  
	  
	Tech is no longer the moat.  
	  
	The most important set of skills are business skills.  
	  
	These are the 3 I’d focus on:  
	  
	1/ Interpersonal and sales skills  
	  
	Can you ask questions, diagnose problems, and demonstrate solutions in a compelling manner?  
	  
	As the tech moat continues to shrink, people will solve more problems for themselves. But if you can show them that you understand their business and more specifically, the problems they have, they’ll trust you to get the work done.  
	  
	Business skills are more valuable than tech skills in today’s economy.  
	  
	2/ Demand gen  
	  
	Can you take an idea and turn it into leads?  
	  
	Within the next 2 years, you’ll realistically have a business idea and have a product 24 hours later. Then the only thing that constitutes whether that business succeeds is whether you can generate demand for it.  
	  
	This will continue to become more valuable.  
	  
	3/ Systems thinking  
	  
	Can you engineer a system to solve problems?  
	  
	I don’t mean n8n workflows necessarily. I mean, can you think through a problem from start to finish and list out all the variables. Then can you sort the process by who solves each part—whether AI agent, owner, or employee?  
	  
	That’s where the value lies.  
	  
	If you’re looking to stack those three skills and land your first (or tenth) automation client, that’s what we focus on inside Maker School:[https://bit.ly/4l09oQQ](https://bit.ly/4l09oQQ)
	Captions are auto generated<video src="blob:https://www.linkedin.com/c5fa0a27-a1ed-4cfe-8ed1-903bb1842113"></video>
	Loaded: 4.19%
	Stream Type LIVE
	Remaining time 1:35
- ## Feed post number 10
	This is one of the most useful mental models I’ve found to guide my entrepreneurial decisions (steal it):  
	  
	Expected value.  
	  
	EV = I \* P.  
	  
	(Don’t let the equation scare you yet—give me 30 seconds!)  
	  
	I is impact and P is likelihood you’ll be successful.  
	  
	Example:  
	  
	• Starting the next social network a la Facebook: huge potential impacts ($10B) but tiny odds of success (maybe 0.01%). If we do the math, $10B x 0.01% = $1,000,000.  
	  
	• Starting a boutique marketing agency: low potential impact ($8M lifetime), but reasonably high odds of success (20%). If we do the math, $8M x 20% = $1,600,000.  
	  
	This makes it easy to make a rational decision.  
	  
	Here’re 3 ways you can use it your advantage:  
	  
	1\. Choose what to work on today  
	  
	You can use this to evaluate what activities to do today. Which marketing channels or campaigns to pursue. And which employees to hire.  
	  
	2\. Choose what company to start  
	  
	Compare impact & likelihood of success, like the Facebook vs agency example.  
	  
	3\. Choose whether to scale up or not  
	  
	You can look at the economics of a business—or an ad campaign—and decide if it’s worth spending more dollars on it.  
	  
	This mental model is why I decided to start building a brand, by the way.  
	  
	Massive potential impact, reasonable probability of success.
- ## Feed post number 11
	I keep getting this question:  
	  
	Agency or SaaS in 2025?  
	  
	Starting a SaaS as your first business is a terrible idea.  
	  
	Start an agency instead, even if your ultimate goal is SaaS.  
	  
	Here are 4 reasons why:  
	  
	1/ Money (10-20x faster revenue)  
	  
	• Agencies: $3K-$15K/month from 1 client  
	• SaaS: $10-20/month × need 500 customers for same revenue  
	• Cash flow lets you make real investment decisions  
	• Can fund your SaaS later with agency profits  
	  
	2/ Business fundamentals you learn  
	  
	• Client management → translates well to customer management  
	• Team management → hiring, leading people  
	• Project management → execution skills that transfer to building products  
	• Compresses "10 years of SaaS learning into 1.5 years of agency work"  
	  
	3/ The scrappy mindset  
	  
	• Bootstrapping forces you to respect every dollar  
	• Spending your own money ≠ spending investor money  
	• Profit-first mentality vs. unicorn-chasing mentality  
	• Most SaaS founders eat ramen and hate their lives for years  
	  
	4/ The lifestyle argument  
	  
	• Solve your near-term security first (Maslow's hierarchy)  
	• Stop worrying about rent → start thinking long-term  
	• High performers should make money fast, not chase unlikely dreams  
	  
	You don’t need to build the next Uber.  
	  
	If you’re like most people, you want to make more money and work less.  
	  
	Agency gets you there 100x faster than SaaS.
	<video src="blob:https://www.linkedin.com/9fecb488-9c32-47c1-b97e-733488e92f16"></video>
	Loaded: 2.46%
	Stream Type LIVE
	Remaining time 2:42
- ## Feed post number 12
	I make $300k+/mo from my Skool community.  
	  
	Here’s the secret to productivity:  
	  
	Eliminate friction.  
	  
	Seriously. Identify every piece of friction in your life. Then eliminate it.  
	  
	I call this the “lifestyle audit”.  
	  
	In Maker School, I have everyone do this on Day 7.  
	  
	Here’s how it works:  
	  
	Friction = anything that makes it harder to do what you want to do.  
	  
	Examples:  
	  
	• Your gym is 15 minutes away → you skip workouts  
	• Your phone is next to your bed → you scroll for 10 minutes every morning  
	• You don't have healthy snacks → you eat junk food  
	  
	Productivity is NOT about willpower.  
	  
	It’s about choice architecture - designing your environment so good decisions are automatic (and so bad decisions require effort).  
	  
	Go through this exercise:  
	  
	Set a timer for 60-minutes. Brainstorm friction points in each area:  
	  
	1\. Daily routine (morning, commute, evening)  
	2\. Hobbies and habits  
	3\. Physical space (home, workspace, car)  
	4\. Time and attention  
	5\. Blind spots  
	6\. Fears and anxieties  
	  
	Once you write them down, you can systematically eliminate them.  
	  
	I did this last November after a few frustrating months. I was more distracted, less productive, and substantially more irritable.  
	  
	Fast forward and 2025 has been an amazing year.  
	  
	I’d attribute a large portion of it to this exercise.  
	  
	PS - check out the comments if you want to see the full lifestyle audit I did.
- ## Feed post number 13
	How I built a 15+ person agency with no management skills (in 3 simple steps):  
	  
	1/ Praise in public, reprimand in private.  
	  
	Give feedback one-on-one. Always. Even if multiple people need the same message, deliver it individually. Nothing ruins trust faster than public criticism. Social shame is powerful.  
	  
	2/ It’s not about keeping everyone happy (The Effective Manager).  
	  
	There are two types of stress:  
	  
	• Distress: anxiety, panic, paralysis  
	• Eustress: excitement, energy, focus  
	  
	Good managers maximize eustress—provide enough challenge that your team does incredible work, but not so much they burn out.  
	  
	Most people want to grow their careers. They just need accountability.  
	  
	3/ Freedom & responsibility (No Rules Rules).  
	  
	Two options:  
	  
	• Rigid procedures that squeeze short-term efficiency  
	• Freedom to figure out the "how" while you define the "what"  
	  
	If you hire well, option two leads to constant improvement as people optimize their own workflows.  
	  
	Yes, it hurts the bottom line initially. But it massively increases it long-term.  
	  
	Check the carousel below for additional details  
	  
	♻️ Repost to your network if you found this helpful!
	Your document has finished loading
- ## Feed post number 14
	I made $38.41 on YouTube.  
	  
	To be clear:  
	  
	$38 would not change my life. But I was one month into my YouTube journey and knew content was a long game. So this was objective validation I was headed in the right direction.  
	  
	As you can see, this was back in March of 2024 (wild how much can change in 18 months!).  
	  
	Here are the first few lessons I learned on my YouTube journey:  
	  
	1/ CPM is several times the average  
	  
	My viewers were highly engaged and it confirmed I had a profitable niche.  
	  
	2/ Better editing = longer watch time  
	  
	Back in those days, my average view duration was right at 5 minutes (5:02 to be precise). I started to realize that catchy intros perform better.  
	  
	3/ Thumbnail changes had immediate impact  
	  
	Consistent branding + best practices (big text, white outline) = ~1% CTR improvement. I didn’t want to get too clickbaity, so was satisfied here.  
	  
	4/ Income mentions drive views  
	  
	The harsh reality is most people don’t have credibility so the videos where I mention my revenue clearly outperform those that don't. But you can’t overdo it or you seem spammy.  
	  
	Goal should be respect. Not popularity.  
	  
	Fast forward to today:  
	  
	It’s consistently bringing in ~$10k in monthly revenue from ads alone. And close to another $300k per month for Maker School.  
	  
	Sometimes all you need is a signal you’re headed in the right direction.
- ## Feed post number 15
	Here’s how I’m making $4M per year while keeping 92% of the profit (and how you can too):  
	  
	I don’t share this to brag. I share it so you’ll take my advice seriously.  
	  
	The last few months of revenue:  
	  
	• Aug: $451,000  
	• July: $405,000  
	• June: $408,000  
	• May: $388,000  
	• April: $322,000  
	  
	And yes, profit margins are north of 90%.  
	  
	These are the 4 levers that got me here:  
	  
	• Lever #1: Scalable Lead Generation — You need lead gen that scales independent of your time. In my case, YouTube.  
	  
	• Lever #2: Time-Divorced Delivery — High margins require products that scale without your time. In my case, Maker School. I do weekly calls and spend a few hours on it per day. But it’s one-to-many.  
	  
	• Lever #3: Automated Sales — I don't hop on sales calls to sell Maker School. In my case, I have a checkout page that has a solid conversion rate.  
	  
	• Lever #4: Take Risk — The probability your business grows when you take risk increases. In my case, I switched from a strictly agency model to an education business. And I went all-in on YouTube.  
	  
	But before you start pulling these levers... these may not make sense for you yet.  
	  
	If your goal is $10k/Mo or $20k/Mo, take the linear path first:  
	  
	• Upwork proposals, cold emails, DM oureach.  
	• Take 1:1 sales calls. No faster way to convert.  
	• Do fulfillment yourself. You’ll have 100% margins.  
	  
	Once you stack some cash and have breathing room, start thinking about leverage.
- ## Feed post number 16
	How I’d automate a creative agency in 28 steps (full breakdown):  
	  
	You can get the full breakdown by commenting “full”.  
	  
	But here’s the quick summary:  
	  
	Lead Management  
	  
	• Automatic lead scoring and routing  
	• Instant client onboarding sequences  
	• Proposal generation and follow-up  
	  
	Project Workflow  
	  
	• Seamless handoffs between teams  
	• Automated status updates to clients  
	• Resource allocation and scheduling  
	  
	Client Communication  
	  
	• Meeting scheduling and reminders  
	• Progress reports and deliverable notifications  
	• Feedback collection and approval processes  
	  
	Business Intelligence  
	  
	• Real-time project profitability tracking  
	• Client satisfaction monitoring  
	• Team performance analytics  
	  
	What I’d expect from an agency that treats automation like a full time job:  
	  
	• 60% reduction in admin time  
	• 40% faster project delivery  
	• 25% increase in client satisfaction  
	• 80% fewer things falling through cracks  
	  
	Of course, it’s not as easy as it sounds.  
	  
	To get the full breakdown, comment “full”.
- ## Feed post number 17
	My content agency was stuck at $10K-$15K/mo.  
	  
	Until I understood this concept:  
	  
	The Theory of Constraints.  
	  
	This was developed by Eli Goldratt. He’s got a book called “The Goal” which explains it thoroughly. But I’ll share the high-level idea with you here and how it helped me crack $50k, $70k and even $90k months with my agencies:  
	  
	In a closed pipeline, the fastest the fluid will ever go is determined by the width of the narrowest part of that pipeline.  
	  
	Let’s look at a hypothetical business:  
	  
	• Process 1: Lead Generation (you get 20 calls a month)  
	• Process 2: Sales (you can handle 20 calls per month & consistently \*can\* sell 5)  
	• Process 3: Onboarding (you can onboard 10 clients per month)  
	• Process 4: Fulfillment (you can fulfill for 3 new clients per month)  
	  
	What’s the constraint?  
	  
	If you said fulfillment, you’re right.  
	  
	Lead gen is bringing in 20 calls a month. Sales can convert 25% of them, so 5. Onboarding can easily handle all 5. But fulfillment can only take 3.  
	  
	Which means, sales can only sell 3 each month because fulfillment couldn’t handle more.  
	  
	The solution:  
	  
	Fix fulfillment.  
	  
	This can look different for different companies. For example, you might need to hire more people OR you might need a better project management system OR you might need to adjust your offer to make fulfillment simpler.  
	  
	But assuming you fix it, and can fulfill for 6 clients each month, your bottleneck is solved and the business nearly 2X’d it’s revenue.  
	  
	(Mini test: what would the next bottleneck be, by the way?)  
	  
	Don’t just work hard. Work smart.
	Captions are auto generated<video src="blob:https://www.linkedin.com/8a4b7e99-2955-4ae9-88f1-baaa4709ac76"></video>
	Loaded: 1.77%
	Stream Type LIVE
	Remaining time 3:46
- ## Feed post number 18
- ## Feed post number 19
	I recently spoke to an AI agency owner.  
	  
	What he said shocked me:  
	  
	“I have 13 clients but I’m not making any money”.  
	  
	For context, at 13 clients with an AI agency, you should be making $20k+ if not more. This particular owner was making a few thousand dollars per month. So I got the details from him.  
	  
	Turns out, he’s selling clients on 100% performance-based deals.  
	  
	The problem:  
	  
	The clients have incredibly long sales cycles (he’s in recruiting). And the systems he sells are only 1 piece of the equation. There are a lot of variable he can’t control. So he’s spending 99% of his time doing work for clients that aren’t paying him a dollar.  
	  
	Not only that, but they don’t take him or his work as seriously because they haven’t paid anything.  
	  
	The solution:  
	  
	Go back to the basics. Use Upwork and cold email (how he is landing clients). But no performance-based deals.  
	  
	Charge a small upfront fee for a small project. Upsell to recurring. Repeat.  
	  
	Here’s what it might look like in real life:  
	  
	• Send 50 proposals and 5,000 cold emails each month  
	• Sell 10 clients on a $1,000 package  
	• Upsell 3 of them to a $3,000 per month retainer  
	• Average retainer client stays for 5 months  
	• Repeat monthly  
	  
	𝗥𝗲𝘀𝘂𝗹𝘁: You land $55,000 of revenue each month ($10k upfront, $45k contracted).  
	  
	This is how you scale an AI agency.
	Your document has finished loading
- ## Feed post number 20
	Social proof is the biggest hack to sales.  
	  
	So here’s how you can buy $1M in social proof:  
	  
	And you can do this using nothing but your time.  
	  
	I have a fair amount of social proof:  
	  
	• Scaled my agencies to a combined $160k/mo in revenue  
	• #1 paid community on Skool  
	• Spoken on stage with Alex Hormozi and Sam Ovens  
	• Mentioned recently on the Diary of a CEO podcast  
	  
	It’s helped me tremendously.  
	  
	But a few years prior, I had none of that and was living on rice and beans.  
	  
	So how can you buy $1M in social proof?  
	  
	Here are 3 "unfair" tactics I used to build credibility fast:  
	  
	1\. Monetary Association Principle  
	  
	Tie everything to money.  
	  
	❌ "I built a marketing system for XYZ agency during my summer job.”  
	  
	✅ "I generated $15,000 in 2 weeks through a marketing system.”  
	  
	If you didn't generate revenue directly, associate with companies that did.  
	  
	"I built the same system Nick Saraev uses to make $50K/month for a local Dallas agency."  
	  
	2\. Team Association Principle  
	  
	You have zero experience. But you've watched videos and learned skills.  
	  
	Here's how you claim working with big companies:  
	  
	• Make a list of employees at big companies (not executives)  
	• Offer them something valuable for free ($500+ in value)  
	• Build them a website, write their LinkedIn posts, whatever  
	• Now you can say: "I've delivered value for members of the Microsoft team"  
	  
	Not the same as "working with Microsoft." But it transfers credibility.  
	  
	I've used this. It works.  
	  
	3\. Overflow Contractor Approach (Most Aggressive)  
	  
	When I started my videography company, I had zero social proof and barely knew how to hold a camera.  
	  
	Here's what I did:  
	  
	Step 1: Bought leads I couldn't fulfill (spent my last few hundred on Bark)  
	  
	Step 2: Called 200 local videography agencies with this pitch:  
	  
	"I have leads I can't fulfill. Want them for a small referral fee?"  
	  
	Most said yes.  
	  
	Step 3: In coffee meetings, I asked:  
	  
	"Can I show prospects your work and say 'members of our team' handle this type of project?"  
	  
	15-20 agencies agreed.  
	  
	Result: Next sales call, I could legitimately say:  
	  
	"Members of our team have worked with Gillette and Fortune 500 companies."  
	  
	Instant credibility.  
	  
	The point of this post:  
	  
	You just have to get creative.
	<video src="blob:https://www.linkedin.com/6c29cef4-ade1-409f-822c-91de9199f355"></video>
	Loaded: 6.39%
	Stream Type LIVE
	Remaining time 2:05
- ## Feed post number 21
	I’ve made 7 figures with automation.  
	  
	Here’s how I’d sell a CRM system:  
	  
	First, this is a little tougher than a front-end, revenue-generating system. So it takes a little bit more finesse. The way I’d do it:  
	  
	1\. Create a killer CRM template in ClickUp or Monday•com.  
	2\. Spin up a cold email campaign. I won’t go through the steps here but I have several YouTube videos walking through how to do this.  
	3\. Give the CRM template away for free (or very low cost).  
	4\. Offer an implementation call.  
	5\. On the implementation call, explain how they can use the CRM and make a paid offer to customize it for them.  
	  
	Boom.  
	  
	Get in the door with free value. Upsell to a valuable service after you’ve educated them on why they need it.  
	  
	The good news:  
	  
	I’ve already tested this with Project Management Systems and it worked, so I have no doubt this can work for CRMs too.  
	  
	Just steal my cold email copy below 👇🏼
- ## Feed post number 22
	In March of 2024, my first Youtube video went viral.  
	  
	20k views in the first few days.  
	  
	It translated into a flood of followers, a ridiculous number of inquiries, and a lot of dopamine. As a result, I hit 5k subscribers around a month after I began publishing consistently on YouTube.  
	  
	But virality doesn’t last. The next day, I was back on the content hamster wheel. Back to the slower growth. And I was lacking motivation.  
	  
	You may face a similar scenario—whether with content, outreach, or business.  
	  
	If so, maybe I can help.  
	  
	Here’s how I inoculate against wavering determination:  
	  
	When you’re creating content, you’re creating an Internet Statue. Something that will be around for a long time. That people can see. A digital asset that will bring income, interest, and reputation for a long time to come.  
	  
	Every “statue” I build may be seen for dozens of years…by millions of people!  
	  
	If I consider my “hourly rate” talking into my camera, then pool my earnings attributable to that action over the course of the next ten years, it’s probably something like $10,000/hour!  
	  
	Insane.  
	  
	Why I write this:  
	  
	If you find your motivation to build your internet business fluctuating, you probably haven’t logically evaluated the expected return of what you’re doing.  
	  
	Zoom out.  
	  
	Inoculate yourself agains the tens of millions of years of evolution our brains have built that focus on the bad.
- ## Feed post number 23
	“Should I quit my job and go all in?” I got this question last week. Here’s his scenario and what I said:  
	  
	This was a Maker School member.  
	  
	• $10K/M with automation  
	• $15K/M with his 9-5 job  
	  
	And he’s just working on his automation business from 6-8:30am and 7-8:45pm.  
	  
	Baller.  
	  
	But you might be surprised to hear I DID NOT tell him to go all in.  
	  
	You quit your job and you’re making $10K/month but it’s all one-time project revenue, so you’re essentially living paycheck to paycheck.  
	  
	You replace your day job, except now the paychecks are unpredictable and you’re making less than you were.  
	  
	You land a $3K project. Great. But the following month you're starting from zero again.  
	  
	Bad trade.  
	  
	Instead, here’s what I recommended:  
	  
	Use that day job stability to build recurring revenue. Convert your one-time clients to retainers. Upsell monthly services.  
	  
	Guarantee the next month’s income.  
	  
	This buys you stability. Then you can leave your job in a comfortable position, then reinvest those extra 8 hours a day into doing more client acquisition.  
	  
	Being an entrepreneur is all about making the best risk-adjusted bet available.  
	  
	Picture below is his daily schedule.
- ## Feed post number 24
	A few years ago, when I was going door-to-door, a lucrative equity deal (worth $MM) came my way.  
	  
	I didn’t do anything to “deserve” it. I just happened to be at the right place at the right time.  
	  
	In short, it was serendipity.  
	  
	In contrast to most of my current leads, this cost:  
	  
	\- $0 in marketing  
	\- 0 sales calls  
	\- 0 conscious effort  
	  
	Most people would call that luck.  
	  
	But, although often confused, serendipity is \*not\* luck.  
	  
	Because there are actions you can take to increase serendipity in your life and tilt the scales in your favor. And I’ve found great success with one of them:  
	  
	Meet as many people as you can!  
	  
	Two important facts:  
	  
	1\. The avg American knows 20 people closely, and 580 by name.  
	2\. Your age, stats, occupation, and net worth are highly correlated with your friends.  
	  
	Now, let’s invent a “luck” stat: your base rate of serendipity.  
	  
	Every time you meet someone new, you multiply your base rate. I can’t tell you the number of fantastic connections I’ve made by virtue of introducing myself at an event or meeting. Many have changed my life.  
	  
	This specific deal has came my way because I chose to shake someone’s hand at a random event in Vancouver.  
	  
	Impossible to know the value looking forward.  
	  
	You can only see it looking backward.  
	  
	TLDR: just meet more people.
	Your document has finished loading
- ## Feed post number 25
	Proposals won’t get you the highest close rates.  
	  
	But here’s why I use them anyway (and how):  
	  
	I prefer not to sign up for projects with low prices and massive scopes. When you’re live on a sales call, you often commit to things you don’t really want to do. Proposals solve that problem for you.  
	  
	The problem most agencies have with proposals: they have a 6-step process.  
	  
	1\. Send proposal  
	2\. Prospect signs proposal  
	3\. Send agreement  
	4\. Prospect signs agreement  
	5\. Send invoice  
	6\. Prospect pays invoice  
	  
	That's 6 places where deals die.  
	  
	𝗧𝗵𝗲 𝗦𝗼𝗹𝘂𝘁𝗶𝗼𝗻:  
	  
	Combine everything into 2 steps:  
	  
	1\. Send proposal + agreement + invoice (all in one)  
	2\. Prospect signs and pays  
	  
	𝗪𝗵𝘆 𝘁𝗵𝗶𝘀 𝘄𝗼𝗿𝗸𝘀:  
	  
	• 0 back-and-forth emails  
	• 0 confusion about next steps  
	• If they've chosen you, make it easy to give you money  
	• Went from 6 failure points to 1  
	  
	𝗠𝘆 𝗽𝗿𝗼𝗽𝗼𝘀𝗮𝗹 𝘀𝘁𝗿𝘂𝗰𝘁𝘂𝗿𝗲:  
	  
	1\. What's the problem?  
	2\. Why am I the solution?  
	3\. Social proof + timeline  
	4\. Cost  
	5\. Legal (keep it simple - <1 page)  
	  
	𝗣𝗿𝗼 𝘁𝗶𝗽: Add a "customized" section at the top. Makes prospects think you personalized everything, even if 80% is templated.  
	  
	𝗧𝗼𝗼𝗹𝘀 𝗜 𝘂𝘀𝗲: PandaDoc automatically prompts payment after signature.  
	  
	So if you use proposals, highly recommend combining the proposal + agreement + invoice.  
	  
	You’ll get better conversion rates.
- ## Feed post number 32
	How I built a $72k/mo automation business with “no-brainer” automation offers:  
	  
	Most people struggle to sell automation because:  
	  
	• It feels complex and expensive  
	• Hard to prove value upfront  
	• Clients don't understand the ROI  
	  
	But there’s an easy solution.  
	  
	Start with no-brainer offers.  
	  
	These are simple, low-risk deliverables that:  
	  
	• Take <1 week to deliver  
	• Cost under $200 to fulfill  
	• Have built-in guarantees  
	• Lead to bigger recurring deals  
	  
	My best example:  
	  
	• $1,325 cold email system  
	• 45 minutes to build (used templates)  
	• <$50 in costs  
	• Leads to $3K/month retainers  
	  
	The secret formula: (Cost × Ease × Desire) / Risk  
	  
	Maximize the first three, minimize risk = higher conversions.  
	  
	You might have occasional refunds (I’d get about 5% refund rate), but you’ll increase conversions by 200-300%.  
	  
	The carousel breaks down my exact process, including copy-paste offer examples.  
	  
	What automation will you turn into your first no-brainer offer?
	Your document has finished loading
- ## Feed post number 33
	Revenue per employee is the #1 metric you should care about in the age of automation.  
	  
	I’ve made tons of mistakes.  
	  
	But I’ve also built a one-person business to $300k+ months.  
	  
	If I were to hire my first remote employee, here’s how I’d do it over again:  
	  
	First, I’d embrace these 3 core concepts:  
	  
	1\. Don’t hire until I absolutely have to.  
	2\. Don’t expect immediate value produciton.  
	3\. Don’t just interview — get them to produce before hiring.  
	  
	Then, I’d follow these 4 steps:  
	  
	→ Define 3 KPIs you can use to measure progress  
	→ Create a defined, 7-day onboarding sequence  
	→ Build a daily system that forces progress tracking  
	→ Make the output public OR review it periodically  
	  
	I’d look for the talent in these places:  
	  
	• Upwork: Fast but expensive  
	• Fiverr: Freelancers, also fast but quality varies  
	• Indeed: Scalable, expensive, primarily corporate  
	• Facebook groups: Great talent, cheapest prices  
	• Cold email: Best quality and price, but high effort  
	  
	And that’s how I’d do it.  
	  
	Any additional suggestions you’d add?  
	  
	PS - comment has a link to the page you see below if you want to check it out
- ## Feed post number 34
	Last week, I made an announcement that surprised a lot of people:  
	  
	I'm pausing my Daily Updates YouTube channel.  
	  
	I posted 216 videos this year. And it was working. People were joining Maker School.  
	  
	Over the past week, I’ve gotten a bunch of comments. Mostly positive. But quite a few asking questions like:  
	  
	• "𝘈𝘳𝘦 𝘺𝘰𝘶 𝘤𝘳𝘢𝘻𝘺? 𝘞𝘩𝘺 𝘸𝘰𝘶𝘭𝘥 𝘺𝘰𝘶 𝘴𝘵𝘰𝘱 𝘴𝘰𝘮𝘦𝘵𝘩𝘪𝘯𝘨 𝘴𝘰 𝘱𝘳𝘰𝘧𝘪𝘵𝘢𝘣𝘭𝘦?"  
	• "𝘐𝘴 𝘢𝘶𝘵𝘰𝘮𝘢𝘵𝘪𝘰𝘯 𝘥𝘺𝘪𝘯𝘨? 𝘚𝘩𝘰𝘶𝘭𝘥 𝘐 𝘱𝘪𝘷𝘰𝘵 𝘵𝘰 𝘴𝘰𝘮𝘦𝘵𝘩𝘪𝘯𝘨 𝘦𝘭𝘴𝘦?"  
	  
	Here’s why I’m stepping back:  
	  
	I didn't pause my Daily Updates because they weren't working.  
	  
	I paused them because they were working too well.  
	  
	But after 200 days of daily videos, I realized I was stuck answering the same questions, making incremental improvements, optimizing for metrics that stopped mattering.  
	  
	Frankly, I could make a bigger impact spending my time elsewhere.  
	  
	When I asked "Is creating daily updates on YouTube the highest-leverage use of my time if my goal is to help distribute AI benefits more equitably?"  
	  
	The answer was no.  
	  
	The constraint is rarely time. It’s almost always focus.
	Captions are auto generated<video src="blob:https://www.linkedin.com/857d97e5-f2f5-48e8-960b-43533f4f1ce8"></video>
	Loaded: 0.00%
	Stream Type LIVE
	Remaining time 1:36
- ## Feed post number 35
	Everyone overcomplicates making money.  
	  
	No one takes the caveman approach to $10k/mo:  
	  
	The caveman with a giant bat can kill a saber-tooth tiger. He doesn’t need a hyper-sophisticated sniper rifle. He doesn’t need laser technology or guided missiles.  
	  
	No.  
	  
	If he just hits the thing enough times, he will eventually kill the tiger.  
	  
	Might not do the best job of it. Maybe he’ll get some scratches in the process. But the darn thing is going down eventually.  
	  
	$10,000/mo with an agency/service business is the exact same thing.  
	  
	Submit more upwork proposals. Send more cold emails. Get more sales calls.  
	  
	And if you’re worried about a niche being saturated, a quick reality check:  
	  
	$10,000/mo is an objectively small some of money. From a market perspective, it’s tiny. There is always room for a new entrant to make another $10,000 a month. It doesn’t matter how saturated it is or how competitive it seems.  
	  
	It won’t be easy.  
	  
	If it was easy, would any of us be doing it? No. It wouldn’t be worthwhile. Anything worthwhile is hard.  
	  
	You have to get through the crisis of meaning before you can reach the stage of informed optimism.
- ## Feed post number 36
	1-call close vs 2-call close.  
	  
	Which is better in 2025?  
	  
	Here's what most people's "strategic" funnel looks like:  
	  
	Step 1: Send cold email asking "Are you interested?"  
	  
	Step 2: Prospect replies "Yes"  
	  
	Step 3: Send Loom video with value  
	  
	Step 4: Wait for them to watch the Loom  
	  
	Step 5: Hope they respond positively to the video  
	  
	Step 6: Send calendar link  
	  
	Step 7: Finally get them to book  
	  
	Step 8: Get the best prospects to book a second call  
	  
	But here’s what happens:  
	  
	You start with 100 people. 2% reply “yes” to your initial email (not bad!). But then reality hits:  
	  
	• Of the 2% who said yes, maybe half actually watch your Loom (now down to 1%)  
	• Of those who watch, maybe half respond positively (now 0.5%)  
	• Of those who respond, maybe half actually book your calendar (now 0.125%)  
	  
	You just took a 2% response rate and turned it into less than 0.1% bookings.  
	  
	Every single step in your funnel is a leakage point.  
	  
	Here's what high-converting funnels actually look like:  
	  
	Step 1: Send cold email with your full value proposition, how you solve their problem, your offer, social proof, and clear next steps  
	  
	Step 2: They book a call  
	  
	Way less “leakage”.  
	  
	Just simplify things.  
	  
	I got Maker School to $300k/mo by putting a link in my YouTube descriptions. That’s it.  
	  
	PS - the time it makes most sense to use a 2-call close system is if you’re selling to enterprise companies.
- ## Feed post number 37
	I sold my first clients for $500.  
	  
	One of my last clients paid $21,000+.  
	  
	Here’s how to consistently raise your prices over time:  
	  
	1\. Flood your pipeline.  
	  
	If you only have 2–3 leads, you’ll undercharge out of scarcity. With 20+ leads, you pick the clients who value you most.  
	  
	2\. Land & expand.  
	  
	A $500 project can turn into $16K+ if you deliver quick wins and upsell bigger retainers (real example).  
	  
	3\. Stop trading hours for dollars.  
	  
	Don’t price based on how long it takes you. Price based on the value you create.  
	  
	4\. Solve richer people problems.  
	  
	Dog walkers vs. Wall Street firms. Same effort, 100x pricing difference.  
	  
	5\. Sell outcomes, not features.  
	  
	Clients don’t care about APIs or workflows. They care about ROI and outcomes.  
	  
	6\. Productize or die.  
	  
	If every delivery is custom, you’ll cap out fast. Standardize into repeatable offers so you can scale.  
	  
	  
	If you’re struggling to raise your prices, it’s not just about tweaking the numbers.  
	  
	It’s about shifting how you think about clients, the value you provide, and leverage.  
	  
	PS - if you want my complete guide to pricing automation services, comment “pricing” and I’ll send it to you.
- ## Feed post number 38
	I asked 1,000+ AI agency owners how they’re signing clients. Here’s what actually works in 2025:  
	  
	1\. Upwork (Most Popular for Beginners)  
	  
	“It’s a freelancing platform and you can’t scale.” Sure. But you don’t need $1M/year. You just need some clients.  
	  
	Some key notes:  
	  
	• Beginners suck at sales. Eliminates need to identify problems or explain solutions (clients already know both)  
	• 30% proposal-to-reply rate possible with quality applications (avg is ~20%)  
	• $4,300 closed in first 12 days by one member  
	• Strategy: start with smaller projects to build reviews, then scale pricing  
	  
	2\. Cold Email (Highest ROI)  
	  
	Highest ROI of all the methods. Also quite scalable. This is the #2 most popular client acquisition method.  
	  
	• Lots of initial effort setting up campaigns but most scalable method once set up (just respond to leads)  
	• Get lead source (like apollo), scrape it (apify), enrich it (leadmagic), feed to AI  
	• Set up mailboxes (google) and campaigns (instantly)  
	• Benchmark: 2-3% positive response rates.  
	  
	3\. Communities (Best for Building Authority)  
	  
	Find niche communities. Add value. Be “the guy” in that community. Skool groups, FB groups, etc.  
	  
	• Member signed 4 clients in one month sharing demos in Facebook groups  
	• Takes patience: 2-3 months to build authority  
	• Higher close rates due to trust factor (40-50%)  
	• Perfect if you're starting with no budget. Just takes work. Scales with your time and you need to show up every day  
	  
	4\. LinkedIn/Social Media  
	  
	Not great as the primary approach. But great as a complementary strategy. Very scalable but not as direct a return.  
	  
	• Lead magnets get a bunch of comments  
	• Long-term ROI but requires patience. Can take months to work  
	• Focus on problem-solving content.  
	• Fewer people win. But when you do win, you win really big  
	  
	5\. YouTube (High Long-term Value)  
	  
	This has worked great for me. Show what you do with long-form videos, then use the description link for a form.  
	  
	• Member landed $3,000 client directly from YouTube  
	• 3-6 months to hit "product-content fit". High long-term ROI, but significant upfront time investment  
	• Tutorial-style content works best  
	• High conversion despite low view counts  
	  
	6\. Social Media DMs (Another Cold Outreach Channel)  
	  
	X/LinkedIn makes a lot of sense for B2B. Voice and audio messages work well. So do Loom videos.  
	  
	• Overlooked but effective  
	• Use the "do you know anyone who..." approach  
	  
	A few takeaways:  
	  
	• Start with direct methods (Upwork, cold email) before content strategies  
	• Go to warm leads (people you already know) for the straightest line path to getting clients  
	  
	Once you’re getting clients, then start worrying about making it “scalable”.
	<video src="blob:https://www.linkedin.com/63bf093e-0a58-462a-892a-3ec793cb3c54"></video>
	Loaded: 0.00%
	Stream Type LIVE
	Remaining time 1:55
- ## Feed post number 39
- ## Feed post number 40
	My content agency hit $92k one month.  
	  
	My AI agency quickly hit $72k.  
	  
	(~$50k avg).  
	  
	The type of agency you build matters a lot less than the skill of building an agency. Because they inherently look the same:  
	  
	Marketing → Sales → Onboarding → Fulfillment → Delivery → Retention.  
	  
	You can learn to deliver a service in a matter of weeks. Whether that’s paid ads, content, automation, etc. However, learning the entire flow from marketing to retention takes more time and skill.  
	  
	But once learned, you can scale an agency selling \*any\* service.  
	  
	To give you a clear example, I built a content agency with a partner. We hit $92k one month. Then, I later built an AI agency and scaled it to $72k in a month. At the time, I owned the agency outright and consistently made around $50k a month (that business changed my life).  
	  
	But I was only able to get to that scale as quickly as I did because I’d already done it with a content agency.  
	  
	Master the business model “container” and it doesn’t matter if the service you sell goes out of fashion.  
	  
	Because you’ll be able to pivot and sell whatever is in demand.  
	  
	That’s one reason why I love helping people build AI automation agencies. They don’t just learn how to use Make•com. They learn how to drive demand, close deals, fulfill deals, manage clients, and upsell.  
	  
	Services change. Platforms change. Demand shifts.  
	  
	But if you know how to build an agency, it doesn’t matter.  
	  
	PS - if you want the 3 AI agency sales flows I show in the video, comment “3” and I’ll send it to you.
	<video src="blob:https://www.linkedin.com/12de5d25-b424-41f9-921a-8883fdb990c8"></video>
	Loaded: 0.00%
	Stream Type LIVE
	Remaining time 1:53