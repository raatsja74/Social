---
type: prompt-library
category: engagement-responses
---

# Engagement Response Prompts

- Friendly reply to positive comment about [topic].
- Clarify question about [feature] with concise, helpful tone.

