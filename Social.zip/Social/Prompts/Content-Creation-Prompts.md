---
type: prompt-library
category: content-creation
---

# Content Creation Prompts

- Draft a LinkedIn post about [topic] with [tone].
- Turn this KPI into a post: [metric].

