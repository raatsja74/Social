---
type: prompt-library
category: rag-queries
---

# RAG Query Prompts

- Summarize sources on [subject] for social content.
- Extract 5 key stats about [topic] with citations.

