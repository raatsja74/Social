---
title: "Social Operations Dashboard"
type: dashboard
tags: [dashboard, social, content, outreach, engagement]
created: 2025-11-01
updated: 2025-11-01
status: active
satellite: social
---

# 📱 Social Operations Dashboard

> **Content scheduling, outreach tracking, engagement metrics, and RAG-powered content creation**

[[Ops Hub - Command Center|← Back to Ops Hub]]

---

## 📊 Content Pipeline Overview

### Content Status
```dataview
TABLE 
  platform as "Platform",
  status as "Status",
  scheduled-date as "Scheduled",
  engagement-rate as "Engagement"
FROM "Social/Content"
WHERE type = "post" AND status != "published"
SORT scheduled-date ASC
```

### This Week's Publishing Schedule
| Date | Platform | Content Type | Status | Link |
|------|----------|--------------|--------|------|
| | | | | |

---

## 🎯 Engagement Metrics

### Current Period Performance
- **Posts Published:** [#]
- **Total Reach:** [#]
- **Avg Engagement Rate:** [%]
- **Top Performing Platform:** [Platform]

### Platform Breakdown
| Platform | Posts | Reach | Engagement | Best Time |
|----------|-------|-------|------------|-----------|
| LinkedIn | | | | |
| Twitter/X | | | | |
| Instagram | | | | |
| Facebook | | | | |

---

## 🤝 Outreach Operations

### Active Outreach Campaigns
```dataview
TABLE 
  campaign-name as "Campaign",
  contacts-reached as "Contacts",
  response-rate as "Response Rate",
  status as "Status"
FROM "Social/Outreach"
WHERE status = "active"
SORT file.ctime DESC
```

### Outreach Metrics
- **Contacts This Week:** [#]
- **Response Rate:** [%]
- **Conversations Started:** [#]
- **Conversions:** [#]

### Contact Log
```dataview
TABLE 
  contact-name as "Contact",
  platform as "Platform",
  last-interaction as "Last Contact",
  status as "Status"
FROM "Social/Outreach/Logs"
SORT last-interaction DESC
LIMIT 10
```

---

## 🧠 RAG & Content Intelligence

### Recent RAG Queries
- [Date]: "[Query]" → Used in [[Content/Post-Name]]
- [Date]: "[Query]" → Used in [[Content/Post-Name]]
- [Date]: "[Query]" → Used in [[Content/Post-Name]]

### Content Themes in Rotation
- **LeadBolt & Speed-to-Lead:** [# posts]
- **Automation & AI:** [# posts]
- **Home Services Marketing:** [# posts]
- **Technical Guides:** [# posts]

### Prompt Template Usage
```dataview
TABLE 
  prompt-type as "Type",
  usage-count as "Times Used",
  avg-performance as "Avg Performance"
FROM "Social/Prompts"
SORT usage-count DESC
LIMIT 5
```

---

## 🔥 Priority Focus

### This Week's Content Goals
- [ ] Publish [#] posts about [topic]
- [ ] Complete [#] outreach contacts
- [ ] Test new content format: [format]
- [ ] Update RAG database with [source]

### Content Backlog
- **Drafts Ready:** [#]
- **Ideas Queue:** [#]
- **Research Needed:** [#]

---

## 📈 Performance Analysis

### Top Performing Content
```dataview
TABLE 
  title as "Post",
  platform as "Platform",
  engagement-rate as "Engagement",
  reach as "Reach"
FROM "Social/Content"
WHERE type = "post" AND status = "published"
SORT engagement-rate DESC
LIMIT 5
```

### Content Insights
- **Best Day to Post:** [Day]
- **Best Time:** [Time]
- **Top Content Type:** [Type]
- **Trending Topics:** [Topics]

---

## 🛠️ Quick Actions

```button
name New LinkedIn Post
type command
action QuickAdd: New LinkedIn Post
```
^button-new-post-linkedin

```button
name New X Post
type command
action QuickAdd: New X Post
```
^button-new-post-x

```button
name New Thread
type command
action QuickAdd: New Thread
```
^button-new-post-thread

```button
name Log Outreach Contact
type command
action QuickAdd: Log Outreach Contact
```
^button-log-outreach

```button
name New Outreach Campaign
type command
action QuickAdd: New Outreach Campaign
```
^button-new-outreach-campaign

```button
name RAG Query Entry
type command
action QuickAdd: RAG Query Entry
```
^button-rag-query

```button
name Schedule Content Entry
type command
action QuickAdd: Schedule Content Entry
```
^button-schedule-content

---

## 🔗 Resources & Templates

### Content Templates
- [[Social/Templates/Post-Template-LinkedIn]]
- [[Social/Templates/Post-Template-Twitter]]
- [[Social/Templates/Post-Template-Thread]]
- [[Social/Templates/Outreach-Message-Template]]

### Prompt Library
- [[Social/Prompts/Content-Creation-Prompts]]
- [[Social/Prompts/Engagement-Response-Prompts]]
- [[Social/Prompts/RAG-Query-Prompts]]

### RAG Database
- [[Social/RAG/LeadBolt-Knowledge-Base]]
- [[Social/RAG/Technical-Content-Library]]
- [[Social/RAG/Case-Studies-Archive]]

---

## 🔗 Related Dashboards

- [[Ops Hub - Command Center|🎯 Ops Hub]]
- [[Launch Dashboard|🚀 Launch]]
- [[Automations Dashboard|⚙️ Automations]]

---

## 📝 Social Notes

**Content Wins:**
- [Date]: [Win description]

**Engagement Insights:**
- [Date]: [Insight]

**Process Improvements:**
- [Date]: [Improvement]

---

*Last updated: `= date(today)`*
*Next review: [Date]*
