---
type: post
platform: X
status: draft
scheduled-date: <% tp.date.now("YYYY-MM-DD") %>
engagement-rate:
reach:
tags: [social, x, twitter, content]
title: "<% tp.file.title %>"
---

// 280 characters max

Hook: 

Key stat or insight.

CTA: 

Hashtags: #SpeedToLead #REI #Automation

