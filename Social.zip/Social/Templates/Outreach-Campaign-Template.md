---
type: outreach-campaign
campaign-name: "<% tp.file.title %>"
status: active
start-date: <% tp.date.now("YYYY-MM-DD") %>
end-date: 
target-platforms: [LinkedIn, X]
contacts-target: 50
response-rate-target: 20%
conversions-target: 5
owner: 
notes:
---

## Goals

- Objective:
- KPIs:

## Messaging

- Hook:
- Value props:
- CTAs:

## Cadence

- Daily touch count:
- Follow-up intervals:

## Tracking

- Contacts reached: 0
- Responses: 0
- Conversations: 0
- Conversions: 0

## Tasks

- [ ] Prospect list ready
- [ ] First-touch copy approved
- [ ] Follow-up copy approved
- [ ] Start outreach
- [ ] Mid-campaign review
- [ ] Close-out + summary

