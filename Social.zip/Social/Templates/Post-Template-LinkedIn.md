---
type: post
platform: LinkedIn
status: draft
scheduled-date: <% tp.date.now("YYYY-MM-DD") %>
engagement-rate:
reach:
tags: [social, linkedin, content]
title: "<% tp.file.title %>"
---

# Headline / Hook

## Body

- Point 1
- Point 2
- Point 3

## CTA

See how <3-min replies feel — DM "PILOT".

## Hashtags

#RealEstateWholesaling #LeadResponse #REI #SpeedWins #Under3

