---
type: outreach-log
contact-name: 
platform: 
last-interaction: <% tp.date.now("YYYY-MM-DD") %>
status: open
campaign: 
notes:
---

## Interaction Summary

- Message sent:
- Response:
- Next step:

## Details

- Company:
- Role:
- Channel:
- Link:

