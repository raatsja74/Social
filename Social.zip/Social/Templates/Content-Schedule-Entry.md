---
type: content-schedule
date: <% tp.date.now("YYYY-MM-DD") %>
platform: 
content-type: 
status: planned
link: 
---

## Schedule Entry

- Platform: 
- Content Type: 
- Target Date: <% tp.date.now("YYYY-MM-DD") %>
- Notes:

