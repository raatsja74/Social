---
type: outreach-log
contact-name: 
platform: 
last-interaction: <% tp.date.now("YYYY-MM-DD") %>
status: open
campaign: 
notes:
---

Hi {{name}},

[Your message]

—
Logged on: <% tp.date.now("YYYY-MM-DD HH:mm") %>

