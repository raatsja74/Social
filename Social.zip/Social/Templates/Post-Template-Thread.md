---
type: post
platform: X
content-type: thread
status: draft
scheduled-date: <% tp.date.now("YYYY-MM-DD") %>
engagement-rate:
reach:
tags: [social, thread, content]
title: "<% tp.file.title %>"
---

## Thread Title

1) 

2) 

3) 

4) 

5) 

CTA: 

Hashtags: 

